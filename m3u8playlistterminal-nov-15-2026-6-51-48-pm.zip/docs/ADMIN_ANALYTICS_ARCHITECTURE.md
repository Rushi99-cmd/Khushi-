# M3U8PLAYLISTTERMINAL — Super Admin, Live Analytics & Source Protection Architecture

## 1. Security Model
- **Zero Secrets in the Android APK**: The Android APK contains no administrator passwords, password hashes, signing secrets, or static admin API keys.
- **Owner-Only Server Authentication**: `POST /api/admin/login` verifies credentials against a salted `scrypt` hash (`N=16384, r=8, p=1`) using constant-time `crypto.timingSafeEqual`. There is no public admin registration endpoint.
- **Short-Lived Signed Tokens**:
  - Admin tokens expire after `ADMIN_TOKEN_TTL_SECONDS` (default 15 minutes) and are stored only in volatile memory on the Android device. Signing out (`POST /api/admin/logout`) revokes the token's `jti` immediately on the server.
  - Client tokens expire after `CLIENT_TOKEN_TTL_SECONDS` (default 10 minutes) and gate `/api/client/bootstrap`, `/api/client/playlist`, and `/api/analytics/event`.
- **Rate Limiting**: Sliding-window per-IP limits (`5 req / 15 min` on `/api/admin/login`, `30 req / min` on `/api/client/token`, `60–240 req / min` on proxy/analytics routes).
- **Immutable Audit Log**: Every login, logout, source change, channel edit, and config push is recorded server-side with actor, action, timestamp, and details.

## 2. Source Protection & Trade-Offs
- When `useProxy` is enabled on a source, upstream M3U/M3U8 URLs and server-side upstream headers remain strictly on the backend and are omitted from `/api/client/bootstrap`.
- The backend parses upstream playlists on `/api/admin/sources/:id/refresh` and delivers sanitized channel catalogs or proxied M3U8 output via `/api/client/playlist`.
- **Transparent Limitation**: Media3 ExoPlayer on the user's device must connect to stream segment/manifest URLs to decode video. Unless all video segments are also bandwidth-proxied through a media relay, individual stream URLs delivered to the player are observable on the client network interface.

## 3. Live Viewer Analytics & Crash Handling
- **Anonymous Session IDs**: Each playback session generates a random UUID v4 (`sessionId`). No personal data (email, phone, device serial, MAC, or Android ID) is collected.
- **Lifecycle Events**:
  - `START`: Sent when ExoPlayer begins preparing/playing a channel.
  - `HEARTBEAT`: Sent periodically (`heartbeatIntervalSeconds`, remotely configurable) **only while actively playing**.
  - `STOP`: Sent when exiting playback, switching channels, or backgrounding (`onStop`).
  - `ERROR`: Sent when Media3 emits a `PlaybackException`.
  - `CRASH_RECOVERY`: On next app startup, if DataStore finds an unclosed `pendingAnalyticsSessionId`, the client immediately closes out the crashed session.
- **Server-Side Expiration**: Any session whose `lastHeartbeatAt` exceeds `sessionTimeoutSeconds` (default `75s`) is marked `EXPIRED` and excluded from `totalConcurrentViewers`. Peak concurrency (`peakConcurrentViewers`) is updated strictly from verified active sessions.

## 4. Cost Control, Database Queries & Hosting/Bandwidth Estimates

### Cost Control Design
1. **Lightweight Payloads**: Heartbeat JSON bodies are ~180–220 bytes; bootstrap checks only sync full channels when `configVersion` increments.
2. **Configurable Intervals**: Raising `heartbeatIntervalSeconds` from `30s` to `60s`–`90s` cuts write/compute volume by 50%–67% while adjusting `sessionTimeoutSeconds` proportionally (`~2.5 × heartbeatInterval`).
3. **Configurable Data Retention**: Expired sessions and playback errors older than `retentionDays` (default 7 days) are pruned automatically to keep storage bounded.
4. **Database Query Efficiency**:
   - Index active sessions by `(status, lastHeartbeatAt)` so live concurrent queries only scan active rows (`WHERE status IN ('PLAYING','BUFFERING') AND lastHeartbeatAt >= :cutoff`).
   - Aggregate channel viewer counts in a single pass (`GROUP BY channelId`).

### Hosting & Bandwidth Estimates (Per 1,000 Concurrent Viewers)
- **Heartbeat Interval = 30s**:
  - Requests/sec: `1,000 / 30 ≈ 33.3 req/s` (~86.4M requests/month if sustained 24/7).
  - Bandwidth: `~33.3 × 500 bytes (HTTP headers + JSON) ≈ 16.7 KB/s` (~43 GB/month).
- **Heartbeat Interval = 60s** (Recommended for lower cost):
  - Requests/sec: `1,000 / 60 ≈ 16.7 req/s`.
  - Bandwidth: `~8.3 KB/s` (~21.5 GB/month).
- **Recommended Hosting Tiers**:
  - **Up to 2,000 concurrent viewers**: Single 1 vCPU / 512 MB–1 GB container (e.g., Cloud Run, Fly.io, Railway, or VPS) with SQLite/WAL or managed PostgreSQL.
  - **2,000–25,000 concurrent viewers**: Horizontally scaled stateless Node/Ktor containers behind HTTPS load balancer + Redis for active session/rate-limit state + PostgreSQL for sources, channels, and audit logs.
  - **Important Bandwidth Note**: Keeping `useProxy = true` for playlist metadata uses negligible bandwidth (~20–100 KB per playlist refresh). Do **not** proxy HLS/DASH video segments through the control-plane server unless provisioning dedicated CDN/edge bandwidth (1,000 concurrent 4 Mbps streams = ~4 Gbps egress).
