package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ChannelEntity
import com.example.data.PlaylistEntity
import com.example.models.PlaylistType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name and TV leanback launcher are configured`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("M3U8PLAYLISTTERMINAL", appName)

        val pm = context.packageManager
        val leanbackIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            setPackage(context.packageName)
        }
        val tvActivities = pm.queryIntentActivities(leanbackIntent, 0)
        assertTrue("Expected LEANBACK_LAUNCHER activity", tvActivities.isNotEmpty())
    }

    @Test
    fun `room database caches channels, toggles favourites, and cascades deletes`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val playlist = PlaylistEntity(
            id = "test_pl",
            name = "Test Network",
            urlOrUri = "https://example.com/list.m3u8",
            sourceType = PlaylistType.REMOTE_URL.name,
            isEnabled = true,
            isBuiltIn = false,
            isDefault = true,
            channelCount = 1,
            lastSyncedAt = 123456L,
            lastError = null
        )
        db.playlistDao().upsertPlaylist(playlist)

        val channel = ChannelEntity(
            id = "ch_1",
            playlistId = "test_pl",
            playlistName = "Test Network",
            channelNumber = 1,
            name = "News HD",
            streamUrl = "https://example.com/live/news.m3u8",
            logoUrl = "https://example.com/logo.png",
            groupTitle = "News",
            tvgId = "news.hd",
            userAgent = null,
            referrer = null,
            drmScheme = null,
            drmLicenseUrl = null
        )
        db.channelDao().replaceChannelsForPlaylist("test_pl", listOf(channel))

        val loaded = db.channelDao().observeEnabledChannels().first()
        assertEquals(1, loaded.size)
        assertEquals("News HD", loaded.first().name)

        db.channelDao().setFavourite("ch_1", true)
        val favs = db.channelDao().observeFavouriteChannels().first()
        assertEquals(1, favs.size)

        db.playlistDao().deletePlaylistById("test_pl")
        val afterDelete = db.channelDao().observeEnabledChannels().first()
        assertTrue(afterDelete.isEmpty())
        assertNotNull(db)
        db.close()
    }
}
