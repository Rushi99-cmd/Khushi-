package com.example

import com.example.playlist.M3uParser
import com.example.utils.UrlValidationResult
import com.example.utils.UrlValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M3uParserTest {

    @Test
    fun `parses valid M3U8 entries with EXTINF attributes, EXTVLCOPT, and relative URLs`() {
        val sample = """
            #EXTM3U
            #EXTINF:-1 tvg-id="sci.1" tvg-name="Science Live" tvg-logo="https://cdn.example.com/sci.png" group-title="Documentary" tvg-chno="12",Science Channel HD
            #EXTVLCOPT:http-user-agent=CustomTVAgent/2.0
            https://stream.example.com/hls/science.m3u8
            #EXTINF:-1 group-title="Sports",Sports Arena
            live/sports.mpd
        """.trimIndent()

        val entries = M3uParser.parse(
            content = sample,
            playlistId = "pl_1",
            baseUrl = "https://cdn.example.com/playlists/main.m3u8"
        )

        assertEquals(2, entries.size)
        assertEquals(12, entries[0].channelNumber)
        assertEquals("Science Channel HD", entries[0].name)
        assertEquals("Documentary", entries[0].groupTitle)
        assertEquals("https://cdn.example.com/sci.png", entries[0].logoUrl)
        assertEquals("CustomTVAgent/2.0", entries[0].userAgent)

        assertEquals(13, entries[1].channelNumber)
        assertEquals("Sports Arena", entries[1].name)
        assertEquals("https://cdn.example.com/playlists/live/sports.mpd", entries[1].streamUrl)
    }

    @Test
    fun `validates playlist URLs cleanly`() {
        assertTrue(UrlValidator.validatePlaylistUrl("https://m3u8playlistterminal-free.lovable.app/api/playlist") is UrlValidationResult.Valid)
        assertTrue(UrlValidator.validatePlaylistUrl("") is UrlValidationResult.Invalid)
        assertTrue(UrlValidator.validatePlaylistUrl("ftp://example.com/list.m3u") is UrlValidationResult.Invalid)
        assertTrue(UrlValidator.validatePlaylistUrl("https://") is UrlValidationResult.Invalid)
    }
}
