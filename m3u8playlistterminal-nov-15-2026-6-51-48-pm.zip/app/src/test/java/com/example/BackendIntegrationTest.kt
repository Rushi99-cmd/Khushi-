package com.example

import com.example.models.AdminChannelPatchRequest
import com.example.models.AdminConfigUpdateRequest
import com.example.models.AdminSourceUpsertRequest
import com.example.models.AnalyticsEventRequest
import com.example.network.AdminUnauthorizedException
import com.example.network.BackendApiClient
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class BackendIntegrationTest {

    private lateinit var server: HttpServer
    private lateinit var baseUrl: String
    private val clientTokenCalls = AtomicInteger(0)
    private val analyticsPayloads = mutableListOf<String>()

    @Before
    fun setUp() {
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        baseUrl = "http://127.0.0.1:$port"

        server.createContext("/api/client/token") { exchange ->
            clientTokenCalls.incrementAndGet()
            val body = """{"token":"client_tok_1","expiresAt":${System.currentTimeMillis() + 300_000L}}"""
            sendJson(exchange, 200, body)
        }

        server.createContext("/api/client/bootstrap") { exchange ->
            val auth = exchange.requestHeaders.getFirst("Authorization")
            if (auth != "Bearer client_tok_1") {
                sendJson(exchange, 401, """{"error":"Missing client token"}""")
                return@createContext
            }
            val body = """
                {
                  "configVersion": 4,
                  "heartbeatIntervalSeconds": 25,
                  "sessionTimeoutSeconds": 70,
                  "analyticsEnabled": true,
                  "maintenanceMessage": "Maintenance tonight at 02:00 UTC",
                  "sources": [
                    {
                      "id": "src_1",
                      "name": "Protected Primary",
                      "isPrimary": true,
                      "isBackup": false,
                      "useProxy": true,
                      "channelCount": 1,
                      "lastRefreshedAt": 1700000000000,
                      "publicUrl": "/api/client/playlist?sourceId=src_1"
                    }
                  ],
                  "channels": [
                    {
                      "id": "ch_1",
                      "sourceId": "src_1",
                      "channelNumber": 101,
                      "name": "Terminal News HD",
                      "streamUrl": "https://cdn.example.com/news.m3u8",
                      "logoUrl": "https://cdn.example.com/news.png",
                      "groupTitle": "News"
                    }
                  ]
                }
            """.trimIndent()
            sendJson(exchange, 200, body)
        }

        server.createContext("/api/analytics/event") { exchange ->
            val auth = exchange.requestHeaders.getFirst("Authorization")
            if (auth != "Bearer client_tok_1") {
                sendJson(exchange, 401, """{"error":"Invalid client token"}""")
                return@createContext
            }
            val requestBody = exchange.requestBody.readBytes().toString(StandardCharsets.UTF_8)
            synchronized(analyticsPayloads) {
                analyticsPayloads.add(requestBody)
            }
            sendJson(exchange, 200, """{"ok":true,"heartbeatIntervalSeconds":25}""")
        }

        server.createContext("/api/admin/login") { exchange ->
            val req = exchange.requestBody.readBytes().toString(StandardCharsets.UTF_8)
            when {
                req.contains("rate_limit_user") -> {
                    sendJson(exchange, 429, """{"error":"Too many login attempts"}""")
                }
                req.contains("owner@terminal") && req.contains("valid_pass_123") -> {
                    sendJson(
                        exchange,
                        200,
                        """{"token":"admin_tok_99","expiresAt":${System.currentTimeMillis() + 600_000L},"username":"owner@terminal"}"""
                    )
                }
                else -> {
                    sendJson(exchange, 401, """{"error":"Invalid owner credentials"}""")
                }
            }
        }

        server.createContext("/api/admin/analytics/live") { exchange ->
            if (exchange.requestHeaders.getFirst("Authorization") != "Bearer admin_tok_99") {
                sendJson(exchange, 401, """{"error":"Admin token expired"}""")
                return@createContext
            }
            val body = """
                {
                  "generatedAt": 1700000100000,
                  "totalConcurrentViewers": 2,
                  "peakConcurrentViewers": 5,
                  "peakConcurrentAt": 1700000050000,
                  "tvViewers": 1,
                  "mobileViewers": 1,
                  "appVersionCounts": {"1.0": 2},
                  "channelViewerCounts": [{"channelId":"ch_1","channelName":"Terminal News HD","viewers":2}],
                  "activeSessions": [],
                  "recentErrors": [],
                  "config": {
                    "configVersion": 4,
                    "heartbeatIntervalSeconds": 25,
                    "sessionTimeoutSeconds": 70,
                    "retentionDays": 7,
                    "analyticsEnabled": true,
                    "maintenanceMessage": ""
                  }
                }
            """.trimIndent()
            sendJson(exchange, 200, body)
        }

        server.createContext("/api/admin/sources") { exchange ->
            if (exchange.requestHeaders.getFirst("Authorization") != "Bearer admin_tok_99") {
                sendJson(exchange, 401, """{"error":"Unauthorized"}""")
                return@createContext
            }
            when (exchange.requestMethod) {
                "GET" -> sendJson(exchange, 200, """{"sources":[{"id":"src_1","name":"Primary","upstreamUrl":"https://secret.upstream/live.m3u8","isPrimary":true,"isBackup":false,"isEnabled":true,"useProxy":true,"channelCount":1}]}""")
                "POST" -> sendJson(exchange, 201, """{"ok":true}""")
                else -> sendJson(exchange, 200, """{"ok":true}""")
            }
        }

        server.createContext("/api/admin/channels/ch_1") { exchange ->
            if (exchange.requestHeaders.getFirst("Authorization") != "Bearer admin_tok_99") {
                sendJson(exchange, 401, """{"error":"Unauthorized"}""")
                return@createContext
            }
            sendJson(exchange, 200, """{"ok":true}""")
        }

        server.createContext("/api/admin/config") { exchange ->
            if (exchange.requestHeaders.getFirst("Authorization") != "Bearer admin_tok_99") {
                sendJson(exchange, 401, """{"error":"Unauthorized"}""")
                return@createContext
            }
            sendJson(
                exchange,
                200,
                """{"config":{"configVersion":5,"heartbeatIntervalSeconds":20,"sessionTimeoutSeconds":60,"retentionDays":14,"analyticsEnabled":true,"maintenanceMessage":"Updated"}}"""
            )
        }

        server.createContext("/api/admin/audit-logs") { exchange ->
            if (exchange.requestHeaders.getFirst("Authorization") != "Bearer admin_tok_99") {
                sendJson(exchange, 401, """{"error":"Unauthorized"}""")
                return@createContext
            }
            sendJson(
                exchange,
                200,
                """{"logs":[{"id":"log_1","timestamp":1700000000000,"actor":"owner@terminal","action":"CONFIG_PUSH","details":"Updated config"}]}"""
            )
        }

        server.start()
    }

    @After
    fun tearDown() {
        server.stop(0)
    }

    private fun sendJson(exchange: com.sun.net.httpserver.HttpExchange, status: Int, jsonBody: String) {
        val bytes = jsonBody.toByteArray(StandardCharsets.UTF_8)
        exchange.responseHeaders.add("Content-Type", "application/json")
        exchange.sendResponseHeaders(status, bytes.size.toLong())
        exchange.responseBody.use { it.write(bytes) }
    }

    @Test
    fun `client token caching, bootstrap sync, and analytics event delivery succeed`() = runBlocking {
        val api = BackendApiClient()

        val bootstrap = api.fetchRemoteBootstrap(baseUrl).getOrThrow()
        assertEquals(4, bootstrap.configVersion)
        assertEquals(25, bootstrap.heartbeatIntervalSeconds)
        assertEquals(1, bootstrap.sources.size)
        assertEquals("Terminal News HD", bootstrap.channels.first().name)

        val eventResult = api.sendAnalyticsEvent(
            baseUrl,
            AnalyticsEventRequest(
                type = "START",
                sessionId = "anon-uuid-1234",
                channelId = "ch_1",
                channelName = "Terminal News HD",
                deviceType = "ANDROID_TV",
                appVersion = "1.0"
            )
        )
        assertTrue(eventResult.isSuccess)
        assertEquals(1, clientTokenCalls.get()) // Client token cached across calls
        assertEquals(1, analyticsPayloads.size)
        assertTrue(analyticsPayloads.first().contains("anon-uuid-1234"))
    }

    @Test
    fun `owner admin login enforces auth, rate limits, and AdminUnauthorizedException`() = runBlocking {
        val api = BackendApiClient()

        val badLogin = api.adminLogin(baseUrl, "user", "wrong")
        assertTrue(badLogin.isFailure)

        val rateLimited = api.adminLogin(baseUrl, "rate_limit_user", "any")
        assertTrue(rateLimited.isFailure)
        assertTrue(rateLimited.exceptionOrNull()?.message?.contains("Too many") == true)

        val expiredCheck = api.fetchLiveAnalytics(baseUrl, "expired_token")
        assertTrue(expiredCheck.exceptionOrNull() is AdminUnauthorizedException)

        val session = api.adminLogin(baseUrl, "owner@terminal", "valid_pass_123").getOrThrow()
        assertEquals("owner@terminal", session.username)

        val live = api.fetchLiveAnalytics(baseUrl, session.token).getOrThrow()
        assertEquals(2, live.totalConcurrentViewers)
        assertEquals(5, live.peakConcurrentViewers)

        val sources = api.fetchAdminSources(baseUrl, session.token).getOrThrow()
        assertEquals(1, sources.size)

        assertTrue(
            api.addAdminSource(
                baseUrl,
                session.token,
                AdminSourceUpsertRequest("Backup", "https://backup.example.com/list.m3u8", isBackup = true)
            ).isSuccess
        )

        assertTrue(
            api.patchAdminChannel(
                baseUrl,
                session.token,
                "ch_1",
                AdminChannelPatchRequest(enabled = false)
            ).isSuccess
        )

        val pushed = api.pushRemoteConfig(
            baseUrl,
            session.token,
            AdminConfigUpdateRequest(20, 60, 14, true, "Updated")
        ).getOrThrow()
        assertEquals(5, pushed.configVersion)

        val logs = api.fetchAuditLogs(baseUrl, session.token).getOrThrow()
        assertEquals(1, logs.size)
        assertEquals("CONFIG_PUSH", logs.first().action)
    }
}
