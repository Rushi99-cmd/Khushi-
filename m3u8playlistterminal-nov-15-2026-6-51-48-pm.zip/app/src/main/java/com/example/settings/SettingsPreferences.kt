package com.example.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.models.AspectRatioMode
import com.example.models.BufferProfile
import com.example.models.RefreshInterval
import com.example.models.ThemePreset
import com.example.models.UserSettings
import com.example.utils.AppConstants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "terminal_settings")

class SettingsPreferences(private val context: Context) {

    private object Keys {
        val HAS_COMPLETED_WELCOME = booleanPreferencesKey("has_completed_welcome")
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val DEFAULT_PLAYLIST_ID = stringPreferencesKey("default_playlist_id")
        val AUTO_REFRESH_ENABLED = booleanPreferencesKey("auto_refresh_enabled")
        val REFRESH_INTERVAL = stringPreferencesKey("refresh_interval")
        val DEFAULT_ASPECT_RATIO = stringPreferencesKey("default_aspect_ratio")
        val BUFFER_PROFILE = stringPreferencesKey("buffer_profile")
        val CUSTOM_USER_AGENT = stringPreferencesKey("custom_user_agent")
        val LAST_CHANNEL_ID = stringPreferencesKey("last_channel_id")
        val LAST_AUTO_REFRESH_AT = longPreferencesKey("last_auto_refresh_at")
        val BACKEND_SERVER_URL = stringPreferencesKey("backend_server_url")
        val ANALYTICS_ENABLED = booleanPreferencesKey("analytics_enabled")
        val HEARTBEAT_INTERVAL_SECONDS = intPreferencesKey("heartbeat_interval_seconds")
        val LAST_REMOTE_CONFIG_VERSION = intPreferencesKey("last_remote_config_version")
        val MAINTENANCE_MESSAGE = stringPreferencesKey("maintenance_message")
        val PENDING_ANALYTICS_SESSION_ID = stringPreferencesKey("pending_analytics_session_id")
        val PENDING_ANALYTICS_CHANNEL_ID = stringPreferencesKey("pending_analytics_channel_id")
        val PENDING_ANALYTICS_CHANNEL_NAME = stringPreferencesKey("pending_analytics_channel_name")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            hasCompletedWelcome = prefs[Keys.HAS_COMPLETED_WELCOME] ?: false,
            themePreset = prefs[Keys.THEME_PRESET]?.let {
                runCatching { ThemePreset.valueOf(it) }.getOrNull()
            } ?: ThemePreset.MIDNIGHT_NEON,
            defaultPlaylistId = prefs[Keys.DEFAULT_PLAYLIST_ID] ?: AppConstants.BUILT_IN_PLAYLIST_ID,
            autoRefreshEnabled = prefs[Keys.AUTO_REFRESH_ENABLED] ?: true,
            refreshInterval = prefs[Keys.REFRESH_INTERVAL]?.let {
                runCatching { RefreshInterval.valueOf(it) }.getOrNull()
            } ?: RefreshInterval.ON_LAUNCH,
            defaultAspectRatio = prefs[Keys.DEFAULT_ASPECT_RATIO]?.let {
                runCatching { AspectRatioMode.valueOf(it) }.getOrNull()
            } ?: AspectRatioMode.FIT,
            bufferProfile = prefs[Keys.BUFFER_PROFILE]?.let {
                runCatching { BufferProfile.valueOf(it) }.getOrNull()
            } ?: BufferProfile.BALANCED,
            customUserAgent = prefs[Keys.CUSTOM_USER_AGENT] ?: "",
            lastChannelId = prefs[Keys.LAST_CHANNEL_ID],
            backendServerUrl = prefs[Keys.BACKEND_SERVER_URL] ?: "",
            analyticsEnabled = prefs[Keys.ANALYTICS_ENABLED] ?: true,
            heartbeatIntervalSeconds = prefs[Keys.HEARTBEAT_INTERVAL_SECONDS] ?: 30,
            lastRemoteConfigVersion = prefs[Keys.LAST_REMOTE_CONFIG_VERSION] ?: 0,
            maintenanceMessage = prefs[Keys.MAINTENANCE_MESSAGE] ?: ""
        )
    }

    suspend fun getSettingsOnce(): UserSettings = settingsFlow.first()

    suspend fun getLastAutoRefreshAt(): Long =
        context.dataStore.data.first()[Keys.LAST_AUTO_REFRESH_AT] ?: 0L

    suspend fun setLastAutoRefreshAt(timestamp: Long) {
        context.dataStore.edit { it[Keys.LAST_AUTO_REFRESH_AT] = timestamp }
    }

    suspend fun setWelcomeCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.HAS_COMPLETED_WELCOME] = completed }
    }

    suspend fun setThemePreset(preset: ThemePreset) {
        context.dataStore.edit { it[Keys.THEME_PRESET] = preset.name }
    }

    suspend fun setDefaultPlaylistId(playlistId: String) {
        context.dataStore.edit { it[Keys.DEFAULT_PLAYLIST_ID] = playlistId }
    }

    suspend fun setAutoRefreshEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_REFRESH_ENABLED] = enabled }
    }

    suspend fun setRefreshInterval(interval: RefreshInterval) {
        context.dataStore.edit { it[Keys.REFRESH_INTERVAL] = interval.name }
    }

    suspend fun setDefaultAspectRatio(mode: AspectRatioMode) {
        context.dataStore.edit { it[Keys.DEFAULT_ASPECT_RATIO] = mode.name }
    }

    suspend fun setBufferProfile(profile: BufferProfile) {
        context.dataStore.edit { it[Keys.BUFFER_PROFILE] = profile.name }
    }

    suspend fun setCustomUserAgent(userAgent: String) {
        context.dataStore.edit { it[Keys.CUSTOM_USER_AGENT] = userAgent.trim() }
    }

    suspend fun setLastChannelId(channelId: String?) {
        context.dataStore.edit {
            if (channelId == null) {
                it.remove(Keys.LAST_CHANNEL_ID)
            } else {
                it[Keys.LAST_CHANNEL_ID] = channelId
            }
        }
    }

    suspend fun setBackendServerUrl(url: String) {
        context.dataStore.edit { it[Keys.BACKEND_SERVER_URL] = url.trim().trimEnd('/') }
    }

    suspend fun setAnalyticsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ANALYTICS_ENABLED] = enabled }
    }

    suspend fun applyRemoteConfig(
        configVersion: Int,
        heartbeatIntervalSeconds: Int,
        maintenanceMessage: String
    ) {
        context.dataStore.edit {
            it[Keys.LAST_REMOTE_CONFIG_VERSION] = configVersion
            it[Keys.HEARTBEAT_INTERVAL_SECONDS] = heartbeatIntervalSeconds.coerceIn(10, 300)
            it[Keys.MAINTENANCE_MESSAGE] = maintenanceMessage
        }
    }

    suspend fun getPendingAnalyticsSession(): Triple<String, String, String>? {
        val prefs = context.dataStore.data.first()
        val sid = prefs[Keys.PENDING_ANALYTICS_SESSION_ID] ?: return null
        val cid = prefs[Keys.PENDING_ANALYTICS_CHANNEL_ID] ?: ""
        val cname = prefs[Keys.PENDING_ANALYTICS_CHANNEL_NAME] ?: ""
        return Triple(sid, cid, cname)
    }

    suspend fun setPendingAnalyticsSession(sessionId: String?, channelId: String = "", channelName: String = "") {
        context.dataStore.edit {
            if (sessionId == null) {
                it.remove(Keys.PENDING_ANALYTICS_SESSION_ID)
                it.remove(Keys.PENDING_ANALYTICS_CHANNEL_ID)
                it.remove(Keys.PENDING_ANALYTICS_CHANNEL_NAME)
            } else {
                it[Keys.PENDING_ANALYTICS_SESSION_ID] = sessionId
                it[Keys.PENDING_ANALYTICS_CHANNEL_ID] = channelId
                it[Keys.PENDING_ANALYTICS_CHANNEL_NAME] = channelName
            }
        }
    }
}
