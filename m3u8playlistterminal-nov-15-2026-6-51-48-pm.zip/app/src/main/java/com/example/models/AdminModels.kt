package com.example.models

import kotlinx.serialization.Serializable

@Serializable
data class ClientTokenResponse(
    val token: String,
    val expiresAt: Long
)

@Serializable
data class RemoteSourceDto(
    val id: String,
    val name: String,
    val isPrimary: Boolean = false,
    val isBackup: Boolean = false,
    val useProxy: Boolean = true,
    val channelCount: Int = 0,
    val lastRefreshedAt: Long? = null,
    val publicUrl: String? = null
)

@Serializable
data class RemoteChannelDto(
    val id: String,
    val sourceId: String,
    val channelNumber: Int,
    val name: String,
    val streamUrl: String,
    val logoUrl: String? = null,
    val groupTitle: String = "General",
    val tvgId: String? = null,
    val userAgent: String? = null
)

@Serializable
data class RemoteBootstrapResponse(
    val configVersion: Int,
    val heartbeatIntervalSeconds: Int = 30,
    val sessionTimeoutSeconds: Int = 75,
    val analyticsEnabled: Boolean = true,
    val maintenanceMessage: String = "",
    val sources: List<RemoteSourceDto> = emptyList(),
    val channels: List<RemoteChannelDto> = emptyList()
)

@Serializable
data class AnalyticsEventRequest(
    val type: String,
    val sessionId: String,
    val channelId: String,
    val channelName: String,
    val deviceType: String,
    val appVersion: String,
    val status: String = "PLAYING",
    val errorCode: String? = null,
    val errorMessage: String? = null
)

@Serializable
data class AnalyticsEventResponse(
    val ok: Boolean = true,
    val heartbeatIntervalSeconds: Int? = null
)

@Serializable
data class AdminLoginRequest(
    val username: String,
    val password: String
)

@Serializable
data class AdminLoginResponse(
    val token: String,
    val expiresAt: Long,
    val username: String
)

@Serializable
data class ActiveSessionDto(
    val sessionId: String,
    val channelId: String = "",
    val channelName: String = "",
    val deviceType: String = "MOBILE",
    val appVersion: String = "1.0",
    val status: String = "PLAYING",
    val startedAt: Long = 0L,
    val lastHeartbeatAt: Long = 0L,
    val errorCount: Int = 0
)

@Serializable
data class ChannelViewerCountDto(
    val channelId: String = "",
    val channelName: String = "",
    val viewers: Int = 0
)

@Serializable
data class PlaybackErrorLogDto(
    val id: String = "",
    val sessionId: String = "",
    val channelId: String = "",
    val channelName: String = "",
    val deviceType: String = "MOBILE",
    val appVersion: String = "1.0",
    val errorCode: String = "",
    val errorMessage: String = "",
    val timestamp: Long = 0L
)

@Serializable
data class RemoteConfigDto(
    val configVersion: Int = 1,
    val heartbeatIntervalSeconds: Int = 30,
    val sessionTimeoutSeconds: Int = 75,
    val retentionDays: Int = 7,
    val analyticsEnabled: Boolean = true,
    val maintenanceMessage: String = ""
)

@Serializable
data class LiveAnalyticsResponse(
    val generatedAt: Long = 0L,
    val totalConcurrentViewers: Int = 0,
    val peakConcurrentViewers: Int = 0,
    val peakConcurrentAt: Long? = null,
    val tvViewers: Int = 0,
    val mobileViewers: Int = 0,
    val appVersionCounts: Map<String, Int> = emptyMap(),
    val channelViewerCounts: List<ChannelViewerCountDto> = emptyList(),
    val activeSessions: List<ActiveSessionDto> = emptyList(),
    val recentErrors: List<PlaybackErrorLogDto> = emptyList(),
    val config: RemoteConfigDto = RemoteConfigDto()
)

@Serializable
data class AdminSourceDto(
    val id: String,
    val name: String,
    val upstreamUrl: String,
    val isPrimary: Boolean = false,
    val isBackup: Boolean = false,
    val isEnabled: Boolean = true,
    val useProxy: Boolean = true,
    val lastRefreshedAt: Long? = null,
    val lastError: String? = null,
    val channelCount: Int = 0
)

@Serializable
data class AdminSourcesResponse(
    val sources: List<AdminSourceDto> = emptyList()
)

@Serializable
data class AdminChannelDto(
    val id: String,
    val sourceId: String,
    val channelNumber: Int,
    val name: String,
    val streamUrl: String,
    val logoUrl: String? = null,
    val groupTitle: String = "General",
    val tvgId: String? = null,
    val userAgent: String? = null,
    val enabled: Boolean = true
)

@Serializable
data class AdminChannelsResponse(
    val channels: List<AdminChannelDto> = emptyList()
)

@Serializable
data class AuditLogEntryDto(
    val id: String,
    val timestamp: Long,
    val actor: String,
    val action: String,
    val details: String
)

@Serializable
data class AuditLogsResponse(
    val logs: List<AuditLogEntryDto> = emptyList()
)

@Serializable
data class AdminSourceUpsertRequest(
    val name: String,
    val upstreamUrl: String,
    val isPrimary: Boolean = false,
    val isBackup: Boolean = false,
    val isEnabled: Boolean = true,
    val useProxy: Boolean = true
)

@Serializable
data class AdminChannelPatchRequest(
    val name: String? = null,
    val logoUrl: String? = null,
    val groupTitle: String? = null,
    val channelNumber: Int? = null,
    val enabled: Boolean? = null
)

@Serializable
data class AdminConfigUpdateRequest(
    val heartbeatIntervalSeconds: Int,
    val sessionTimeoutSeconds: Int,
    val retentionDays: Int,
    val analyticsEnabled: Boolean,
    val maintenanceMessage: String
)

data class AdminSessionState(
    val token: String,
    val expiresAt: Long,
    val username: String
) {
    fun isExpired(nowMs: Long = System.currentTimeMillis()): Boolean = nowMs >= expiresAt - 5_000L
}
