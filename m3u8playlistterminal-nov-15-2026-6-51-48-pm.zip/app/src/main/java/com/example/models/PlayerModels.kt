package com.example.models

data class TrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val subLabel: String,
    val isSelected: Boolean,
    val isSupported: Boolean = true
)

data class PlayerUiState(
    val currentChannel: Channel? = null,
    val channelQueue: List<Channel> = emptyList(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val isLive: Boolean = true,
    val isSeekable: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPercentage: Int = 0,
    val volume: Float = 1f,
    val isMuted: Boolean = false,
    val aspectRatio: AspectRatioMode = AspectRatioMode.FIT,
    val isFullscreen: Boolean = true,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val audioTracks: List<TrackOption> = emptyList(),
    val subtitleTracks: List<TrackOption> = emptyList(),
    val videoQualities: List<TrackOption> = emptyList(),
    val errorTitle: String? = null,
    val errorMessage: String? = null,
    val errorDetails: String? = null
)
