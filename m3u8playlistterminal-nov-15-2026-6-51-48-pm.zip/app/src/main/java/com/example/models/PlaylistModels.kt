package com.example.models

enum class PlaylistType(val label: String) {
    BUILT_IN("Built-in Terminal"),
    REMOTE_URL("Remote M3U/M3U8"),
    LOCAL_FILE("Local File")
}

enum class ThemePreset(val label: String, val subtitle: String) {
    MIDNIGHT_NEON("Midnight Neon", "Default #07090F deep terminal with neon pink & cyan"),
    CYBER_SLATE("Cyber Slate", "High-contrast slate surfaces for bright living rooms"),
    OLED_BLACK("OLED Pure Black", "True #000000 backdrop for OLED TVs and phones")
}

enum class AspectRatioMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    ZOOM("Zoom"),
    RATIO_16_9("16:9"),
    RATIO_4_3("4:3")
}

enum class RefreshInterval(val label: String, val hours: Long) {
    MANUAL("Manual Only", 0L),
    ON_LAUNCH("Every App Launch", -1L),
    EVERY_6_HOURS("Every 6 Hours", 6L),
    EVERY_12_HOURS("Every 12 Hours", 12L),
    EVERY_24_HOURS("Every 24 Hours", 24L)
}

enum class BufferProfile(
    val label: String,
    val description: String,
    val minBufferMs: Int,
    val maxBufferMs: Int,
    val bufferForPlaybackMs: Int,
    val bufferForPlaybackAfterRebufferMs: Int
) {
    LOW_LATENCY(
        label = "Low Latency",
        description = "Fast channel zapping for strong connections",
        minBufferMs = 4_000,
        maxBufferMs = 15_000,
        bufferForPlaybackMs = 1_000,
        bufferForPlaybackAfterRebufferMs = 2_000
    ),
    BALANCED(
        label = "Balanced",
        description = "Recommended for Android TV & mobile",
        minBufferMs = 10_000,
        maxBufferMs = 30_000,
        bufferForPlaybackMs = 2_000,
        bufferForPlaybackAfterRebufferMs = 4_000
    ),
    HIGH_STABILITY(
        label = "Slow Internet / High Buffer",
        description = "Extra pre-buffering to reduce stalls on weak links",
        minBufferMs = 20_000,
        maxBufferMs = 60_000,
        bufferForPlaybackMs = 4_000,
        bufferForPlaybackAfterRebufferMs = 8_000
    )
}

enum class SearchScope(val label: String) {
    ALL("All"),
    CHANNEL_NAME("Channel"),
    CATEGORY("Category"),
    PLAYLIST("Playlist")
}

data class PlaylistSource(
    val id: String,
    val name: String,
    val urlOrUri: String,
    val type: PlaylistType,
    val isEnabled: Boolean,
    val isBuiltIn: Boolean,
    val isDefault: Boolean,
    val channelCount: Int,
    val lastSyncedAt: Long?,
    val lastError: String?
)

data class Channel(
    val id: String,
    val playlistId: String,
    val playlistName: String,
    val channelNumber: Int,
    val name: String,
    val streamUrl: String,
    val logoUrl: String?,
    val groupTitle: String,
    val tvgId: String?,
    val userAgent: String?,
    val referrer: String?,
    val drmScheme: String?,
    val drmLicenseUrl: String?,
    val isFavourite: Boolean,
    val lastWatchedAt: Long?,
    val lastPositionMs: Long,
    val durationMs: Long
)

data class CategorySummary(
    val name: String,
    val channelCount: Int,
    val sampleLogoUrl: String?
)

sealed interface SyncState {
    data object Idle : SyncState
    data class Loading(val message: String) : SyncState
    data class Success(val message: String, val timestamp: Long) : SyncState
    data class CachedFallback(val reason: String, val channelCount: Int) : SyncState
    data class Error(val message: String) : SyncState
}

data class UserSettings(
    val hasCompletedWelcome: Boolean = false,
    val themePreset: ThemePreset = ThemePreset.MIDNIGHT_NEON,
    val defaultPlaylistId: String = "built_in_terminal",
    val autoRefreshEnabled: Boolean = true,
    val refreshInterval: RefreshInterval = RefreshInterval.ON_LAUNCH,
    val defaultAspectRatio: AspectRatioMode = AspectRatioMode.FIT,
    val bufferProfile: BufferProfile = BufferProfile.BALANCED,
    val customUserAgent: String = "",
    val lastChannelId: String? = null,
    val backendServerUrl: String = "",
    val analyticsEnabled: Boolean = true,
    val heartbeatIntervalSeconds: Int = 30,
    val lastRemoteConfigVersion: Int = 0,
    val maintenanceMessage: String = ""
)
