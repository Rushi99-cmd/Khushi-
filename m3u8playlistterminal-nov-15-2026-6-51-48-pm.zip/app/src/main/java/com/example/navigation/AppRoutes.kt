package com.example.navigation

import kotlinx.serialization.Serializable

sealed interface AppRoute {
    @Serializable
    data object Welcome : AppRoute

    @Serializable
    data object Home : AppRoute

    @Serializable
    data class LiveTv(val initialCategory: String? = null) : AppRoute

    @Serializable
    data object Categories : AppRoute

    @Serializable
    data object Playlists : AppRoute

    @Serializable
    data object Search : AppRoute

    @Serializable
    data object Settings : AppRoute

    @Serializable
    data class Player(val channelId: String) : AppRoute

    @Serializable
    data object AdminLogin : AppRoute

    @Serializable
    data object AdminDashboard : AppRoute
}

enum class SidebarDestination(
    val label: String,
    val testTag: String
) {
    HOME("Home", "nav_home"),
    LIVE_TV("Live TV", "nav_live_tv"),
    CATEGORIES("Categories", "nav_categories"),
    PLAYLISTS("My Playlists", "nav_playlists"),
    SEARCH("Search", "nav_search"),
    SETTINGS("Settings", "nav_settings")
}
