package com.example.ui.screens

import android.app.Activity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.models.AspectRatioMode
import com.example.models.Channel
import com.example.models.PlayerUiState
import com.example.models.TrackOption
import com.example.ui.components.BroadcastPulseLoader
import com.example.ui.components.ChannelCard
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.NeonAccentGradient
import com.example.ui.theme.TerminalError
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.utils.Formatters
import kotlinx.coroutines.delay

private enum class TrackDialogType {
    NONE, AUDIO, SUBTITLE, VIDEO_QUALITY
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    player: ExoPlayer,
    uiState: PlayerUiState,
    onBack: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeekBy: (Long) -> Unit,
    onSeekTo: (Long) -> Unit,
    onPreviousChannel: () -> Unit,
    onNextChannel: () -> Unit,
    onSelectChannel: (Channel) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onToggleMute: () -> Unit,
    onSetVolume: (Float) -> Unit,
    onSetAspectRatio: (AspectRatioMode) -> Unit,
    onSetFullscreen: (Boolean) -> Unit,
    onSelectAudioTrack: (TrackOption) -> Unit,
    onSelectSubtitleTrack: (TrackOption?) -> Unit,
    onSelectVideoQuality: (TrackOption?) -> Unit,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    val palette = LocalTerminalPalette.current

    var showHud by remember { mutableStateOf(true) }
    var showChannelDrawer by remember { mutableStateOf(false) }
    var activeDialog by remember { mutableStateOf(TrackDialogType.NONE) }
    var lastInteractionAt by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val playPauseFocus = remember { FocusRequester() }

    fun touchHud() {
        showHud = true
        lastInteractionAt = System.currentTimeMillis()
    }

    // Immersive full-screen system bars handling
    DisposableEffect(uiState.isFullscreen, view) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        if (controller != null) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (uiState.isFullscreen) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // Auto-hide HUD after 5 seconds when playing
    LaunchedEffect(showHud, lastInteractionAt, uiState.isPlaying, activeDialog, showChannelDrawer) {
        if (showHud && uiState.isPlaying && activeDialog == TrackDialogType.NONE && !showChannelDrawer && uiState.errorMessage == null) {
            delay(5_000L)
            if (System.currentTimeMillis() - lastInteractionAt >= 4_900L) {
                showHud = false
            }
        }
    }

    LaunchedEffect(showHud) {
        if (showHud) {
            runCatching { playPauseFocus.requestFocus() }
        }
    }

    BackHandler {
        when {
            activeDialog != TrackDialogType.NONE -> activeDialog = TrackDialogType.NONE
            showChannelDrawer -> showChannelDrawer = false
            else -> onBack()
        }
    }

    val videoSurfaceModifier = when (uiState.aspectRatio) {
        AspectRatioMode.RATIO_16_9 -> Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
        AspectRatioMode.RATIO_4_3 -> Modifier
            .fillMaxHeight()
            .aspectRatio(4f / 3f)
        else -> Modifier.fillMaxSize()
    }

    val resizeMode = when (uiState.aspectRatio) {
        AspectRatioMode.FIT, AspectRatioMode.RATIO_16_9, AspectRatioMode.RATIO_4_3 ->
            AspectRatioFrameLayout.RESIZE_MODE_FIT
        AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusable()
            .onPreviewKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown) {
                    when (event.key) {
                        Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause, Key.Spacebar -> {
                            touchHud()
                            onTogglePlayPause()
                            true
                        }
                        Key.ChannelUp, Key.PageUp -> {
                            touchHud()
                            onNextChannel()
                            true
                        }
                        Key.ChannelDown, Key.PageDown -> {
                            touchHud()
                            onPreviousChannel()
                            true
                        }
                        Key.DirectionCenter, Key.Enter -> {
                            if (!showHud) {
                                touchHud()
                                true
                            } else {
                                touchHud()
                                false
                            }
                        }
                        Key.DirectionUp, Key.DirectionDown, Key.DirectionLeft, Key.DirectionRight -> {
                            if (!showHud) {
                                touchHud()
                                true
                            } else {
                                lastInteractionAt = System.currentTimeMillis()
                                false
                            }
                        }
                        else -> false
                    }
                } else {
                    false
                }
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                if (showHud) {
                    showHud = false
                } else {
                    touchHud()
                }
            }
    ) {
        // Native Media3 PlayerView
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        keepScreenOn = true
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        this.player = player
                    }
                },
                update = { playerView ->
                    if (playerView.player !== player) {
                        playerView.player = player
                    }
                    playerView.resizeMode = resizeMode
                },
                modifier = videoSurfaceModifier
            )
        }

        // Buffering Spinner
        if (uiState.isBuffering && uiState.errorMessage == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.35f)),
                contentAlignment = Alignment.Center
            ) {
                BroadcastPulseLoader(
                    label = "Buffering ${uiState.currentChannel?.name ?: "stream"}..."
                )
            }
        }

        // Playback Error Overlay
        if (uiState.errorMessage != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xE607090F))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(22.dp),
                    border = BorderStroke(1.5.dp, TerminalError),
                    modifier = Modifier.widthIn(max = 520.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            tint = TerminalError,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = uiState.errorTitle ?: "Playback Error",
                            style = MaterialTheme.typography.headlineMedium,
                            color = palette.text
                        )
                        Text(
                            text = uiState.errorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textSecondary
                        )
                        if (!uiState.errorDetails.isNullOrBlank()) {
                            Text(
                                text = uiState.errorDetails,
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary.copy(alpha = 0.7f),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NeonGradientButton(
                                text = "Retry",
                                onClick = onRetry,
                                leadingIcon = { Icon(Icons.Filled.Refresh, null, tint = Color.White) },
                                modifier = Modifier.testTag("player_retry_button")
                            )
                            NeonOutlinedButton(
                                text = "Next CH",
                                onClick = onNextChannel,
                                leadingIcon = { Icon(Icons.Filled.SkipNext, null, tint = TerminalSecondary) }
                            )
                            NeonOutlinedButton(
                                text = "Back",
                                onClick = onBack
                            )
                        }
                    }
                }
            }
        }

        // Auto-hiding TV & Mobile Player HUD
        AnimatedVisibility(
            visible = showHud && uiState.errorMessage == null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xCC07090F),
                                Color(0x3307090F),
                                Color(0xE007090F)
                            )
                        )
                    )
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                // Top Info Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            onClick = onBack,
                            color = palette.card.copy(alpha = 0.85f),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, palette.border),
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("player_back_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = stringResource(R.string.cd_back),
                                    tint = Color.White
                                )
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                uiState.currentChannel?.let { ch ->
                                    Surface(
                                        color = TerminalSecondary.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "CH ${Formatters.formatChannelNumber(ch.channelNumber)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TerminalSecondary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (uiState.isLive) {
                                    Surface(
                                        color = TerminalPrimary.copy(alpha = 0.22f),
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.dp, TerminalPrimary)
                                    ) {
                                        Text(
                                            text = "● LIVE",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TerminalPrimary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (uiState.videoHeight > 0) {
                                    Surface(
                                        color = palette.elevated,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = "${uiState.videoHeight}p",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = uiState.currentChannel?.name ?: "Loading Stream...",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            uiState.currentChannel?.let { ch ->
                                Text(
                                    text = "${ch.groupTitle} • ${ch.playlistName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        uiState.currentChannel?.let { ch ->
                            IconButton(
                                onClick = {
                                    touchHud()
                                    onToggleFavourite(ch.id)
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = if (ch.isFavourite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    contentDescription = stringResource(R.string.cd_favourite),
                                    tint = if (ch.isFavourite) TerminalPrimary else Color.White
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                touchHud()
                                showChannelDrawer = !showChannelDrawer
                            },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("player_channel_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.List,
                                contentDescription = "Open channel switcher",
                                tint = TerminalSecondary
                            )
                        }
                    }
                }

                // Center Transport Row
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HudCircleButton(
                        onClick = {
                            touchHud()
                            onPreviousChannel()
                        },
                        contentDescription = stringResource(R.string.cd_previous_channel),
                        modifier = Modifier.testTag("player_prev_channel")
                    ) {
                        Icon(Icons.Filled.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }

                    if (uiState.isSeekable && !uiState.isLive) {
                        HudCircleButton(
                            onClick = {
                                touchHud()
                                onSeekBy(-10_000L)
                            },
                            contentDescription = "Rewind 10 seconds"
                        ) {
                            Icon(Icons.Filled.Replay10, null, tint = Color.White, modifier = Modifier.size(26.dp))
                        }
                    }

                    Surface(
                        onClick = {
                            touchHud()
                            onTogglePlayPause()
                        },
                        shape = CircleShape,
                        color = Color.Transparent,
                        border = BorderStroke(2.dp, NeonAccentGradient),
                        modifier = Modifier
                            .size(72.dp)
                            .focusRequester(playPauseFocus)
                            .testTag("player_play_pause")
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(NeonAccentGradient, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (uiState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = stringResource(R.string.cd_play_pause),
                                tint = Color.White,
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }

                    if (uiState.isSeekable && !uiState.isLive) {
                        HudCircleButton(
                            onClick = {
                                touchHud()
                                onSeekBy(10_000L)
                            },
                            contentDescription = "Forward 10 seconds"
                        ) {
                            Icon(Icons.Filled.Forward10, null, tint = Color.White, modifier = Modifier.size(26.dp))
                        }
                    }

                    HudCircleButton(
                        onClick = {
                            touchHud()
                            onNextChannel()
                        },
                        contentDescription = stringResource(R.string.cd_next_channel),
                        modifier = Modifier.testTag("player_next_channel")
                    ) {
                        Icon(Icons.Filled.SkipNext, null, tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                }

                // Bottom Seekbar + Track / Aspect / Volume Controls
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (uiState.isSeekable && uiState.durationMs > 0L) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = Formatters.formatDuration(uiState.currentPositionMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                            Slider(
                                value = uiState.currentPositionMs.toFloat().coerceIn(0f, uiState.durationMs.toFloat()),
                                onValueChange = { pos ->
                                    touchHud()
                                    onSeekTo(pos.toLong())
                                },
                                valueRange = 0f..uiState.durationMs.toFloat(),
                                colors = SliderDefaults.colors(
                                    thumbColor = TerminalPrimary,
                                    activeTrackColor = TerminalPrimary,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = Formatters.formatDuration(uiState.durationMs),
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                    }

                    Surface(
                        color = palette.card.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, palette.border),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Volume Control
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        touchHud()
                                        onToggleMute()
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = if (uiState.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = stringResource(R.string.cd_volume),
                                        tint = TerminalSecondary
                                    )
                                }
                                Slider(
                                    value = if (uiState.isMuted) 0f else uiState.volume,
                                    onValueChange = {
                                        touchHud()
                                        onSetVolume(it)
                                    },
                                    valueRange = 0f..1f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = TerminalSecondary,
                                        activeTrackColor = TerminalSecondary
                                    ),
                                    modifier = Modifier.width(96.dp)
                                )
                            }

                            // Track & Aspect Controls
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                TextButton(
                                    onClick = {
                                        touchHud()
                                        val modes = AspectRatioMode.entries
                                        val next = modes[(modes.indexOf(uiState.aspectRatio) + 1) % modes.size]
                                        onSetAspectRatio(next)
                                    }
                                ) {
                                    Icon(
                                        Icons.Filled.AspectRatio,
                                        contentDescription = stringResource(R.string.cd_aspect_ratio),
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(uiState.aspectRatio.label, color = Color.White)
                                }

                                IconButton(
                                    onClick = {
                                        touchHud()
                                        activeDialog = TrackDialogType.AUDIO
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        Icons.Filled.Audiotrack,
                                        contentDescription = stringResource(R.string.cd_audio_tracks),
                                        tint = if (uiState.audioTracks.size > 1) TerminalSecondary else Color.White
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        touchHud()
                                        activeDialog = TrackDialogType.SUBTITLE
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        Icons.Filled.ClosedCaption,
                                        contentDescription = stringResource(R.string.cd_subtitles),
                                        tint = if (uiState.subtitleTracks.isNotEmpty()) TerminalSecondary else Color.White
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        touchHud()
                                        activeDialog = TrackDialogType.VIDEO_QUALITY
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        Icons.Filled.HighQuality,
                                        contentDescription = stringResource(R.string.cd_video_quality),
                                        tint = if (uiState.videoQualities.size > 1) TerminalPrimary else Color.White
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        touchHud()
                                        onSetFullscreen(!uiState.isFullscreen)
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = if (uiState.isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                                        contentDescription = stringResource(R.string.cd_fullscreen),
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick Channel Switcher Drawer
        AnimatedVisibility(
            visible = showChannelDrawer,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Surface(
                color = palette.background.copy(alpha = 0.96f),
                border = BorderStroke(1.5.dp, NeonAccentGradient),
                shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp),
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(min = 280.dp, max = 380.dp)
            ) {
                Column(
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Channel Switcher",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.text
                        )
                        TextButton(onClick = { showChannelDrawer = false }) {
                            Text("Close", color = TerminalSecondary)
                        }
                    }
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 16.dp)
                    ) {
                        items(uiState.channelQueue, key = { it.id }) { ch ->
                            ChannelCard(
                                channel = ch,
                                compact = true,
                                onPlay = {
                                    showChannelDrawer = false
                                    onSelectChannel(ch)
                                },
                                onToggleFavourite = { onToggleFavourite(ch.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Track Selection Dialogs
    when (activeDialog) {
        TrackDialogType.AUDIO -> {
            TrackSelectionDialog(
                title = "Audio Track",
                emptyMessage = "No selectable audio tracks exposed by this stream.",
                options = uiState.audioTracks,
                includeAutoOrOff = null,
                isAutoOrOffSelected = false,
                onSelectAutoOrOff = {},
                onSelectOption = {
                    onSelectAudioTrack(it)
                    activeDialog = TrackDialogType.NONE
                },
                onDismiss = { activeDialog = TrackDialogType.NONE }
            )
        }
        TrackDialogType.SUBTITLE -> {
            val anySelected = uiState.subtitleTracks.any { it.isSelected }
            TrackSelectionDialog(
                title = "Subtitles / Captions",
                emptyMessage = "No subtitle tracks available in this stream.",
                options = uiState.subtitleTracks,
                includeAutoOrOff = "Off (Disable Subtitles)",
                isAutoOrOffSelected = !anySelected,
                onSelectAutoOrOff = {
                    onSelectSubtitleTrack(null)
                    activeDialog = TrackDialogType.NONE
                },
                onSelectOption = {
                    onSelectSubtitleTrack(it)
                    activeDialog = TrackDialogType.NONE
                },
                onDismiss = { activeDialog = TrackDialogType.NONE }
            )
        }
        TrackDialogType.VIDEO_QUALITY -> {
            TrackSelectionDialog(
                title = "Video Quality",
                emptyMessage = "Only single-bitrate video is available for this channel.",
                options = uiState.videoQualities,
                includeAutoOrOff = "Auto (Adaptive Bitrate)",
                isAutoOrOffSelected = uiState.videoQualities.none { it.isSelected } || uiState.videoQualities.size <= 1,
                onSelectAutoOrOff = {
                    onSelectVideoQuality(null)
                    activeDialog = TrackDialogType.NONE
                },
                onSelectOption = {
                    onSelectVideoQuality(it)
                    activeDialog = TrackDialogType.NONE
                },
                onDismiss = { activeDialog = TrackDialogType.NONE }
            )
        }
        TrackDialogType.NONE -> Unit
    }
}

@Composable
private fun HudCircleButton(
    onClick: () -> Unit,
    contentDescription: String,
    modifier: Modifier = Modifier,
    icon: @Composable () -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = palette.card.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, palette.border),
        modifier = modifier
            .size(54.dp)
            .clip(CircleShape)
    ) {
        Box(contentAlignment = Alignment.Center) {
            icon()
        }
    }
}

@Composable
private fun TrackSelectionDialog(
    title: String,
    emptyMessage: String,
    options: List<TrackOption>,
    includeAutoOrOff: String?,
    isAutoOrOffSelected: Boolean,
    onSelectAutoOrOff: () -> Unit,
    onSelectOption: (TrackOption) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.card,
        titleContentColor = palette.text,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (includeAutoOrOff != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onSelectAutoOrOff)
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isAutoOrOffSelected,
                            onClick = onSelectAutoOrOff,
                            colors = RadioButtonDefaults.colors(selectedColor = TerminalSecondary)
                        )
                        Text(includeAutoOrOff, color = palette.text)
                    }
                }
                if (options.isEmpty()) {
                    Text(emptyMessage, color = palette.textSecondary)
                } else {
                    options.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = option.isSupported) { onSelectOption(option) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = option.isSelected,
                                enabled = option.isSupported,
                                onClick = { onSelectOption(option) },
                                colors = RadioButtonDefaults.colors(selectedColor = TerminalPrimary)
                            )
                            Column(modifier = Modifier.padding(start = 6.dp)) {
                                Text(
                                    text = option.label,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (option.isSupported) palette.text else palette.textSecondary
                                )
                                Text(
                                    text = if (option.isSupported) option.subLabel else "${option.subLabel} (Unsupported)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TerminalSecondary)
            }
        }
    )
}
