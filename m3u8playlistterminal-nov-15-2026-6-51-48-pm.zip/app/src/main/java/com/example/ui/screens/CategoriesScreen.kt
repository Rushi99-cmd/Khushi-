package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Category
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.models.CategorySummary
import com.example.ui.components.ChannelLogoBadge
import com.example.ui.components.TvFocusableCard
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary

@Composable
fun CategoriesScreen(
    categories: List<CategorySummary>,
    onSelectCategory: (String) -> Unit
) {
    val palette = LocalTerminalPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "Channel Categories",
                style = MaterialTheme.typography.headlineMedium,
                color = palette.text
            )
            Text(
                text = "${categories.size} categories parsed from group-title metadata",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary
            )
        }

        if (categories.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.Category, null, tint = TerminalSecondary, modifier = Modifier.size(48.dp))
                    Text(
                        text = "No categories loaded yet",
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.text
                    )
                    Text(
                        text = "Sync a playlist to populate channel categories.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 240.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(categories, key = { it.name }) { category ->
                    TvFocusableCard(
                        onClick = { onSelectCategory(category.name) },
                        modifier = Modifier.testTag("category_card_${category.name}")
                    ) { isFocused ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            ChannelLogoBadge(
                                logoUrl = category.sampleLogoUrl,
                                channelName = category.name,
                                size = 50.dp
                            )
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = category.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.text,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    color = palette.elevated,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "${category.channelCount} channels",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isFocused) TerminalPrimary else TerminalSecondary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = if (isFocused) TerminalPrimary else palette.textSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
