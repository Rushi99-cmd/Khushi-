package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.models.Channel
import com.example.models.SearchScope
import com.example.ui.components.ChannelCard
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary

@Composable
fun SearchScreen(
    query: String,
    scope: SearchScope,
    results: List<Channel>,
    onQueryChange: (String) -> Unit,
    onScopeChange: (SearchScope) -> Unit,
    onClearSearch: () -> Unit,
    onBackToChannels: () -> Unit,
    onPlayChannel: (Channel, List<Channel>) -> Unit,
    onToggleFavourite: (String) -> Unit
) {
    val palette = LocalTerminalPalette.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Search Terminal",
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.text
                )
                Text(
                    text = "Search instantly by channel name, category, or playlist",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }
            NeonOutlinedButton(
                text = "Channel List",
                onClick = {
                    onClearSearch()
                    onBackToChannels()
                },
                leadingIcon = {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cd_back),
                        tint = TerminalSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            )
        }

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("Type channel name, category, playlist, or #number...") },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = TerminalPrimary) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = onClearSearch,
                        modifier = Modifier.testTag("clear_search_button")
                    ) {
                        Icon(Icons.Filled.Clear, stringResource(R.string.cd_clear_search))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = palette.card,
                unfocusedContainerColor = palette.card,
                focusedBorderColor = TerminalPrimary,
                unfocusedBorderColor = palette.border,
                focusedTextColor = palette.text,
                unfocusedTextColor = palette.text
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_query_input")
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(SearchScope.entries) { entry ->
                FilterChip(
                    selected = scope == entry,
                    onClick = { onScopeChange(entry) },
                    label = { Text(entry.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TerminalSecondary,
                        selectedLabelColor = Color(0xFF001824),
                        containerColor = palette.card,
                        labelColor = palette.text
                    )
                )
            }
        }

        when {
            query.isBlank() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Surface(
                        color = palette.card,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, palette.border)
                    ) {
                        Column(
                            modifier = Modifier.padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Search, null, tint = TerminalSecondary, modifier = Modifier.size(40.dp))
                            Text(
                                text = "Ready to Search",
                                style = MaterialTheme.typography.titleLarge,
                                color = palette.text
                            )
                            Text(
                                text = "Enter a query above to filter across all enabled playlists immediately.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = palette.textSecondary
                            )
                        }
                    }
                }
            }
            results.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "No results for \"$query\"",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.text
                        )
                        Text(
                            text = "Try switching search scope to All or clearing the filter.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textSecondary
                        )
                    }
                }
            }
            else -> {
                Text(
                    text = "${results.size} matching channel(s)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TerminalSecondary
                )
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(results, key = { it.id }) { channel ->
                        ChannelCard(
                            channel = channel,
                            onPlay = { onPlayChannel(channel, results) },
                            onToggleFavourite = { onToggleFavourite(channel.id) }
                        )
                    }
                }
            }
        }
    }
}
