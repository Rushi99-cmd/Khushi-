package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.models.ThemePreset

@Immutable
data class TerminalPalette(
    val background: Color,
    val card: Color,
    val elevated: Color,
    val primary: Color = TerminalPrimary,
    val secondary: Color = TerminalSecondary,
    val text: Color = TerminalText,
    val textSecondary: Color = TerminalTextSecondary,
    val border: Color = TerminalBorderSubtle
)

val LocalTerminalPalette = staticCompositionLocalOf {
    TerminalPalette(
        background = TerminalBackground,
        card = TerminalCard,
        elevated = TerminalElevated
    )
}

private val TerminalShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun M3U8TerminalTheme(
    themePreset: ThemePreset = ThemePreset.MIDNIGHT_NEON,
    content: @Composable () -> Unit
) {
    val palette = when (themePreset) {
        ThemePreset.MIDNIGHT_NEON -> TerminalPalette(
            background = TerminalBackground,
            card = TerminalCard,
            elevated = TerminalElevated
        )
        ThemePreset.CYBER_SLATE -> TerminalPalette(
            background = CyberSlateBackground,
            card = CyberSlateCard,
            elevated = CyberSlateElevated
        )
        ThemePreset.OLED_BLACK -> TerminalPalette(
            background = OledBlackBackground,
            card = OledBlackCard,
            elevated = OledBlackElevated
        )
    }

    val colorScheme = darkColorScheme(
        primary = palette.primary,
        onPrimary = Color(0xFF1B0010),
        primaryContainer = Color(0xFF471330),
        onPrimaryContainer = Color(0xFFFFD8E8),
        secondary = palette.secondary,
        onSecondary = Color(0xFF001D29),
        secondaryContainer = Color(0xFF0F364B),
        onSecondaryContainer = Color(0xFFC9EEFF),
        tertiary = Color(0xFF8A7BFF),
        onTertiary = Color.White,
        background = palette.background,
        onBackground = palette.text,
        surface = palette.card,
        onSurface = palette.text,
        surfaceVariant = palette.elevated,
        onSurfaceVariant = palette.textSecondary,
        surfaceContainerLowest = palette.background,
        surfaceContainerLow = palette.card,
        surfaceContainer = palette.card,
        surfaceContainerHigh = palette.elevated,
        surfaceContainerHighest = palette.elevated,
        outline = palette.border,
        outlineVariant = Color(0xFF1D2436),
        error = TerminalError,
        onError = Color.White
    )

    CompositionLocalProvider(LocalTerminalPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = TerminalShapes,
            content = content
        )
    }
}
