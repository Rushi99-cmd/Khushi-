package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.PlaylistPlay
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.models.Channel
import com.example.navigation.AppRoute
import com.example.navigation.SidebarDestination
import com.example.ui.components.BrandLogoMark
import com.example.ui.components.NumericChannelInputBanner
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AdminLoginScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.M3U8TerminalTheme
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import kotlinx.coroutines.delay

@Composable
fun M3U8TerminalApp(viewModel: MainViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val channels by viewModel.allChannels.collectAsStateWithLifecycle()
    val favourites by viewModel.favouriteChannels.collectAsStateWithLifecycle()
    val recent by viewModel.recentlyWatched.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val featured by viewModel.featuredChannel.collectAsStateWithLifecycle()
    val lastPlayed by viewModel.lastPlayedChannel.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchScope by viewModel.searchScope.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val playerUiState by viewModel.playerUiState.collectAsStateWithLifecycle()
    val actionBanner by viewModel.actionBanner.collectAsStateWithLifecycle()
    val numericEntry by viewModel.numericEntry.collectAsStateWithLifecycle()
    val adminSession by viewModel.adminSession.collectAsStateWithLifecycle()
    val adminDashboardState by viewModel.adminDashboardState.collectAsStateWithLifecycle()

    M3U8TerminalTheme(themePreset = settings.themePreset) {
        val palette = LocalTerminalPalette.current
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination
        val snackbarHostState = remember { SnackbarHostState() }

        val startDestination: AppRoute = remember(settings.hasCompletedWelcome) {
            if (settings.hasCompletedWelcome) AppRoute.Home else AppRoute.Welcome
        }

        val isChromeVisible = currentDestination != null &&
            !currentDestination.hasRoute<AppRoute.Welcome>() &&
            !currentDestination.hasRoute<AppRoute.Player>() &&
            !currentDestination.hasRoute<AppRoute.AdminLogin>() &&
            !currentDestination.hasRoute<AppRoute.AdminDashboard>()

        fun openPlayer(channel: Channel, queue: List<Channel> = channels) {
            viewModel.playChannel(channel, queue)
            navController.navigate(AppRoute.Player(channel.id)) {
                launchSingleTop = true
            }
        }

        fun navigateToSidebar(dest: SidebarDestination) {
            val route: AppRoute = when (dest) {
                SidebarDestination.HOME -> AppRoute.Home
                SidebarDestination.LIVE_TV -> AppRoute.LiveTv(selectedCategory)
                SidebarDestination.CATEGORIES -> AppRoute.Categories
                SidebarDestination.PLAYLISTS -> AppRoute.Playlists
                SidebarDestination.SEARCH -> AppRoute.Search
                SidebarDestination.SETTINGS -> AppRoute.Settings
            }
            navController.navigate(route) {
                popUpTo<AppRoute.Home> { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }

        LaunchedEffect(actionBanner) {
            val msg = actionBanner
            if (msg != null) {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearActionBanner()
            }
        }

        // Auto-commit TV remote numeric entry after 1.6s pause
        LaunchedEffect(numericEntry) {
            if (numericEntry.isNotEmpty()) {
                delay(1_600L)
                viewModel.commitNumericEntry { matched ->
                    openPlayer(matched, channels)
                }
            }
        }

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.background)
                .onPreviewKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown) {
                        val digit = keyToDigitChar(event.key)
                        if (digit != null) {
                            viewModel.appendNumericDigit(digit) { matched ->
                                openPlayer(matched, channels)
                            }
                            true
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }
        ) {
            val useSidebarRail = maxWidth >= 680.dp

            Scaffold(
                containerColor = palette.background,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    if (isChromeVisible && !useSidebarRail) {
                        TerminalBottomBar(
                            currentRouteCheck = { dest -> isDestinationActive(currentDestination, dest) },
                            onSelect = ::navigateToSidebar
                        )
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            bottom = if (isChromeVisible && !useSidebarRail) innerPadding.calculateBottomPadding() else 0.dp
                        )
                ) {
                    if (isChromeVisible && useSidebarRail) {
                        TerminalSidebarRail(
                            currentRouteCheck = { dest -> isDestinationActive(currentDestination, dest) },
                            onSelect = ::navigateToSidebar
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .let { mod ->
                                if (isChromeVisible) mod.windowInsetsPadding(WindowInsets.safeDrawing)
                                else mod
                            }
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            if (isChromeVisible && settings.maintenanceMessage.isNotBlank()) {
                                Surface(
                                    color = TerminalSecondary.copy(alpha = 0.14f),
                                    border = BorderStroke(1.dp, TerminalSecondary.copy(alpha = 0.5f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = settings.maintenanceMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = palette.text,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                NavHost(
                                    navController = navController,
                                    startDestination = startDestination
                                ) {
                            composable<AppRoute.Welcome> {
                                WelcomeScreen(
                                    onContinue = {
                                        viewModel.completeWelcome()
                                        navController.navigate(AppRoute.Home) {
                                            popUpTo<AppRoute.Welcome> { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable<AppRoute.Home> {
                                HomeScreen(
                                    channels = channels,
                                    playlists = playlists,
                                    featuredChannel = featured,
                                    lastPlayedChannel = lastPlayed,
                                    recentlyWatched = recent,
                                    favouriteChannels = favourites,
                                    categories = categories,
                                    syncState = syncState,
                                    onRefresh = { viewModel.refreshAllPlaylists() },
                                    onPlayChannel = ::openPlayer,
                                    onToggleFavourite = { viewModel.toggleFavourite(it) },
                                    onOpenCategory = { cat ->
                                        viewModel.selectCategory(cat)
                                        navController.navigate(AppRoute.LiveTv(cat)) {
                                            launchSingleTop = true
                                        }
                                    },
                                    onNavigateToPlaylists = { navigateToSidebar(SidebarDestination.PLAYLISTS) },
                                    onNavigateToLiveTv = { navigateToSidebar(SidebarDestination.LIVE_TV) }
                                )
                            }

                            composable<AppRoute.LiveTv> { entry ->
                                val args = entry.toRoute<AppRoute.LiveTv>()
                                LaunchedEffect(args.initialCategory) {
                                    if (!args.initialCategory.isNullOrBlank()) {
                                        viewModel.selectCategory(args.initialCategory)
                                    }
                                }
                                LiveTvScreen(
                                    channels = channels,
                                    categories = categories,
                                    selectedCategory = selectedCategory,
                                    lastPlayedChannel = lastPlayed,
                                    syncState = syncState,
                                    onSelectCategory = { viewModel.selectCategory(it) },
                                    onPlayChannel = ::openPlayer,
                                    onToggleFavourite = { viewModel.toggleFavourite(it) },
                                    onJumpToChannelNumber = { number ->
                                        val match = viewModel.jumpToChannelNumber(number)
                                        if (match != null) openPlayer(match, channels)
                                        match
                                    },
                                    onRefresh = { viewModel.refreshAllPlaylists() }
                                )
                            }

                            composable<AppRoute.Categories> {
                                CategoriesScreen(
                                    categories = categories,
                                    onSelectCategory = { categoryName ->
                                        viewModel.selectCategory(categoryName)
                                        navController.navigate(AppRoute.LiveTv(categoryName)) {
                                            launchSingleTop = true
                                        }
                                    }
                                )
                            }

                            composable<AppRoute.Playlists> {
                                PlaylistsScreen(
                                    playlists = playlists,
                                    onAddRemotePlaylist = viewModel::addRemotePlaylist,
                                    onImportLocalPlaylist = viewModel::importLocalPlaylist,
                                    onUpdatePlaylist = viewModel::updatePlaylistDetails,
                                    onToggleEnabled = viewModel::togglePlaylistEnabled,
                                    onSetDefault = viewModel::setDefaultPlaylist,
                                    onRefreshPlaylist = viewModel::refreshSinglePlaylist,
                                    onRefreshAll = viewModel::refreshAllPlaylists,
                                    onDeletePlaylist = viewModel::deletePlaylist
                                )
                            }

                            composable<AppRoute.Search> {
                                SearchScreen(
                                    query = searchQuery,
                                    scope = searchScope,
                                    results = searchResults,
                                    onQueryChange = viewModel::updateSearchQuery,
                                    onScopeChange = viewModel::updateSearchScope,
                                    onClearSearch = viewModel::clearSearch,
                                    onBackToChannels = {
                                        navigateToSidebar(SidebarDestination.LIVE_TV)
                                    },
                                    onPlayChannel = ::openPlayer,
                                    onToggleFavourite = { viewModel.toggleFavourite(it) }
                                )
                            }

                            composable<AppRoute.Settings> {
                                SettingsScreen(
                                    settings = settings,
                                    playlists = playlists,
                                    onSelectTheme = viewModel::setThemePreset,
                                    onSelectDefaultPlaylist = viewModel::setDefaultPlaylist,
                                    onToggleAutoRefresh = viewModel::setAutoRefreshEnabled,
                                    onSelectRefreshInterval = viewModel::setRefreshInterval,
                                    onSelectDefaultAspectRatio = viewModel::setDefaultAspectRatio,
                                    onSelectBufferProfile = viewModel::setBufferProfile,
                                    onUpdateCustomUserAgent = viewModel::setCustomUserAgent,
                                    onUpdateBackendUrl = viewModel::setBackendServerUrl,
                                    onToggleAnalytics = viewModel::setAnalyticsEnabled,
                                    onOpenAdminConsole = {
                                        val active = adminSession
                                        if (active != null && !active.isExpired()) {
                                            navController.navigate(AppRoute.AdminDashboard)
                                        } else {
                                            navController.navigate(AppRoute.AdminLogin)
                                        }
                                    },
                                    onClearCache = viewModel::clearCachedPlaylistData
                                )
                            }

                            composable<AppRoute.AdminLogin> {
                                AdminLoginScreen(
                                    initialServerUrl = settings.backendServerUrl,
                                    onLogin = { serverUrl, username, password, onResult ->
                                        viewModel.loginAsOwner(serverUrl, username, password) { result ->
                                            onResult(result)
                                            if (result.isSuccess) {
                                                navController.navigate(AppRoute.AdminDashboard) {
                                                    popUpTo<AppRoute.AdminLogin> { inclusive = true }
                                                }
                                            }
                                        }
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable<AppRoute.AdminDashboard> {
                                val currentAdmin = adminSession
                                if (currentAdmin == null || currentAdmin.isExpired()) {
                                    LaunchedEffect(currentAdmin) {
                                        navController.navigate(AppRoute.AdminLogin) {
                                            popUpTo<AppRoute.AdminDashboard> { inclusive = true }
                                        }
                                    }
                                } else {
                                    AdminDashboardScreen(
                                        session = currentAdmin,
                                        state = adminDashboardState,
                                        onRefresh = viewModel::refreshAdminDashboard,
                                        onSignOut = {
                                            viewModel.logoutAdmin()
                                            navController.popBackStack()
                                        },
                                        onBack = { navController.popBackStack() },
                                        onAddSource = viewModel::adminAddSource,
                                        onUpdateSource = viewModel::adminUpdateSource,
                                        onDeleteSource = viewModel::adminDeleteSource,
                                        onActivatePrimary = viewModel::adminActivatePrimarySource,
                                        onRefreshSource = viewModel::adminRefreshSource,
                                        onUpdateChannel = viewModel::adminUpdateChannel,
                                        onPushConfig = viewModel::adminPushConfig
                                    )
                                }
                            }

                            composable<AppRoute.Player> { entry ->
                                val args = entry.toRoute<AppRoute.Player>()
                                LaunchedEffect(args.channelId) {
                                    viewModel.playChannelById(args.channelId)
                                }
                                PlayerScreen(
                                    player = viewModel.getExoPlayer(),
                                    uiState = playerUiState,
                                    onBack = {
                                        viewModel.saveCurrentWatchProgressAndPause()
                                        navController.popBackStack()
                                    },
                                    onTogglePlayPause = viewModel::togglePlayPause,
                                    onSeekBy = viewModel::seekBy,
                                    onSeekTo = viewModel::seekTo,
                                    onPreviousChannel = { viewModel.playPreviousChannel() },
                                    onNextChannel = { viewModel.playNextChannel() },
                                    onSelectChannel = { ch -> openPlayer(ch, playerUiState.channelQueue) },
                                    onToggleFavourite = viewModel::toggleFavourite,
                                    onToggleMute = viewModel::toggleMute,
                                    onSetVolume = viewModel::setVolume,
                                    onSetAspectRatio = viewModel::setAspectRatio,
                                    onSetFullscreen = viewModel::setFullscreen,
                                    onSelectAudioTrack = viewModel::selectAudioTrack,
                                    onSelectSubtitleTrack = viewModel::selectSubtitleTrack,
                                    onSelectVideoQuality = viewModel::selectVideoQuality,
                                    onRetry = viewModel::retryPlayback
                                )
                            }
                                }
                            }
                        }

                        NumericChannelInputBanner(
                            digits = numericEntry,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalSidebarRail(
    currentRouteCheck: (SidebarDestination) -> Boolean,
    onSelect: (SidebarDestination) -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.card,
        border = BorderStroke(1.dp, palette.border),
        modifier = Modifier.fillMaxHeight()
    ) {
        NavigationRail(
            containerColor = palette.card,
            header = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                ) {
                    BrandLogoMark(size = 42.dp)
                    Text(
                        text = "TERMINAL",
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalPrimary
                    )
                }
            },
            modifier = Modifier
                .width(100.dp)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Spacer(modifier = Modifier.height(6.dp))
            SidebarDestination.entries.forEach { dest ->
                val selected = currentRouteCheck(dest)
                NavigationRailItem(
                    selected = selected,
                    onClick = { onSelect(dest) },
                    icon = {
                        Icon(
                            imageVector = iconForDestination(dest, selected),
                            contentDescription = dest.label
                        )
                    },
                    label = {
                        Text(
                            text = dest.label,
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = NavigationRailItemDefaults.colors(
                        selectedIconColor = TerminalPrimary,
                        selectedTextColor = Color.White,
                        indicatorColor = TerminalPrimary.copy(alpha = 0.18f),
                        unselectedIconColor = palette.textSecondary,
                        unselectedTextColor = palette.textSecondary
                    ),
                    modifier = Modifier.testTag(dest.testTag)
                )
            }
        }
    }
}

@Composable
private fun TerminalBottomBar(
    currentRouteCheck: (SidebarDestination) -> Boolean,
    onSelect: (SidebarDestination) -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.card,
        border = BorderStroke(1.dp, palette.border),
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
    ) {
        NavigationBar(
            containerColor = palette.card,
            windowInsets = WindowInsets.navigationBars
        ) {
            SidebarDestination.entries.forEach { dest ->
                val selected = currentRouteCheck(dest)
                NavigationBarItem(
                    selected = selected,
                    onClick = { onSelect(dest) },
                    icon = {
                        Icon(
                            imageVector = iconForDestination(dest, selected),
                            contentDescription = dest.label
                        )
                    },
                    label = {
                        Text(
                            text = dest.label,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TerminalPrimary,
                        selectedTextColor = Color.White,
                        indicatorColor = TerminalPrimary.copy(alpha = 0.18f),
                        unselectedIconColor = palette.textSecondary,
                        unselectedTextColor = palette.textSecondary
                    ),
                    modifier = Modifier.testTag(dest.testTag)
                )
            }
        }
    }
}

private fun iconForDestination(dest: SidebarDestination, selected: Boolean): ImageVector {
    return when (dest) {
        SidebarDestination.HOME -> if (selected) Icons.Filled.Home else Icons.Outlined.Home
        SidebarDestination.LIVE_TV -> if (selected) Icons.Filled.LiveTv else Icons.Outlined.LiveTv
        SidebarDestination.CATEGORIES -> if (selected) Icons.Filled.Category else Icons.Outlined.Category
        SidebarDestination.PLAYLISTS -> if (selected) Icons.Filled.PlaylistPlay else Icons.Outlined.PlaylistPlay
        SidebarDestination.SEARCH -> if (selected) Icons.Filled.Search else Icons.Outlined.Search
        SidebarDestination.SETTINGS -> if (selected) Icons.Filled.Settings else Icons.Outlined.Settings
    }
}

private fun isDestinationActive(
    destination: androidx.navigation.NavDestination?,
    sidebarDestination: SidebarDestination
): Boolean {
    if (destination == null) return false
    return when (sidebarDestination) {
        SidebarDestination.HOME -> destination.hasRoute<AppRoute.Home>()
        SidebarDestination.LIVE_TV -> destination.hasRoute<AppRoute.LiveTv>()
        SidebarDestination.CATEGORIES -> destination.hasRoute<AppRoute.Categories>()
        SidebarDestination.PLAYLISTS -> destination.hasRoute<AppRoute.Playlists>()
        SidebarDestination.SEARCH -> destination.hasRoute<AppRoute.Search>()
        SidebarDestination.SETTINGS -> destination.hasRoute<AppRoute.Settings>()
    }
}

private fun keyToDigitChar(key: Key): Char? {
    return when (key) {
        Key.Zero, Key.NumPad0 -> '0'
        Key.One, Key.NumPad1 -> '1'
        Key.Two, Key.NumPad2 -> '2'
        Key.Three, Key.NumPad3 -> '3'
        Key.Four, Key.NumPad4 -> '4'
        Key.Five, Key.NumPad5 -> '5'
        Key.Six, Key.NumPad6 -> '6'
        Key.Seven, Key.NumPad7 -> '7'
        Key.Eight, Key.NumPad8 -> '8'
        Key.Nine, Key.NumPad9 -> '9'
        else -> null
    }
}
