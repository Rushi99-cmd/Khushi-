package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.BrandLogoMark
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.NeonAccentGradient
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.utils.AppConstants

@Composable
fun WelcomeScreen(
    onContinue: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalTerminalPalette.current
    val continueFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        runCatching { continueFocusRequester.requestFocus() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_hero_terminal_1794745150380),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.32f)
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            palette.background.copy(alpha = 0.65f),
                            palette.background.copy(alpha = 0.92f),
                            palette.background
                        )
                    )
                )
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                color = palette.card.copy(alpha = 0.92f),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.5.dp, NeonAccentGradient),
                tonalElevation = 8.dp,
                modifier = Modifier.widthIn(max = 680.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        BrandLogoMark(size = 64.dp)
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "M3U8PLAYLIST",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "TERMINAL",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = TerminalPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "ANDROID TV • GOOGLE TV • MOBILE",
                                style = MaterialTheme.typography.labelSmall,
                                color = TerminalSecondary
                            )
                        }
                    }

                    Text(
                        text = stringResource(R.string.welcome_title),
                        style = MaterialTheme.typography.displayMedium,
                        color = palette.text
                    )

                    Text(
                        text = stringResource(R.string.welcome_subtitle),
                        style = MaterialTheme.typography.bodyLarge,
                        color = palette.textSecondary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WelcomeFeaturePill(
                            icon = { Icon(Icons.Filled.LiveTv, null, tint = TerminalPrimary, modifier = Modifier.size(18.dp)) },
                            title = "HLS & DASH",
                            subtitle = "Media3 ExoPlayer",
                            modifier = Modifier.weight(1f)
                        )
                        WelcomeFeaturePill(
                            icon = { Icon(Icons.Filled.PlaylistPlay, null, tint = TerminalSecondary, modifier = Modifier.size(18.dp)) },
                            title = "Multi-Playlist",
                            subtitle = "URL & Local M3U",
                            modifier = Modifier.weight(1f)
                        )
                        WelcomeFeaturePill(
                            icon = { Icon(Icons.Filled.Tv, null, tint = Color.White, modifier = Modifier.size(18.dp)) },
                            title = "TV Remote",
                            subtitle = "D-Pad & Zapping",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text(
                        text = "Privacy Notice: Anonymous playback analytics (session UUID, active channel, device type & errors) may be collected if connected to a backend server. Local playlists never leave your device, and analytics can be turned off in Settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NeonOutlinedButton(
                            text = stringResource(R.string.join_telegram),
                            onClick = {
                                val intent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse(AppConstants.TELEGRAM_INVITE_URL)
                                ).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                try {
                                    context.startActivity(intent)
                                } catch (_: ActivityNotFoundException) {
                                    Toast.makeText(
                                        context,
                                        "No browser or Telegram app found to open link.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = null,
                                    tint = TerminalSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            modifier = Modifier.testTag("join_telegram_button")
                        )

                        NeonGradientButton(
                            text = stringResource(R.string.continue_to_app),
                            onClick = onContinue,
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            modifier = Modifier
                                .focusRequester(continueFocusRequester)
                                .testTag("continue_button")
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WelcomeFeaturePill(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.elevated.copy(alpha = 0.85f),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, palette.border),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            icon()
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = palette.text,
                maxLines = 1
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
                maxLines = 1
            )
        }
    }
}
