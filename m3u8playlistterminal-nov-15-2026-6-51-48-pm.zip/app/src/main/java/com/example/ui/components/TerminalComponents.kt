package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.models.Channel
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.NeonAccentGradient
import com.example.ui.theme.NeonHorizontalGradient
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.utils.ChannelLogoLoader
import com.example.utils.Formatters

@Composable
fun BrandLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .border(1.5.dp, NeonAccentGradient, RoundedCornerShape(12.dp))
            .background(LocalTerminalPalette.current.elevated),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_launcher_foreground_1794745151152),
            contentDescription = stringResource(R.string.cd_app_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun BrandWordmark(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        BrandLogoMark(size = 38.dp)
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "M3U8PLAYLIST",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1
                )
                Text(
                    text = "TERMINAL",
                    style = MaterialTheme.typography.titleLarge,
                    color = TerminalPrimary,
                    maxLines = 1
                )
            }
            Text(
                text = "TV & STREAM ENGINE",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalSecondary
            )
        }
    }
}

@Composable
fun NeonGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: @Composable (() -> Unit)? = null,
    enabled: Boolean = true
) {
    var isFocused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.04f else 1f,
        animationSpec = spring(stiffness = 500f),
        label = "btnScale"
    )
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            contentColor = Color.White,
            disabledContainerColor = Color(0xFF283044),
            disabledContentColor = Color(0xFF7B879D)
        ),
        contentPadding = PaddingValues(0.dp),
        shape = RoundedCornerShape(14.dp),
        border = if (isFocused) BorderStroke(2.dp, Color.White) else null,
        modifier = modifier
            .scale(scale)
            .minimumInteractiveComponentSize()
            .onFocusChanged { isFocused = it.isFocused }
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = if (enabled) NeonHorizontalGradient else Brush.horizontalGradient(
                        listOf(Color(0xFF283044), Color(0xFF283044))
                    ),
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 22.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (leadingIcon != null) leadingIcon()
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun NeonOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: @Composable (() -> Unit)? = null
) {
    var isFocused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.04f else 1f,
        animationSpec = spring(stiffness = 500f),
        label = "outlineBtnScale"
    )
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            width = if (isFocused) 2.dp else 1.5.dp,
            brush = if (isFocused) NeonAccentGradient else Brush.horizontalGradient(
                listOf(TerminalSecondary.copy(alpha = 0.7f), TerminalPrimary.copy(alpha = 0.7f))
            )
        ),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = if (isFocused) LocalTerminalPalette.current.elevated else Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = modifier
            .scale(scale)
            .minimumInteractiveComponentSize()
            .onFocusChanged { isFocused = it.isFocused }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (leadingIcon != null) leadingIcon()
            Text(text = text, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun BroadcastPulseLoader(
    label: String,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "pulseLoader")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringAngle"
    )
    val pulseAlpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(modifier = Modifier.size(64.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = TerminalSecondary.copy(alpha = 0.18f),
                    style = Stroke(width = 5.dp.toPx())
                )
                rotate(angle) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(
                                Color.Transparent,
                                TerminalSecondary,
                                TerminalPrimary,
                                Color.Transparent
                            )
                        ),
                        startAngle = 0f,
                        sweepAngle = 250f,
                        useCenter = false,
                        style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            Icon(
                imageVector = Icons.Filled.LiveTv,
                contentDescription = null,
                tint = TerminalPrimary.copy(alpha = pulseAlpha),
                modifier = Modifier.size(24.dp)
            )
        }
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = LocalTerminalPalette.current.textSecondary
        )
    }
}

@Composable
fun TvFocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(16.dp),
    containerColor: Color = LocalTerminalPalette.current.card,
    content: @Composable (isFocused: Boolean) -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.035f else 1f,
        animationSpec = spring(stiffness = 480f),
        label = "cardFocusScale"
    )
    val animatedBg by animateColorAsState(
        targetValue = if (isFocused) LocalTerminalPalette.current.elevated else containerColor,
        animationSpec = tween(150),
        label = "cardFocusBg"
    )

    Surface(
        modifier = modifier
            .scale(scale)
            .clip(shape)
            .onFocusChanged { isFocused = it.isFocused }
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyUp &&
                    (event.key == Key.DirectionCenter || event.key == Key.Enter || event.key == Key.NumPadEnter)
                ) {
                    onClick()
                    true
                } else {
                    false
                }
            }
            .focusable()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = androidx.compose.material3.ripple(),
                onClick = onClick
            ),
        shape = shape,
        color = animatedBg,
        border = if (isFocused) {
            BorderStroke(2.2.dp, NeonAccentGradient)
        } else {
            BorderStroke(1.dp, LocalTerminalPalette.current.border)
        },
        tonalElevation = if (isFocused) 8.dp else 2.dp
    ) {
        content(isFocused)
    }
}

@Composable
fun ChannelLogoBadge(
    logoUrl: String?,
    channelName: String,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp
) {
    val context = LocalContext.current
    val imageLoader = remember(context) { ChannelLogoLoader.get(context) }
    val initials = remember(channelName) {
        channelName.trim()
            .split(" ")
            .filter { it.isNotBlank() }
            .take(2)
            .joinToString("") { it.first().uppercaseChar().toString() }
            .ifEmpty { "TV" }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(LocalTerminalPalette.current.elevated)
            .border(1.dp, LocalTerminalPalette.current.border, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials,
            style = MaterialTheme.typography.titleMedium,
            color = TerminalSecondary,
            fontWeight = FontWeight.Bold
        )
        if (!logoUrl.isNullOrBlank()) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(logoUrl)
                    .size(160) // Cap decoded bitmap dimensions for low-memory TV boxes
                    .crossfade(true)
                    .build(),
                imageLoader = imageLoader,
                contentDescription = stringResource(R.string.cd_channel_logo),
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(6.dp)
            )
        }
    }
}

@Composable
fun ChannelCard(
    channel: Channel,
    onPlay: () -> Unit,
    onToggleFavourite: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val palette = LocalTerminalPalette.current
    TvFocusableCard(
        onClick = onPlay,
        modifier = modifier.testTag("channel_card_${channel.id}")
    ) { isFocused ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(if (compact) 12.dp else 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ChannelLogoBadge(
                logoUrl = channel.logoUrl,
                channelName = channel.name,
                size = if (compact) 48.dp else 56.dp
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = if (isFocused) TerminalPrimary.copy(alpha = 0.22f) else palette.elevated,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = Formatters.formatChannelNumber(channel.channelNumber),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isFocused) TerminalPrimary else TerminalSecondary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = channel.groupTitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = channel.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = channel.playlistName,
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.textSecondary.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onToggleFavourite,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("fav_button_${channel.id}")
            ) {
                Icon(
                    imageVector = if (channel.isFavourite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = stringResource(R.string.cd_favourite),
                    tint = if (channel.isFavourite) TerminalPrimary else palette.textSecondary
                )
            }

            if (isFocused) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(NeonAccentGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun NumericChannelInputBanner(
    digits: String,
    modifier: Modifier = Modifier
) {
    if (digits.isEmpty()) return
    Surface(
        modifier = modifier,
        color = LocalTerminalPalette.current.elevated.copy(alpha = 0.96f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(2.dp, NeonAccentGradient),
        shadowElevation = 12.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CHANNEL ZAP",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalSecondary
            )
            Text(
                text = digits.padEnd(3, '_'),
                style = MaterialTheme.typography.displayMedium,
                color = Color.White
            )
        }
    }
}

@Composable
fun ChannelNumberKeypadDialog(
    onDismiss: () -> Unit,
    onTuneNumber: (Int) -> Unit
) {
    var input by remember { mutableStateOf("") }
    val palette = LocalTerminalPalette.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.card,
        titleContentColor = palette.text,
        title = {
            Text(text = "Jump to Channel Number", style = MaterialTheme.typography.titleLarge)
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    color = palette.elevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, NeonHorizontalGradient),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (input.isEmpty()) "Enter channel #" else "#$input",
                        style = MaterialTheme.typography.headlineMedium,
                        color = if (input.isEmpty()) palette.textSecondary else Color.White,
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp)
                    )
                }

                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("CLR", "0", "DEL")
                )
                rows.forEach { row ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        row.forEach { key ->
                            Surface(
                                onClick = {
                                    when (key) {
                                        "CLR" -> input = ""
                                        "DEL" -> input = input.dropLast(1)
                                        else -> if (input.length < 4) input += key
                                    }
                                },
                                color = palette.elevated,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, palette.border),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = key,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (key == "CLR" || key == "DEL") TerminalSecondary else Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            NeonGradientButton(
                text = "Tune",
                enabled = input.toIntOrNull() != null,
                onClick = {
                    input.toIntOrNull()?.let { num ->
                        onTuneNumber(num)
                        onDismiss()
                    }
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}
