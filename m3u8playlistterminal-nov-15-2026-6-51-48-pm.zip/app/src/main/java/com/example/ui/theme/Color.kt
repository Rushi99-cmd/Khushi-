package com.example.ui.theme

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Core Brand Palette
val TerminalBackground = Color(0xFF07090F)
val TerminalCard = Color(0xFF111621)
val TerminalElevated = Color(0xFF171D2B)
val TerminalPrimary = Color(0xFFFF4FA3)
val TerminalSecondary = Color(0xFF40BFFF)
val TerminalText = Color(0xFFFFFFFF)
val TerminalTextSecondary = Color(0xFFAAB4C5)

// Alternate Dark Presets
val CyberSlateBackground = Color(0xFF0B101A)
val CyberSlateCard = Color(0xFF151D2C)
val CyberSlateElevated = Color(0xFF1E283D)

val OledBlackBackground = Color(0xFF000000)
val OledBlackCard = Color(0xFF0B0E14)
val OledBlackElevated = Color(0xFF141923)

// Semantic Status Colors
val TerminalSuccess = Color(0xFF2EE59D)
val TerminalWarning = Color(0xFFFFB84D)
val TerminalError = Color(0xFFFF5A79)
val TerminalBorderSubtle = Color(0xFF232C3F)

val NeonAccentGradient = Brush.linearGradient(
    colors = listOf(TerminalPrimary, TerminalSecondary),
    start = Offset(0f, 0f),
    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
)

val NeonHorizontalGradient = Brush.horizontalGradient(
    colors = listOf(TerminalPrimary, TerminalSecondary)
)

val HeroScrimGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0x3307090F),
        Color(0xCC07090F),
        Color(0xFF07090F)
    )
)
