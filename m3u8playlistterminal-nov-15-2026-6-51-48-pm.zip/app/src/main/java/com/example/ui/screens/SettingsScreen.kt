package com.example.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.clickable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.models.AspectRatioMode
import com.example.models.BufferProfile
import com.example.models.PlaylistSource
import com.example.models.RefreshInterval
import com.example.models.ThemePreset
import com.example.models.UserSettings
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.TerminalError
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.utils.AppConstants

@Composable
fun SettingsScreen(
    settings: UserSettings,
    playlists: List<PlaylistSource>,
    onSelectTheme: (ThemePreset) -> Unit,
    onSelectDefaultPlaylist: (String) -> Unit,
    onToggleAutoRefresh: (Boolean) -> Unit,
    onSelectRefreshInterval: (RefreshInterval) -> Unit,
    onSelectDefaultAspectRatio: (AspectRatioMode) -> Unit,
    onSelectBufferProfile: (BufferProfile) -> Unit,
    onUpdateCustomUserAgent: (String) -> Unit,
    onUpdateBackendUrl: (String) -> Unit,
    onToggleAnalytics: (Boolean) -> Unit,
    onOpenAdminConsole: () -> Unit,
    onClearCache: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalTerminalPalette.current
    var showClearCacheConfirm by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var userAgentDraft by remember(settings.customUserAgent) { mutableStateOf(settings.customUserAgent) }
    var backendUrlDraft by remember(settings.backendServerUrl) { mutableStateOf(settings.backendServerUrl) }
    var versionTapCount by remember { mutableIntStateOf(0) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.text
                )
                Text(
                    text = "Customize theme, playlist sync, Media3 player tuning, and device storage",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }
        }

        // Theme Preferences
        item {
            SettingsSectionCard(
                title = "Theme Preferences",
                icon = { Icon(Icons.Filled.Palette, null, tint = TerminalPrimary) }
            ) {
                ThemePreset.entries.forEach { preset ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.themePreset == preset,
                            onClick = { onSelectTheme(preset) },
                            colors = RadioButtonDefaults.colors(selectedColor = TerminalPrimary)
                        )
                        Column(modifier = Modifier.padding(start = 6.dp)) {
                            Text(preset.label, style = MaterialTheme.typography.titleSmall, color = palette.text)
                            Text(preset.subtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                    }
                }
            }
        }

        // Default Playlist
        item {
            SettingsSectionCard(
                title = "Default Playlist",
                icon = { Icon(Icons.Filled.PlaylistPlay, null, tint = TerminalSecondary) }
            ) {
                if (playlists.isEmpty()) {
                    Text("No playlists configured.", color = palette.textSecondary)
                } else {
                    playlists.forEach { playlist ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = playlist.isDefault,
                                onClick = { onSelectDefaultPlaylist(playlist.id) },
                                colors = RadioButtonDefaults.colors(selectedColor = TerminalSecondary)
                            )
                            Column(modifier = Modifier.padding(start = 6.dp)) {
                                Text(playlist.name, style = MaterialTheme.typography.titleSmall, color = palette.text)
                                Text(
                                    "${playlist.channelCount} channels • ${playlist.type.label}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Automatic Playlist Refresh
        item {
            SettingsSectionCard(
                title = "Automatic Playlist Refresh",
                icon = { Icon(Icons.Filled.Refresh, null, tint = TerminalSecondary) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Automatic Sync", style = MaterialTheme.typography.titleSmall, color = palette.text)
                        Text(
                            "Automatically update active M3U/M3U8 playlists in the background",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    Switch(
                        checked = settings.autoRefreshEnabled,
                        onCheckedChange = onToggleAutoRefresh,
                        colors = SwitchDefaults.colors(checkedTrackColor = TerminalPrimary)
                    )
                }

                if (settings.autoRefreshEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RefreshInterval.entries.take(3).forEach { interval ->
                            FilterChip(
                                selected = settings.refreshInterval == interval,
                                onClick = { onSelectRefreshInterval(interval) },
                                label = { Text(interval.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TerminalSecondary,
                                    selectedLabelColor = Color(0xFF001824)
                                )
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RefreshInterval.entries.drop(3).forEach { interval ->
                            FilterChip(
                                selected = settings.refreshInterval == interval,
                                onClick = { onSelectRefreshInterval(interval) },
                                label = { Text(interval.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TerminalSecondary,
                                    selectedLabelColor = Color(0xFF001824)
                                )
                            )
                        }
                    }
                }
            }
        }

        // Default Video Aspect Ratio
        item {
            SettingsSectionCard(
                title = "Default Video Aspect Ratio",
                icon = { Icon(Icons.Filled.AspectRatio, null, tint = TerminalPrimary) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AspectRatioMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.defaultAspectRatio == mode,
                            onClick = { onSelectDefaultAspectRatio(mode) },
                            label = { Text(mode.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TerminalPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Player Settings
        item {
            SettingsSectionCard(
                title = "Player Settings (Media3 ExoPlayer)",
                icon = { Icon(Icons.Filled.Tune, null, tint = TerminalSecondary) }
            ) {
                Text("Buffer & Network Profile", style = MaterialTheme.typography.titleSmall, color = palette.text)
                BufferProfile.entries.forEach { profile ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = settings.bufferProfile == profile,
                            onClick = { onSelectBufferProfile(profile) },
                            colors = RadioButtonDefaults.colors(selectedColor = TerminalPrimary)
                        )
                        Column(modifier = Modifier.padding(start = 6.dp)) {
                            Text(profile.label, style = MaterialTheme.typography.titleSmall, color = palette.text)
                            Text(profile.description, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                        }
                    }
                }

                OutlinedTextField(
                    value = userAgentDraft,
                    onValueChange = { userAgentDraft = it },
                    label = { Text("Custom HTTP User-Agent (Optional)") },
                    placeholder = { Text(AppConstants.DEFAULT_USER_AGENT) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalSecondary,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.text,
                        unfocusedTextColor = palette.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                NeonOutlinedButton(
                    text = "Save User-Agent",
                    onClick = { onUpdateCustomUserAgent(userAgentDraft) }
                )
            }
        }

        // Community, Cache & Privacy
        item {
            SettingsSectionCard(
                title = "Storage, Community & Privacy",
                icon = { Icon(Icons.Filled.Security, null, tint = TerminalPrimary) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    NeonOutlinedButton(
                        text = "Join Telegram",
                        onClick = {
                            val intent = Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(AppConstants.TELEGRAM_INVITE_URL)
                            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                            try {
                                context.startActivity(intent)
                            } catch (_: ActivityNotFoundException) {
                                Toast.makeText(context, "Unable to open Telegram link.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        leadingIcon = {
                            Icon(Icons.AutoMirrored.Filled.Send, null, tint = TerminalSecondary, modifier = Modifier.size(18.dp))
                        }
                    )

                    NeonOutlinedButton(
                        text = "Privacy Info",
                        onClick = { showPrivacyDialog = true },
                        leadingIcon = {
                            Icon(Icons.Filled.Security, null, tint = TerminalPrimary, modifier = Modifier.size(18.dp))
                        }
                    )
                }

                NeonOutlinedButton(
                    text = "Clear Cached Playlist Data",
                    onClick = { showClearCacheConfirm = true },
                    leadingIcon = {
                        Icon(Icons.Filled.DeleteSweep, null, tint = TerminalError, modifier = Modifier.size(18.dp))
                    }
                )
            }
        }

        // Viewing Analytics & Control-Plane Sync
        item {
            SettingsSectionCard(
                title = "Viewing Analytics & Privacy",
                icon = { Icon(Icons.Filled.Analytics, null, tint = TerminalSecondary) }
            ) {
                Surface(
                    color = palette.elevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = AppConstants.PRIVACY_SUMMARY,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Share Anonymous Viewing Analytics",
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.text
                        )
                        Text(
                            text = "Sends anonymous session UUID, channel ID, device type (TV/Mobile), app version & errors (heartbeat every ${settings.heartbeatIntervalSeconds}s)",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary
                        )
                    }
                    Switch(
                        checked = settings.analyticsEnabled,
                        onCheckedChange = onToggleAnalytics,
                        colors = SwitchDefaults.colors(checkedTrackColor = TerminalPrimary),
                        modifier = Modifier.testTag("analytics_toggle_switch")
                    )
                }

                OutlinedTextField(
                    value = backendUrlDraft,
                    onValueChange = { backendUrlDraft = it },
                    label = { Text("Backend Control-Plane URL (Optional)") },
                    placeholder = { Text("https://your-backend.example.com") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalSecondary,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.text,
                        unfocusedTextColor = palette.text
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("backend_url_input")
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NeonOutlinedButton(
                        text = "Save Control-Plane URL",
                        onClick = { onUpdateBackendUrl(backendUrlDraft) },
                        modifier = Modifier.testTag("save_backend_url_button")
                    )
                    if (settings.backendServerUrl.isNotBlank()) {
                        Text(
                            text = "Remote Config v${settings.lastRemoteConfigVersion}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TerminalSecondary
                        )
                    }
                }
            }
        }

        // App Information (with discreet Owner Super Admin access)
        item {
            SettingsSectionCard(
                title = "App Information",
                icon = { Icon(Icons.Filled.Info, null, tint = TerminalSecondary) }
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            versionTapCount += 1
                            if (versionTapCount >= 5) {
                                versionTapCount = 0
                                onOpenAdminConsole()
                            } else if (versionTapCount >= 3) {
                                val remaining = 5 - versionTapCount
                                Toast.makeText(
                                    context,
                                    "$remaining more taps for Owner Console",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .padding(vertical = 4.dp)
                        .testTag("app_version_info_row")
                ) {
                    Text(
                        text = "M3U8PLAYLISTTERMINAL • Version 1.0",
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.text
                    )
                    Text(
                        text = "Native Android TV + Mobile streaming engine powered by AndroidX Media3 ExoPlayer (HLS, DASH, Progressive MP4), Room Cache, and Jetpack Compose.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onOpenAdminConsole,
                        modifier = Modifier.testTag("owner_console_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = null,
                            tint = palette.textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "  Owner Console",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.textSecondary
                        )
                    }
                }
            }
        }
    }

    if (showClearCacheConfirm) {
        AlertDialog(
            onDismissRequest = { showClearCacheConfirm = false },
            containerColor = palette.card,
            titleContentColor = palette.text,
            title = { Text("Clear Cached Playlist Data?") },
            text = {
                Text(
                    "This clears all cached channels and watch history from the local database while keeping your playlist URLs.",
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                NeonGradientButton(
                    text = "Clear Cache",
                    onClick = {
                        onClearCache()
                        showClearCacheConfirm = false
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showClearCacheConfirm = false }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            containerColor = palette.card,
            titleContentColor = palette.text,
            title = { Text("Privacy Information") },
            text = {
                Text(AppConstants.PRIVACY_SUMMARY, color = palette.textSecondary)
            },
            confirmButton = {
                NeonGradientButton(
                    text = "Close",
                    onClick = { showPrivacyDialog = false }
                )
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: @Composable () -> Unit,
    content: @Composable () -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.card,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, palette.border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                icon()
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = palette.text
                )
            }
            content()
        }
    }
}
