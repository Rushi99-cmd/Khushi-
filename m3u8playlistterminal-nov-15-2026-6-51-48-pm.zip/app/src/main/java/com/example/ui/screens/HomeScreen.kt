package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.models.CategorySummary
import com.example.models.Channel
import com.example.models.PlaylistSource
import com.example.models.SyncState
import com.example.ui.components.BroadcastPulseLoader
import com.example.ui.components.ChannelCard
import com.example.ui.components.ChannelLogoBadge
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.components.TvFocusableCard
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.NeonAccentGradient
import com.example.ui.theme.TerminalError
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.ui.theme.TerminalSuccess
import com.example.ui.theme.TerminalWarning
import com.example.utils.Formatters

@Composable
fun HomeScreen(
    channels: List<Channel>,
    playlists: List<PlaylistSource>,
    featuredChannel: Channel?,
    lastPlayedChannel: Channel?,
    recentlyWatched: List<Channel>,
    favouriteChannels: List<Channel>,
    categories: List<CategorySummary>,
    syncState: SyncState,
    onRefresh: () -> Unit,
    onPlayChannel: (Channel, List<Channel>) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onOpenCategory: (String) -> Unit,
    onNavigateToPlaylists: () -> Unit,
    onNavigateToLiveTv: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    val topCategoryGroups = remember(channels, categories) {
        categories.take(4).map { summary ->
            summary.name to channels.filter { it.groupTitle == summary.name }.take(12)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // 1. Playlist Status & Refresh Bar
        item {
            PlaylistStatusHeader(
                playlists = playlists,
                totalChannels = channels.size,
                syncState = syncState,
                onRefresh = onRefresh
            )
        }

        // 2. Loading or Hard Error state when no cached channels exist
        if (channels.isEmpty()) {
            item {
                when (syncState) {
                    is SyncState.Loading -> {
                        Surface(
                            color = palette.card,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, palette.border),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                BroadcastPulseLoader(label = syncState.message)
                            }
                        }
                    }
                    is SyncState.Error -> {
                        EmptyServerErrorCard(
                            errorMessage = syncState.message,
                            onRetry = onRefresh,
                            onAddPlaylist = onNavigateToPlaylists
                        )
                    }
                    else -> {
                        EmptyServerErrorCard(
                            errorMessage = "No active channels loaded yet. Refresh the built-in playlist or add an external M3U/M3U8 source.",
                            onRetry = onRefresh,
                            onAddPlaylist = onNavigateToPlaylists
                        )
                    }
                }
            }
        } else {
            // 3. Featured Channel Hero
            if (featuredChannel != null) {
                item {
                    FeaturedChannelBanner(
                        channel = featuredChannel,
                        onWatchNow = { onPlayChannel(featuredChannel, channels) },
                        onToggleFavourite = { onToggleFavourite(featuredChannel.id) }
                    )
                }
            }

            // 4. Continue Watching / Last Channel Quick Resume
            if (lastPlayedChannel != null) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitleRow(
                            title = "Continue Watching",
                            subtitle = "Last channel shortcut",
                            actionLabel = "All Live TV",
                            onAction = onNavigateToLiveTv
                        )
                        ChannelCard(
                            channel = lastPlayedChannel,
                            onPlay = { onPlayChannel(lastPlayedChannel, channels) },
                            onToggleFavourite = { onToggleFavourite(lastPlayedChannel.id) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // 5. Recently Watched Carousel
            if (recentlyWatched.isNotEmpty()) {
                item {
                    ChannelCarouselSection(
                        title = "Recently Watched",
                        channels = recentlyWatched,
                        onPlayChannel = { ch -> onPlayChannel(ch, recentlyWatched) },
                        onToggleFavourite = onToggleFavourite
                    )
                }
            }

            // 6. Favourite Channels Carousel
            if (favouriteChannels.isNotEmpty()) {
                item {
                    ChannelCarouselSection(
                        title = "Favourite Channels",
                        channels = favouriteChannels,
                        onPlayChannel = { ch -> onPlayChannel(ch, favouriteChannels) },
                        onToggleFavourite = onToggleFavourite
                    )
                }
            }

            // 7. Category Sections
            items(topCategoryGroups, key = { it.first }) { (categoryName, catChannels) ->
                if (catChannels.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitleRow(
                            title = categoryName,
                            subtitle = "${catChannels.size} shown",
                            actionLabel = "View Category",
                            onAction = { onOpenCategory(categoryName) }
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(catChannels, key = { "${categoryName}_${it.id}" }) { channel ->
                                TvChannelTile(
                                    channel = channel,
                                    onPlay = { onPlayChannel(channel, catChannels) },
                                    onToggleFavourite = { onToggleFavourite(channel.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaylistStatusHeader(
    playlists: List<PlaylistSource>,
    totalChannels: Int,
    syncState: SyncState,
    onRefresh: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    val enabledCount = playlists.count { it.isEnabled }
    val latestSync = playlists.mapNotNull { it.lastSyncedAt }.maxOrNull()

    val (statusText, statusColor) = when (syncState) {
        is SyncState.Loading -> syncState.message to TerminalSecondary
        is SyncState.Error -> syncState.message to TerminalError
        is SyncState.CachedFallback -> "Cached ($totalChannels ch) • ${syncState.reason}" to TerminalWarning
        is SyncState.Success -> "Live Sync • $totalChannels channels" to TerminalSuccess
        SyncState.Idle -> "$totalChannels channels • $enabledCount playlist(s) active" to TerminalSecondary
    }

    Surface(
        color = palette.card,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, palette.border),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(statusColor, shape = RoundedCornerShape(50))
                    )
                    Text(
                        text = "PLAYLIST TERMINAL STATUS",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                }
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.titleSmall,
                    color = palette.text,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Last synced: ${Formatters.formatTimestamp(latestSync)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            NeonOutlinedButton(
                text = if (syncState is SyncState.Loading) "Syncing..." else "Refresh",
                onClick = onRefresh,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = stringResource(R.string.cd_refresh),
                        tint = TerminalSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                modifier = Modifier.testTag("home_refresh_button")
            )
        }
    }
}

@Composable
private fun FeaturedChannelBanner(
    channel: Channel,
    onWatchNow: () -> Unit,
    onToggleFavourite: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(1.5.dp, NeonAccentGradient),
        color = palette.card,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_terminal_1794745150380),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .alpha(0.35f)
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                palette.card.copy(alpha = 0.96f),
                                palette.card.copy(alpha = 0.78f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = TerminalPrimary.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, TerminalPrimary)
                    ) {
                        Text(
                            text = "FEATURED STREAM",
                            style = MaterialTheme.typography.labelSmall,
                            color = TerminalPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        color = palette.elevated,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = channel.groupTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = TerminalSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    ChannelLogoBadge(
                        logoUrl = channel.logoUrl,
                        channelName = channel.name,
                        size = 72.dp
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "CH ${Formatters.formatChannelNumber(channel.channelNumber)} • ${channel.playlistName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = TerminalSecondary
                        )
                        Text(
                            text = channel.name,
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NeonGradientButton(
                        text = "Watch Now",
                        onClick = onWatchNow,
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        modifier = Modifier.testTag("featured_watch_button")
                    )

                    NeonOutlinedButton(
                        text = if (channel.isFavourite) "Favourited" else "Favourite",
                        onClick = onToggleFavourite,
                        leadingIcon = {
                            Icon(
                                imageVector = if (channel.isFavourite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                contentDescription = null,
                                tint = TerminalPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChannelCarouselSection(
    title: String,
    channels: List<Channel>,
    onPlayChannel: (Channel) -> Unit,
    onToggleFavourite: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = LocalTerminalPalette.current.text
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(channels, key = { "${title}_${it.id}" }) { channel ->
                TvChannelTile(
                    channel = channel,
                    onPlay = { onPlayChannel(channel) },
                    onToggleFavourite = { onToggleFavourite(channel.id) }
                )
            }
        }
    }
}

@Composable
fun TvChannelTile(
    channel: Channel,
    onPlay: () -> Unit,
    onToggleFavourite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalTerminalPalette.current
    TvFocusableCard(
        onClick = onPlay,
        modifier = modifier.width(220.dp)
    ) { isFocused ->
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                ChannelLogoBadge(
                    logoUrl = channel.logoUrl,
                    channelName = channel.name,
                    size = 54.dp
                )
                Surface(
                    color = if (isFocused) TerminalPrimary.copy(alpha = 0.25f) else palette.elevated,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "#${Formatters.formatChannelNumber(channel.channelNumber)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isFocused) TerminalPrimary else TerminalSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = channel.name,
                style = MaterialTheme.typography.titleMedium,
                color = palette.text,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = channel.groupTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (channel.isFavourite) {
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = stringResource(R.string.cd_favourite),
                        tint = TerminalPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitleRow(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = LocalTerminalPalette.current.text
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = LocalTerminalPalette.current.textSecondary
            )
        }
        TextButton(onClick = onAction) {
            Text(text = actionLabel, color = TerminalSecondary)
        }
    }
}

@Composable
private fun EmptyServerErrorCard(
    errorMessage: String,
    onRetry: () -> Unit,
    onAddPlaylist: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.card,
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, TerminalError.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.CloudOff,
                contentDescription = null,
                tint = TerminalError,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = "Playlist Unavailable",
                style = MaterialTheme.typography.headlineMedium,
                color = palette.text
            )
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NeonGradientButton(
                    text = "Retry Built-in Playlist",
                    onClick = onRetry,
                    leadingIcon = {
                        Icon(Icons.Filled.Refresh, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                )
                NeonOutlinedButton(
                    text = "My Playlists",
                    onClick = onAddPlaylist,
                    leadingIcon = {
                        Icon(Icons.Filled.PlaylistAdd, null, tint = TerminalSecondary, modifier = Modifier.size(18.dp))
                    }
                )
            }
        }
    }
}
