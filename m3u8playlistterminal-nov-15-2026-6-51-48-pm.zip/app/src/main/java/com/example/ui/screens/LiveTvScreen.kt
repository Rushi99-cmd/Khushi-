package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.models.CategorySummary
import com.example.models.Channel
import com.example.models.SyncState
import com.example.ui.components.BroadcastPulseLoader
import com.example.ui.components.ChannelCard
import com.example.ui.components.ChannelNumberKeypadDialog
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary

@Composable
fun LiveTvScreen(
    channels: List<Channel>,
    categories: List<CategorySummary>,
    selectedCategory: String?,
    lastPlayedChannel: Channel?,
    syncState: SyncState,
    onSelectCategory: (String) -> Unit,
    onPlayChannel: (Channel, List<Channel>) -> Unit,
    onToggleFavourite: (String) -> Unit,
    onJumpToChannelNumber: (Int) -> Channel?,
    onRefresh: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    var inlineFilter by remember { mutableStateOf("") }
    var showFavouritesOnly by remember { mutableStateOf(false) }
    var showKeypad by remember { mutableStateOf(false) }

    val filteredChannels = remember(channels, selectedCategory, inlineFilter, showFavouritesOnly) {
        channels.filter { channel ->
            val matchesCategory = selectedCategory.isNullOrBlank() ||
                selectedCategory == "All" ||
                channel.groupTitle.equals(selectedCategory, ignoreCase = true)
            val matchesFav = !showFavouritesOnly || channel.isFavourite
            val query = inlineFilter.trim()
            val matchesQuery = query.isEmpty() ||
                channel.name.contains(query, ignoreCase = true) ||
                channel.groupTitle.contains(query, ignoreCase = true) ||
                channel.channelNumber.toString() == query
            matchesCategory && matchesFav && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header + Quick Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Live TV Channels",
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.text
                )
                Text(
                    text = "${filteredChannels.size} of ${channels.size} channels",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (lastPlayedChannel != null) {
                    NeonOutlinedButton(
                        text = "Last CH",
                        onClick = { onPlayChannel(lastPlayedChannel, channels) },
                        leadingIcon = {
                            Icon(Icons.Filled.History, null, tint = TerminalPrimary, modifier = Modifier.size(18.dp))
                        },
                        modifier = Modifier.testTag("last_channel_shortcut")
                    )
                }

                NeonOutlinedButton(
                    text = "CH #",
                    onClick = { showKeypad = true },
                    leadingIcon = {
                        Icon(Icons.Filled.Dialpad, null, tint = TerminalSecondary, modifier = Modifier.size(18.dp))
                    },
                    modifier = Modifier.testTag("channel_keypad_button")
                )
            }
        }

        // Inline Filter Input
        OutlinedTextField(
            value = inlineFilter,
            onValueChange = { inlineFilter = it },
            placeholder = { Text("Filter channels by name, category, or number...") },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = TerminalSecondary) },
            trailingIcon = {
                if (inlineFilter.isNotEmpty()) {
                    IconButton(onClick = { inlineFilter = "" }) {
                        Icon(Icons.Filled.Clear, stringResource(R.string.cd_clear_search))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = palette.card,
                unfocusedContainerColor = palette.card,
                focusedBorderColor = TerminalSecondary,
                unfocusedBorderColor = palette.border,
                focusedTextColor = palette.text,
                unfocusedTextColor = palette.text
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("live_tv_filter_input")
        )

        // Category & Favourites Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = showFavouritesOnly,
                    onClick = { showFavouritesOnly = !showFavouritesOnly },
                    label = { Text("Favourites") },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.Star,
                            contentDescription = null,
                            tint = if (showFavouritesOnly) Color.White else TerminalPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TerminalPrimary,
                        selectedLabelColor = Color.White,
                        containerColor = palette.card,
                        labelColor = palette.text
                    )
                )
            }
            item {
                val isAll = selectedCategory.isNullOrBlank() || selectedCategory == "All"
                FilterChip(
                    selected = isAll,
                    onClick = { onSelectCategory("All") },
                    label = { Text("All (${channels.size})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TerminalSecondary,
                        selectedLabelColor = Color(0xFF001824),
                        containerColor = palette.card,
                        labelColor = palette.text
                    )
                )
            }
            items(categories, key = { it.name }) { cat ->
                val selected = selectedCategory.equals(cat.name, ignoreCase = true)
                FilterChip(
                    selected = selected,
                    onClick = { onSelectCategory(cat.name) },
                    label = { Text("${cat.name} (${cat.channelCount})") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TerminalSecondary,
                        selectedLabelColor = Color(0xFF001824),
                        containerColor = palette.card,
                        labelColor = palette.text
                    )
                )
            }
        }

        // Channel Grid / Empty / Loading
        when {
            syncState is SyncState.Loading && channels.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    BroadcastPulseLoader(label = syncState.message)
                }
            }
            filteredChannels.isEmpty() -> {
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Filled.LiveTv, null, tint = TerminalSecondary, modifier = Modifier.size(40.dp))
                        Text(
                            text = if (channels.isEmpty()) "No channels available" else "No matching channels",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.text
                        )
                        Text(
                            text = if (syncState is SyncState.Error) syncState.message
                            else "Try clearing your category/search filters or refreshing playlists.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.textSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        NeonGradientButton(
                            text = "Refresh Playlists",
                            onClick = onRefresh,
                            leadingIcon = { Icon(Icons.Filled.Refresh, null, tint = Color.White) }
                        )
                    }
                }
            }
            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredChannels, key = { it.id }) { channel ->
                        ChannelCard(
                            channel = channel,
                            onPlay = { onPlayChannel(channel, filteredChannels) },
                            onToggleFavourite = { onToggleFavourite(channel.id) }
                        )
                    }
                }
            }
        }
    }

    if (showKeypad) {
        ChannelNumberKeypadDialog(
            onDismiss = { showKeypad = false },
            onTuneNumber = { number ->
                onJumpToChannelNumber(number)
            }
        )
    }
}
