package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.exoplayer.ExoPlayer
import com.example.data.AnalyticsTracker
import com.example.data.AppDatabase
import com.example.data.PlaylistRepository
import com.example.models.AdminChannelDto
import com.example.models.AdminChannelPatchRequest
import com.example.models.AdminConfigUpdateRequest
import com.example.models.AdminSessionState
import com.example.models.AdminSourceDto
import com.example.models.AdminSourceUpsertRequest
import com.example.models.AspectRatioMode
import com.example.models.AuditLogEntryDto
import com.example.models.BufferProfile
import com.example.models.CategorySummary
import com.example.models.Channel
import com.example.models.LiveAnalyticsResponse
import com.example.models.PlayerUiState
import com.example.models.PlaylistSource
import com.example.models.RefreshInterval
import com.example.models.SearchScope
import com.example.models.SyncState
import com.example.models.ThemePreset
import com.example.models.TrackOption
import com.example.models.UserSettings
import com.example.network.AdminUnauthorizedException
import com.example.network.BackendApiClient
import com.example.player.ExoPlayerManager
import com.example.settings.SettingsPreferences
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminDashboardUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val liveAnalytics: LiveAnalyticsResponse = LiveAnalyticsResponse(),
    val sources: List<AdminSourceDto> = emptyList(),
    val channels: List<AdminChannelDto> = emptyList(),
    val auditLogs: List<AuditLogEntryDto> = emptyList()
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = PlaylistRepository(application, database)
    private val settingsPrefs = SettingsPreferences(application)
    private val playerManager = ExoPlayerManager(application)
    private val backendApi = BackendApiClient()
    private val analyticsTracker = AnalyticsTracker(application, backendApi, settingsPrefs, viewModelScope)

    val settings: StateFlow<UserSettings> = settingsPrefs.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = UserSettings()
        )

    val playlists: StateFlow<List<PlaylistSource>> = repository.playlistsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val allChannels: StateFlow<List<Channel>> = repository.enabledChannelsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val favouriteChannels: StateFlow<List<Channel>> = repository.favouriteChannelsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val recentlyWatched: StateFlow<List<Channel>> = repository.recentlyWatchedFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val categories: StateFlow<List<CategorySummary>> = allChannels
        .combine(playlists) { channels, _ ->
            channels.groupBy { it.groupTitle }
                .entries
                .sortedByDescending { it.value.size }
                .map { (groupName, groupChannels) ->
                    CategorySummary(
                        name = groupName,
                        channelCount = groupChannels.size,
                        sampleLogoUrl = groupChannels.firstOrNull { !it.logoUrl.isNullOrBlank() }?.logoUrl
                    )
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    val lastPlayedChannel: StateFlow<Channel?> = combine(
        allChannels,
        recentlyWatched,
        settings
    ) { channels, recent, userSettings ->
        val lastId = userSettings.lastChannelId
        recent.firstOrNull()
            ?: channels.firstOrNull { it.id == lastId }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = null
    )

    val featuredChannel: StateFlow<Channel?> = combine(
        allChannels,
        favouriteChannels,
        recentlyWatched
    ) { channels, favs, recent ->
        recent.firstOrNull()
            ?: favs.firstOrNull()
            ?: channels.firstOrNull { !it.logoUrl.isNullOrBlank() }
            ?: channels.firstOrNull()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = null
    )

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>("All")
    val selectedCategory: StateFlow<String?> = _selectedCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchScope = MutableStateFlow(SearchScope.ALL)
    val searchScope: StateFlow<SearchScope> = _searchScope.asStateFlow()

    val searchResults: StateFlow<List<Channel>> = combine(
        allChannels,
        _searchQuery,
        _searchScope
    ) { channels, query, scope ->
        val trimmed = query.trim().lowercase(Locale.ROOT)
        if (trimmed.isEmpty()) {
            emptyList()
        } else {
            channels.filter { channel ->
                when (scope) {
                    SearchScope.ALL -> {
                        channel.name.lowercase(Locale.ROOT).contains(trimmed) ||
                            channel.groupTitle.lowercase(Locale.ROOT).contains(trimmed) ||
                            channel.playlistName.lowercase(Locale.ROOT).contains(trimmed) ||
                            channel.channelNumber.toString() == trimmed
                    }
                    SearchScope.CHANNEL_NAME -> {
                        channel.name.lowercase(Locale.ROOT).contains(trimmed) ||
                            channel.channelNumber.toString() == trimmed
                    }
                    SearchScope.CATEGORY -> channel.groupTitle.lowercase(Locale.ROOT).contains(trimmed)
                    SearchScope.PLAYLIST -> channel.playlistName.lowercase(Locale.ROOT).contains(trimmed)
                }
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    private val _actionBanner = MutableStateFlow<String?>(null)
    val actionBanner: StateFlow<String?> = _actionBanner.asStateFlow()

    val playerUiState: StateFlow<PlayerUiState> = playerManager.uiState

    private val _numericEntry = MutableStateFlow("")
    val numericEntry: StateFlow<String> = _numericEntry.asStateFlow()

    // Owner-only in-memory admin session (never written to APK or persisted across cold restarts)
    private val _adminSession = MutableStateFlow<AdminSessionState?>(null)
    val adminSession: StateFlow<AdminSessionState?> = _adminSession.asStateFlow()

    private val _adminDashboardState = MutableStateFlow(AdminDashboardUiState())
    val adminDashboardState: StateFlow<AdminDashboardUiState> = _adminDashboardState.asStateFlow()

    init {
        playerManager.onPlaybackErrorCallback = { channel, errorCode, errorMessage ->
            analyticsTracker.onPlaybackError(channel, errorCode, errorMessage)
        }

        analyticsTracker.recoverCrashedSessionIfAny()

        viewModelScope.launch {
            repository.ensureBuiltInPlaylistExists()
            val currentSettings = settingsPrefs.getSettingsOnce()
            val lastSync = settingsPrefs.getLastAutoRefreshAt()
            val now = System.currentTimeMillis()

            if (currentSettings.backendServerUrl.isNotBlank()) {
                syncRemoteControlPlane(currentSettings.backendServerUrl)
            }

            val shouldAutoSync = when {
                lastSync == 0L -> true
                !currentSettings.autoRefreshEnabled -> false
                currentSettings.refreshInterval == RefreshInterval.MANUAL -> false
                currentSettings.refreshInterval == RefreshInterval.ON_LAUNCH -> true
                else -> {
                    val intervalMs = currentSettings.refreshInterval.hours * 3_600_000L
                    (now - lastSync) >= intervalMs
                }
            }

            if (shouldAutoSync) {
                refreshAllPlaylists()
            }
        }

        viewModelScope.launch {
            while (true) {
                delay(1_000L)
                val state = playerManager.uiState.value
                if (state.currentChannel != null && state.isPlaying) {
                    playerManager.refreshProgressTick()
                }
            }
        }
    }

    private suspend fun syncRemoteControlPlane(serverUrl: String) {
        if (serverUrl.isBlank()) return
        backendApi.fetchRemoteBootstrap(serverUrl).onSuccess { bootstrap ->
            settingsPrefs.applyRemoteConfig(
                configVersion = bootstrap.configVersion,
                heartbeatIntervalSeconds = bootstrap.heartbeatIntervalSeconds,
                maintenanceMessage = bootstrap.maintenanceMessage
            )
            repository.applyRemoteBootstrap(bootstrap)
        }
    }

    fun completeWelcome() {
        viewModelScope.launch {
            settingsPrefs.setWelcomeCompleted(true)
        }
    }

    fun refreshAllPlaylists() {
        viewModelScope.launch {
            _syncState.value = SyncState.Loading("Fetching M3U8 playlists...")
            val currentSettings = settingsPrefs.getSettingsOnce()
            if (currentSettings.backendServerUrl.isNotBlank()) {
                syncRemoteControlPlane(currentSettings.backendServerUrl)
            }
            val result = repository.refreshAllEnabledPlaylists(currentSettings.customUserAgent)
            _syncState.value = result
            if (result is SyncState.Success) {
                settingsPrefs.setLastAutoRefreshAt(result.timestamp)
            }
        }
    }

    fun refreshSinglePlaylist(playlistId: String) {
        viewModelScope.launch {
            _syncState.value = SyncState.Loading("Refreshing playlist...")
            val result = repository.refreshSinglePlaylist(playlistId, settings.value.customUserAgent)
            _syncState.value = result
            if (result is SyncState.Success) {
                _actionBanner.value = result.message
            } else if (result is SyncState.Error) {
                _actionBanner.value = result.message
            }
        }
    }

    fun addRemotePlaylist(
        name: String,
        url: String,
        makeDefault: Boolean,
        onResult: (Result<PlaylistSource>) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.addRemotePlaylist(
                name = name,
                rawUrl = url,
                makeDefault = makeDefault,
                customUserAgent = settings.value.customUserAgent
            )
            result.onSuccess { added ->
                if (makeDefault) {
                    settingsPrefs.setDefaultPlaylistId(added.id)
                }
                _actionBanner.value = "Added '${added.name}' (${added.channelCount} channels)."
            }
            onResult(result)
        }
    }

    fun importLocalPlaylist(
        name: String,
        uri: Uri,
        makeDefault: Boolean,
        onResult: (Result<PlaylistSource>) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.importLocalPlaylist(name, uri, makeDefault)
            result.onSuccess { added ->
                if (makeDefault) {
                    settingsPrefs.setDefaultPlaylistId(added.id)
                }
                _actionBanner.value = "Imported '${added.name}' (${added.channelCount} channels)."
            }
            onResult(result)
        }
    }

    fun updatePlaylistDetails(
        playlistId: String,
        newName: String,
        newUrl: String,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.updatePlaylistDetails(
                playlistId = playlistId,
                newName = newName,
                newUrl = newUrl,
                customUserAgent = settings.value.customUserAgent
            )
            result.onSuccess {
                _actionBanner.value = "Updated playlist details."
            }
            onResult(result)
        }
    }

    fun togglePlaylistEnabled(playlistId: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.setPlaylistEnabled(playlistId, enabled)
        }
    }

    fun setDefaultPlaylist(playlistId: String) {
        viewModelScope.launch {
            repository.setDefaultPlaylist(playlistId)
            settingsPrefs.setDefaultPlaylistId(playlistId)
            _actionBanner.value = "Default playlist updated."
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            _actionBanner.value = "Playlist removed."
        }
    }

    fun selectCategory(category: String?) {
        _selectedCategory.value = category ?: "All"
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateSearchScope(scope: SearchScope) {
        _searchScope.value = scope
    }

    fun clearSearch() {
        _searchQuery.value = ""
    }

    fun toggleFavourite(channelId: String) {
        viewModelScope.launch {
            repository.toggleFavourite(channelId)
        }
    }

    fun clearActionBanner() {
        _actionBanner.value = null
    }

    // Player & Zapping
    fun getExoPlayer(): ExoPlayer {
        val currentSettings = settings.value
        return playerManager.getOrCreatePlayer(
            bufferProfile = currentSettings.bufferProfile,
            userAgent = currentSettings.customUserAgent
        )
    }

    fun playChannel(channel: Channel, queue: List<Channel> = allChannels.value) {
        val currentSettings = settings.value
        val effectiveQueue = queue.ifEmpty { listOf(channel) }
        playerManager.playChannel(
            channel = channel,
            queue = effectiveQueue,
            aspectRatio = currentSettings.defaultAspectRatio,
            bufferProfile = currentSettings.bufferProfile,
            globalUserAgent = currentSettings.customUserAgent,
            resumeIfVod = true
        )
        analyticsTracker.onPlaybackStarted(channel)
        viewModelScope.launch {
            settingsPrefs.setLastChannelId(channel.id)
            repository.recordWatchProgress(channel.id, channel.lastPositionMs, channel.durationMs)
        }
    }

    fun playChannelById(channelId: String) {
        val channels = allChannels.value
        val target = channels.firstOrNull { it.id == channelId } ?: return
        val current = playerManager.uiState.value.currentChannel
        if (current?.id == target.id && playerManager.uiState.value.errorMessage == null) {
            return
        }
        playChannel(target, channels)
    }

    fun playPreviousChannel(): Channel? {
        val state = playerManager.uiState.value
        val queue = state.channelQueue.ifEmpty { allChannels.value }
        val current = state.currentChannel ?: return null
        val index = queue.indexOfFirst { it.id == current.id }
        if (index == -1 || queue.isEmpty()) return null
        val prevIndex = if (index - 1 < 0) queue.lastIndex else index - 1
        val prev = queue[prevIndex]
        playChannel(prev, queue)
        return prev
    }

    fun playNextChannel(): Channel? {
        val state = playerManager.uiState.value
        val queue = state.channelQueue.ifEmpty { allChannels.value }
        val current = state.currentChannel ?: return null
        val index = queue.indexOfFirst { it.id == current.id }
        if (index == -1 || queue.isEmpty()) return null
        val nextIndex = (index + 1) % queue.size
        val next = queue[nextIndex]
        playChannel(next, queue)
        return next
    }

    fun jumpToChannelNumber(channelNumber: Int): Channel? {
        val channels = allChannels.value
        val match = channels.firstOrNull { it.channelNumber == channelNumber }
        if (match != null) {
            playChannel(match, channels)
        } else {
            _actionBanner.value = "Channel #$channelNumber not found in enabled playlists."
        }
        return match
    }

    fun appendNumericDigit(digit: Char, onMatched: (Channel) -> Unit) {
        if (!digit.isDigit()) return
        val updated = (_numericEntry.value + digit).take(4)
        _numericEntry.value = updated
        if (updated.length >= 4) {
            commitNumericEntry(onMatched)
        }
    }

    fun commitNumericEntry(onMatched: (Channel) -> Unit) {
        val num = _numericEntry.value.toIntOrNull()
        _numericEntry.value = ""
        if (num != null) {
            val match = jumpToChannelNumber(num)
            if (match != null) {
                onMatched(match)
            }
        }
    }

    fun clearNumericEntry() {
        _numericEntry.value = ""
    }

    fun retryPlayback() {
        val currentSettings = settings.value
        val ch = playerManager.uiState.value.currentChannel
        playerManager.retryCurrentChannel(
            bufferProfile = currentSettings.bufferProfile,
            globalUserAgent = currentSettings.customUserAgent
        )
        if (ch != null) {
            analyticsTracker.onPlaybackStarted(ch)
        }
    }

    fun togglePlayPause() {
        val wasPlaying = playerManager.uiState.value.isPlaying
        playerManager.togglePlayPause()
        val channel = playerManager.uiState.value.currentChannel
        if (wasPlaying) {
            analyticsTracker.onPlaybackPausedOrStopped()
        } else if (channel != null) {
            analyticsTracker.onPlaybackStarted(channel)
        }
    }

    fun seekBy(deltaMs: Long) = playerManager.seekBy(deltaMs)
    fun seekTo(positionMs: Long) = playerManager.seekTo(positionMs)
    fun setVolume(volume: Float) = playerManager.setVolume(volume)
    fun toggleMute() = playerManager.toggleMute()
    fun setAspectRatio(mode: AspectRatioMode) = playerManager.setAspectRatio(mode)
    fun setFullscreen(fullscreen: Boolean) = playerManager.setFullscreen(fullscreen)
    fun selectAudioTrack(option: TrackOption) = playerManager.selectAudioTrack(option)
    fun selectSubtitleTrack(option: TrackOption?) = playerManager.selectSubtitleTrack(option)
    fun selectVideoQuality(option: TrackOption?) = playerManager.selectVideoQuality(option)

    fun saveCurrentWatchProgressAndPause() {
        val state = playerManager.uiState.value
        val channel = state.currentChannel
        if (channel != null) {
            viewModelScope.launch {
                repository.recordWatchProgress(channel.id, state.currentPositionMs, state.durationMs)
            }
        }
        analyticsTracker.onPlaybackPausedOrStopped()
        playerManager.pausePlayback()
    }

    // Settings mutations
    fun setThemePreset(preset: ThemePreset) {
        viewModelScope.launch { settingsPrefs.setThemePreset(preset) }
    }

    fun setAutoRefreshEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsPrefs.setAutoRefreshEnabled(enabled) }
    }

    fun setRefreshInterval(interval: RefreshInterval) {
        viewModelScope.launch { settingsPrefs.setRefreshInterval(interval) }
    }

    fun setDefaultAspectRatio(mode: AspectRatioMode) {
        viewModelScope.launch {
            settingsPrefs.setDefaultAspectRatio(mode)
            playerManager.setAspectRatio(mode)
        }
    }

    fun setBufferProfile(profile: BufferProfile) {
        viewModelScope.launch { settingsPrefs.setBufferProfile(profile) }
    }

    fun setCustomUserAgent(userAgent: String) {
        viewModelScope.launch {
            settingsPrefs.setCustomUserAgent(userAgent)
            _actionBanner.value = "Player User-Agent updated."
        }
    }

    fun setBackendServerUrl(url: String) {
        viewModelScope.launch {
            settingsPrefs.setBackendServerUrl(url)
            val normalized = url.trim().trimEnd('/')
            if (normalized.isNotBlank()) {
                syncRemoteControlPlane(normalized)
            }
            _actionBanner.value = if (normalized.isBlank()) {
                "Backend server disconnected (local-only mode)."
            } else {
                "Backend server endpoint saved."
            }
        }
    }

    fun setAnalyticsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsPrefs.setAnalyticsEnabled(enabled)
            if (!enabled) {
                analyticsTracker.onPlaybackPausedOrStopped()
            }
        }
    }

    fun clearCachedPlaylistData() {
        viewModelScope.launch {
            repository.clearCachedPlaylistData()
            settingsPrefs.setLastAutoRefreshAt(0L)
            _syncState.value = SyncState.Idle
            _actionBanner.value = "Cached playlist channels cleared."
        }
    }

    // Owner-Only Super Admin Actions
    fun loginAsOwner(
        serverUrl: String,
        username: String,
        password: String,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            val cleanUrl = serverUrl.trim().trimEnd('/')
            if (cleanUrl.isBlank()) {
                onResult(Result.failure(IllegalArgumentException("Enter the backend server URL.")))
                return@launch
            }
            if (username.isBlank() || password.isBlank()) {
                onResult(Result.failure(IllegalArgumentException("Enter owner username and password.")))
                return@launch
            }
            val result = backendApi.adminLogin(cleanUrl, username, password)
            result.onSuccess { session ->
                settingsPrefs.setBackendServerUrl(cleanUrl)
                _adminSession.value = session
                refreshAdminDashboard()
                onResult(Result.success(Unit))
            }.onFailure { err ->
                onResult(Result.failure(err))
            }
        }
    }

    fun logoutAdmin() {
        val session = _adminSession.value
        val url = settings.value.backendServerUrl
        _adminSession.value = null
        _adminDashboardState.value = AdminDashboardUiState()
        if (session != null && url.isNotBlank()) {
            viewModelScope.launch {
                backendApi.adminLogout(url, session.token)
            }
        }
    }

    private fun requireActiveAdminSession(): Pair<String, AdminSessionState>? {
        val session = _adminSession.value
        val url = settings.value.backendServerUrl
        if (session == null || session.isExpired() || url.isBlank()) {
            _adminSession.value = null
            return null
        }
        return url to session
    }

    private fun handleAdminFailure(err: Throwable) {
        if (err is AdminUnauthorizedException) {
            _adminSession.value = null
            _adminDashboardState.update { it.copy(isLoading = false, errorMessage = err.message) }
        } else {
            _adminDashboardState.update {
                it.copy(isLoading = false, errorMessage = err.localizedMessage ?: "Admin request failed")
            }
        }
    }

    fun refreshAdminDashboard() {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            _adminDashboardState.update { it.copy(isLoading = true, errorMessage = null) }
            val liveRes = backendApi.fetchLiveAnalytics(url, session.token)
            if (liveRes.isFailure) {
                handleAdminFailure(liveRes.exceptionOrNull()!!)
                return@launch
            }
            val sourcesRes = backendApi.fetchAdminSources(url, session.token)
            val channelsRes = backendApi.fetchAdminChannels(url, session.token)
            val logsRes = backendApi.fetchAuditLogs(url, session.token)

            val firstError = listOfNotNull(
                sourcesRes.exceptionOrNull(),
                channelsRes.exceptionOrNull(),
                logsRes.exceptionOrNull()
            ).firstOrNull()

            if (firstError is AdminUnauthorizedException) {
                handleAdminFailure(firstError)
                return@launch
            }

            _adminDashboardState.value = AdminDashboardUiState(
                isLoading = false,
                errorMessage = firstError?.localizedMessage,
                liveAnalytics = liveRes.getOrThrow(),
                sources = sourcesRes.getOrDefault(emptyList()),
                channels = channelsRes.getOrDefault(emptyList()),
                auditLogs = logsRes.getOrDefault(emptyList())
            )
        }
    }

    fun adminAddSource(
        name: String,
        upstreamUrl: String,
        isPrimary: Boolean,
        isBackup: Boolean,
        useProxy: Boolean
    ) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            backendApi.addAdminSource(
                url,
                session.token,
                AdminSourceUpsertRequest(
                    name = name,
                    upstreamUrl = upstreamUrl,
                    isPrimary = isPrimary,
                    isBackup = isBackup,
                    isEnabled = true,
                    useProxy = useProxy
                )
            ).onSuccess {
                _actionBanner.value = "Source '$name' added."
                refreshAdminDashboard()
                syncRemoteControlPlane(url)
            }.onFailure(::handleAdminFailure)
        }
    }

    fun adminUpdateSource(
        source: AdminSourceDto,
        newName: String,
        newUpstreamUrl: String,
        isPrimary: Boolean,
        isBackup: Boolean,
        isEnabled: Boolean,
        useProxy: Boolean
    ) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            backendApi.updateAdminSource(
                url,
                session.token,
                source.id,
                AdminSourceUpsertRequest(
                    name = newName,
                    upstreamUrl = newUpstreamUrl,
                    isPrimary = isPrimary,
                    isBackup = isBackup,
                    isEnabled = isEnabled,
                    useProxy = useProxy
                )
            ).onSuccess {
                _actionBanner.value = "Source '$newName' updated."
                refreshAdminDashboard()
                syncRemoteControlPlane(url)
            }.onFailure(::handleAdminFailure)
        }
    }

    fun adminDeleteSource(sourceId: String) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            backendApi.deleteAdminSource(url, session.token, sourceId)
                .onSuccess {
                    _actionBanner.value = "Source removed."
                    refreshAdminDashboard()
                    syncRemoteControlPlane(url)
                }.onFailure(::handleAdminFailure)
        }
    }

    fun adminActivatePrimarySource(sourceId: String) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            backendApi.activatePrimarySource(url, session.token, sourceId)
                .onSuccess {
                    _actionBanner.value = "Primary source switched."
                    refreshAdminDashboard()
                    syncRemoteControlPlane(url)
                }.onFailure(::handleAdminFailure)
        }
    }

    fun adminRefreshSource(sourceId: String) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            _adminDashboardState.update { it.copy(isLoading = true) }
            backendApi.refreshAdminSource(url, session.token, sourceId)
                .onSuccess {
                    _actionBanner.value = "Refreshed upstream channels on server."
                    refreshAdminDashboard()
                    syncRemoteControlPlane(url)
                }.onFailure(::handleAdminFailure)
        }
    }

    fun adminUpdateChannel(
        channelId: String,
        name: String? = null,
        logoUrl: String? = null,
        groupTitle: String? = null,
        channelNumber: Int? = null,
        enabled: Boolean? = null
    ) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            backendApi.patchAdminChannel(
                url,
                session.token,
                channelId,
                AdminChannelPatchRequest(
                    name = name,
                    logoUrl = logoUrl,
                    groupTitle = groupTitle,
                    channelNumber = channelNumber,
                    enabled = enabled
                )
            ).onSuccess {
                _actionBanner.value = "Channel updated."
                refreshAdminDashboard()
                syncRemoteControlPlane(url)
            }.onFailure(::handleAdminFailure)
        }
    }

    fun adminPushConfig(
        heartbeatIntervalSeconds: Int,
        sessionTimeoutSeconds: Int,
        retentionDays: Int,
        analyticsEnabled: Boolean,
        maintenanceMessage: String
    ) {
        val (url, session) = requireActiveAdminSession() ?: return
        viewModelScope.launch {
            backendApi.pushRemoteConfig(
                url,
                session.token,
                AdminConfigUpdateRequest(
                    heartbeatIntervalSeconds = heartbeatIntervalSeconds,
                    sessionTimeoutSeconds = sessionTimeoutSeconds,
                    retentionDays = retentionDays,
                    analyticsEnabled = analyticsEnabled,
                    maintenanceMessage = maintenanceMessage
                )
            ).onSuccess { pushed ->
                settingsPrefs.applyRemoteConfig(
                    configVersion = pushed.configVersion,
                    heartbeatIntervalSeconds = pushed.heartbeatIntervalSeconds,
                    maintenanceMessage = pushed.maintenanceMessage
                )
                _actionBanner.value = "Pushed config v${pushed.configVersion} to clients."
                refreshAdminDashboard()
            }.onFailure(::handleAdminFailure)
        }
    }

    override fun onCleared() {
        super.onCleared()
        analyticsTracker.onPlaybackPausedOrStopped()
        playerManager.release()
    }
}
