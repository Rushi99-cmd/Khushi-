package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.models.PlaylistSource
import com.example.models.PlaylistType
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.NeonAccentGradient
import com.example.ui.theme.TerminalError
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.ui.theme.TerminalSuccess
import com.example.utils.Formatters

@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistSource>,
    onAddRemotePlaylist: (name: String, url: String, makeDefault: Boolean, onResult: (Result<PlaylistSource>) -> Unit) -> Unit,
    onImportLocalPlaylist: (name: String, uri: Uri, makeDefault: Boolean, onResult: (Result<PlaylistSource>) -> Unit) -> Unit,
    onUpdatePlaylist: (id: String, name: String, url: String, onResult: (Result<Unit>) -> Unit) -> Unit,
    onToggleEnabled: (id: String, enabled: Boolean) -> Unit,
    onSetDefault: (id: String) -> Unit,
    onRefreshPlaylist: (id: String) -> Unit,
    onRefreshAll: () -> Unit,
    onDeletePlaylist: (id: String) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var showAddUrlDialog by remember { mutableStateOf(false) }
    var pendingLocalUri by remember { mutableStateOf<Uri?>(null) }
    var editingPlaylist by remember { mutableStateOf<PlaylistSource?>(null) }
    var deletingPlaylist by remember { mutableStateOf<PlaylistSource?>(null) }

    // Storage Access Framework launcher for local M3U/M3U8 files
    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pendingLocalUri = uri
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header & Add Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "My Playlists",
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.text
                )
                Text(
                    text = "Manage remote M3U/M3U8 URLs and local files. Playlists stay private on your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NeonGradientButton(
                text = "Add M3U / M3U8 URL",
                onClick = { showAddUrlDialog = true },
                leadingIcon = {
                    Icon(Icons.Filled.AddLink, null, tint = Color.White, modifier = Modifier.size(18.dp))
                },
                modifier = Modifier.testTag("add_playlist_url_button")
            )

            NeonOutlinedButton(
                text = "Import Local File",
                onClick = {
                    safLauncher.launch(
                        arrayOf(
                            "audio/x-mpegurl",
                            "application/vnd.apple.mpegurl",
                            "application/x-mpegURL",
                            "text/plain",
                            "*/*"
                        )
                    )
                },
                leadingIcon = {
                    Icon(Icons.Filled.FolderOpen, null, tint = TerminalSecondary, modifier = Modifier.size(18.dp))
                },
                modifier = Modifier.testTag("import_local_playlist_button")
            )

            NeonOutlinedButton(
                text = "Sync All",
                onClick = onRefreshAll,
                leadingIcon = {
                    Icon(Icons.Filled.Refresh, null, tint = TerminalPrimary, modifier = Modifier.size(18.dp))
                }
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(playlists, key = { it.id }) { playlist ->
                PlaylistSourceCard(
                    playlist = playlist,
                    onToggleEnabled = { enabled -> onToggleEnabled(playlist.id, enabled) },
                    onSetDefault = { onSetDefault(playlist.id) },
                    onRefresh = { onRefreshPlaylist(playlist.id) },
                    onEdit = { editingPlaylist = playlist },
                    onDelete = { deletingPlaylist = playlist }
                )
            }
        }
    }

    if (showAddUrlDialog) {
        AddUrlPlaylistDialog(
            onDismiss = { showAddUrlDialog = false },
            onSubmit = { name, url, makeDefault, onDone ->
                onAddRemotePlaylist(name, url, makeDefault) { result ->
                    onDone(result.exceptionOrNull()?.message)
                    if (result.isSuccess) showAddUrlDialog = false
                }
            }
        )
    }

    pendingLocalUri?.let { uri ->
        ImportLocalNameDialog(
            uri = uri,
            onDismiss = { pendingLocalUri = null },
            onSubmit = { name, makeDefault, onDone ->
                onImportLocalPlaylist(name, uri, makeDefault) { result ->
                    onDone(result.exceptionOrNull()?.message)
                    if (result.isSuccess) pendingLocalUri = null
                }
            }
        )
    }

    editingPlaylist?.let { target ->
        EditPlaylistDialog(
            playlist = target,
            onDismiss = { editingPlaylist = null },
            onSave = { newName, newUrl, onDone ->
                onUpdatePlaylist(target.id, newName, newUrl) { result ->
                    onDone(result.exceptionOrNull()?.message)
                    if (result.isSuccess) editingPlaylist = null
                }
            }
        )
    }

    deletingPlaylist?.let { target ->
        AlertDialog(
            onDismissRequest = { deletingPlaylist = null },
            containerColor = palette.card,
            titleContentColor = palette.text,
            title = { Text("Delete Playlist?") },
            text = {
                Text(
                    text = "Remove '${target.name}' and its ${target.channelCount} cached channels from this device?",
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                NeonGradientButton(
                    text = "Delete",
                    onClick = {
                        onDeletePlaylist(target.id)
                        deletingPlaylist = null
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { deletingPlaylist = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun PlaylistSourceCard(
    playlist: PlaylistSource,
    onToggleEnabled: (Boolean) -> Unit,
    onSetDefault: () -> Unit,
    onRefresh: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.card,
        shape = RoundedCornerShape(18.dp),
        border = if (playlist.isDefault) {
            BorderStroke(1.5.dp, NeonAccentGradient)
        } else {
            BorderStroke(1.dp, palette.border)
        },
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlaylistPlay,
                        contentDescription = null,
                        tint = if (playlist.isEnabled) TerminalSecondary else palette.textSecondary,
                        modifier = Modifier.size(28.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = playlist.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = palette.text,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (playlist.isDefault) {
                                Surface(
                                    color = TerminalPrimary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "DEFAULT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TerminalPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Surface(
                                color = palette.elevated,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = playlist.type.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TerminalSecondary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = playlist.urlOrUri,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Switch(
                    checked = playlist.isEnabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = TerminalPrimary,
                        uncheckedTrackColor = palette.elevated
                    )
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (playlist.lastError == null) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                        contentDescription = null,
                        tint = if (playlist.lastError == null) TerminalSuccess else TerminalError,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (playlist.lastError != null) {
                            "${playlist.channelCount} cached • ${playlist.lastError}"
                        } else {
                            "${playlist.channelCount} channels • Synced ${Formatters.formatTimestamp(playlist.lastSyncedAt)}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (playlist.lastError != null) TerminalError else palette.textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (!playlist.isDefault) {
                        IconButton(
                            onClick = onSetDefault,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Star, "Set as default playlist", tint = TerminalSecondary)
                        }
                    }
                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Filled.Refresh, "Refresh playlist", tint = palette.text)
                    }
                    if (!playlist.isBuiltIn) {
                        IconButton(
                            onClick = onEdit,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Edit, "Edit playlist", tint = palette.text)
                        }
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Delete, "Delete playlist", tint = TerminalError)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddUrlPlaylistDialog(
    onDismiss: () -> Unit,
    onSubmit: (name: String, url: String, makeDefault: Boolean, onDone: (String?) -> Unit) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var makeDefault by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isLoading) onDismiss() },
        containerColor = palette.card,
        titleContentColor = palette.text,
        title = { Text("Add M3U / M3U8 Playlist URL") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    label = { Text("Custom Playlist Name") },
                    placeholder = { Text("e.g. Sports & News") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalSecondary,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.text,
                        unfocusedTextColor = palette.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it; errorMessage = null },
                    label = { Text("M3U or M3U8 URL") },
                    placeholder = { Text("https://example.com/playlist.m3u8") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalSecondary,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.text,
                        unfocusedTextColor = palette.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = makeDefault,
                        onCheckedChange = { makeDefault = it }
                    )
                    Text("Set as default playlist", color = palette.text)
                }
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = TerminalError
                    )
                }
                if (isLoading) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = TerminalPrimary)
                        Text("Validating and parsing playlist...", color = palette.textSecondary)
                    }
                }
            }
        },
        confirmButton = {
            NeonGradientButton(
                text = if (isLoading) "Adding..." else "Add Playlist",
                enabled = !isLoading,
                onClick = {
                    isLoading = true
                    errorMessage = null
                    onSubmit(name, url, makeDefault) { err ->
                        isLoading = false
                        errorMessage = err
                    }
                }
            )
        },
        dismissButton = {
            TextButton(enabled = !isLoading, onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
private fun ImportLocalNameDialog(
    uri: Uri,
    onDismiss: () -> Unit,
    onSubmit: (name: String, makeDefault: Boolean, onDone: (String?) -> Unit) -> Unit
) {
    val palette = LocalTerminalPalette.current
    val suggested = remember(uri) {
        uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.')
            ?.takeIf { it.isNotBlank() } ?: "Local M3U Playlist"
    }
    var name by remember { mutableStateOf(suggested) }
    var makeDefault by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isLoading) onDismiss() },
        containerColor = palette.card,
        titleContentColor = palette.text,
        title = { Text("Import Local Playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "File selected via Storage Access Framework. Parsed channels are stored privately on-device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    label = { Text("Custom Playlist Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalSecondary,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.text,
                        unfocusedTextColor = palette.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = makeDefault, onCheckedChange = { makeDefault = it })
                    Text("Set as default playlist", color = palette.text)
                }
                if (errorMessage != null) {
                    Text(errorMessage!!, style = MaterialTheme.typography.bodySmall, color = TerminalError)
                }
            }
        },
        confirmButton = {
            NeonGradientButton(
                text = if (isLoading) "Importing..." else "Import",
                enabled = !isLoading,
                onClick = {
                    isLoading = true
                    onSubmit(name, makeDefault) { err ->
                        isLoading = false
                        errorMessage = err
                    }
                }
            )
        },
        dismissButton = {
            TextButton(enabled = !isLoading, onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
private fun EditPlaylistDialog(
    playlist: PlaylistSource,
    onDismiss: () -> Unit,
    onSave: (name: String, url: String, onDone: (String?) -> Unit) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var name by remember(playlist) { mutableStateOf(playlist.name) }
    var url by remember(playlist) { mutableStateOf(playlist.urlOrUri) }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        containerColor = palette.card,
        titleContentColor = palette.text,
        title = { Text("Edit Playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    label = { Text("Playlist Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalSecondary,
                        unfocusedBorderColor = palette.border,
                        focusedTextColor = palette.text,
                        unfocusedTextColor = palette.text
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (playlist.type == PlaylistType.REMOTE_URL) {
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it; errorMessage = null },
                        label = { Text("Playlist URL") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TerminalSecondary,
                            unfocusedBorderColor = palette.border,
                            focusedTextColor = palette.text,
                            unfocusedTextColor = palette.text
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (errorMessage != null) {
                    Text(errorMessage!!, style = MaterialTheme.typography.bodySmall, color = TerminalError)
                }
            }
        },
        confirmButton = {
            NeonGradientButton(
                text = if (isSaving) "Saving..." else "Save",
                enabled = !isSaving,
                onClick = {
                    isSaving = true
                    onSave(name, url) { err ->
                        isSaving = false
                        errorMessage = err
                    }
                }
            )
        },
        dismissButton = {
            TextButton(enabled = !isSaving, onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}
