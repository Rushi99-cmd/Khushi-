package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PublishedWithChanges
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.models.AdminChannelDto
import com.example.models.AdminSessionState
import com.example.models.AdminSourceDto
import com.example.ui.AdminDashboardUiState
import com.example.ui.components.NeonGradientButton
import com.example.ui.components.NeonOutlinedButton
import com.example.ui.theme.LocalTerminalPalette
import com.example.ui.theme.NeonAccentGradient
import com.example.ui.theme.TerminalError
import com.example.ui.theme.TerminalPrimary
import com.example.ui.theme.TerminalSecondary
import com.example.ui.theme.TerminalSuccess
import com.example.ui.theme.TerminalWarning
import com.example.utils.Formatters
import kotlinx.coroutines.delay

@Composable
fun AdminDashboardScreen(
    session: AdminSessionState,
    state: AdminDashboardUiState,
    onRefresh: () -> Unit,
    onSignOut: () -> Unit,
    onBack: () -> Unit,
    onAddSource: (name: String, url: String, isPrimary: Boolean, isBackup: Boolean, useProxy: Boolean) -> Unit,
    onUpdateSource: (source: AdminSourceDto, name: String, url: String, isPrimary: Boolean, isBackup: Boolean, isEnabled: Boolean, useProxy: Boolean) -> Unit,
    onDeleteSource: (String) -> Unit,
    onActivatePrimary: (String) -> Unit,
    onRefreshSource: (String) -> Unit,
    onUpdateChannel: (channelId: String, name: String?, logoUrl: String?, groupTitle: String?, channelNumber: Int?, enabled: Boolean?) -> Unit,
    onPushConfig: (heartbeatSec: Int, timeoutSec: Int, retentionDays: Int, analyticsEnabled: Boolean, maintenanceMsg: String) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var autoRefreshLive by remember { mutableStateOf(true) }

    BackHandler { onBack() }

    LaunchedEffect(selectedTab, autoRefreshLive) {
        if (selectedTab == 0 && autoRefreshLive) {
            while (true) {
                delay(10_000L)
                onRefresh()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                }
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Super Admin Console",
                            style = MaterialTheme.typography.titleLarge,
                            color = palette.text
                        )
                        Surface(
                            color = TerminalSuccess.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "OWNER",
                                style = MaterialTheme.typography.labelSmall,
                                color = TerminalSuccess,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "${session.username} • Token expires ${Formatters.formatTimestamp(session.expiresAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonOutlinedButton(
                    text = "Refresh",
                    onClick = onRefresh,
                    leadingIcon = {
                        Icon(Icons.Filled.Refresh, null, tint = TerminalSecondary, modifier = Modifier.size(18.dp))
                    }
                )
                NeonOutlinedButton(
                    text = "Sign Out",
                    onClick = onSignOut,
                    leadingIcon = {
                        Icon(Icons.AutoMirrored.Filled.Logout, null, tint = TerminalPrimary, modifier = Modifier.size(18.dp))
                    },
                    modifier = Modifier.testTag("admin_logout_button")
                )
            }
        }

        if (state.isLoading) {
            LinearProgressIndicator(
                color = TerminalPrimary,
                trackColor = palette.elevated,
                modifier = Modifier.fillMaxWidth()
            )
        }

        state.errorMessage?.let { err ->
            Surface(
                color = TerminalError.copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, TerminalError),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    color = TerminalError,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        val tabs = listOf("Live Analytics", "Sources & Proxy", "Channels", "Config & Audit")
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = palette.card,
            contentColor = TerminalPrimary
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = if (selectedTab == index) TerminalPrimary else palette.textSecondary
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> LiveAnalyticsTab(
                state = state,
                autoRefresh = autoRefreshLive,
                onToggleAutoRefresh = { autoRefreshLive = it }
            )
            1 -> AdminSourcesTab(
                sources = state.sources,
                onAddSource = onAddSource,
                onUpdateSource = onUpdateSource,
                onDeleteSource = onDeleteSource,
                onActivatePrimary = onActivatePrimary,
                onRefreshSource = onRefreshSource
            )
            2 -> AdminChannelsTab(
                channels = state.channels,
                onUpdateChannel = onUpdateChannel
            )
            3 -> AdminConfigAuditTab(
                state = state,
                onPushConfig = onPushConfig
            )
        }
    }
}

@Composable
private fun LiveAnalyticsTab(
    state: AdminDashboardUiState,
    autoRefresh: Boolean,
    onToggleAutoRefresh: (Boolean) -> Unit
) {
    val palette = LocalTerminalPalette.current
    val live = state.liveAnalytics

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Real-time telemetry • Last updated ${Formatters.formatTimestamp(live.generatedAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Live Poll (10s)", style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                    Switch(
                        checked = autoRefresh,
                        onCheckedChange = onToggleAutoRefresh,
                        colors = SwitchDefaults.colors(checkedTrackColor = TerminalPrimary)
                    )
                }
            }
        }

        // KPI Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                KpiCard(
                    title = "Concurrent Viewers",
                    value = live.totalConcurrentViewers.toString(),
                    subtitle = "Active non-expired",
                    accent = TerminalPrimary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Peak Concurrent",
                    value = live.peakConcurrentViewers.toString(),
                    subtitle = Formatters.formatTimestamp(live.peakConcurrentAt),
                    accent = TerminalSecondary,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "TV / Mobile",
                    value = "${live.tvViewers} / ${live.mobileViewers}",
                    subtitle = "Active devices",
                    accent = TerminalSuccess,
                    modifier = Modifier.weight(1f)
                )
                KpiCard(
                    title = "Playback Errors",
                    value = live.recentErrors.size.toString(),
                    subtitle = "Within retention",
                    accent = TerminalError,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // App Version Breakdown
        if (live.appVersionCounts.isNotEmpty()) {
            item {
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Active App Versions", style = MaterialTheme.typography.titleMedium, color = palette.text)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            live.appVersionCounts.forEach { (ver, count) ->
                                Surface(color = palette.elevated, shape = RoundedCornerShape(8.dp)) {
                                    Text(
                                        text = "v$ver: $count",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TerminalSecondary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Channel Viewer Counts
        item {
            Text("Channel Viewer Counts", style = MaterialTheme.typography.titleLarge, color = palette.text)
        }
        if (live.channelViewerCounts.isEmpty()) {
            item {
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No active viewers right now. Counts reflect real playback sessions only.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.textSecondary,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(live.channelViewerCounts, key = { it.channelId.ifEmpty { it.channelName } }) { chCount ->
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = chCount.channelName,
                            style = MaterialTheme.typography.titleSmall,
                            color = palette.text,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(color = TerminalPrimary.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp)) {
                            Text(
                                text = "${chCount.viewers} watching",
                                style = MaterialTheme.typography.labelMedium,
                                color = TerminalPrimary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Active Anonymous Sessions
        item {
            Text(
                text = "Active Anonymous Sessions (${live.activeSessions.size})",
                style = MaterialTheme.typography.titleLarge,
                color = palette.text
            )
        }
        items(live.activeSessions, key = { it.sessionId }) { session ->
            val heartbeatAgeSec = ((live.generatedAt - session.lastHeartbeatAt).coerceAtLeast(0L) / 1000L)
            Surface(
                color = palette.card,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, palette.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = if (session.deviceType == "ANDROID_TV") Icons.Filled.Tv else Icons.Filled.PhoneAndroid,
                        contentDescription = null,
                        tint = TerminalSecondary
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(session.channelName, style = MaterialTheme.typography.titleSmall, color = palette.text)
                        Text(
                            text = "SID ${session.sessionId.take(8)}… • ${session.deviceType} • v${session.appVersion}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textSecondary
                        )
                    }
                    Text(
                        text = "${heartbeatAgeSec}s ago",
                        style = MaterialTheme.typography.labelSmall,
                        color = TerminalSuccess
                    )
                }
            }
        }

        // Recent Playback Errors
        if (live.recentErrors.isNotEmpty()) {
            item {
                Text("Recent Playback Errors", style = MaterialTheme.typography.titleLarge, color = palette.text)
            }
            items(live.recentErrors, key = { it.id }) { err ->
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, TerminalError.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(Icons.Filled.ErrorOutline, null, tint = TerminalError)
                        Column {
                            Text(
                                text = "${err.channelName} (${err.errorCode})",
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.text
                            )
                            Text(err.errorMessage, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
                            Text(
                                text = "${err.deviceType} • v${err.appVersion} • ${Formatters.formatTimestamp(err.timestamp)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.textSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val palette = LocalTerminalPalette.current
    Surface(
        color = palette.card,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = palette.textSecondary, maxLines = 1)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = accent, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary, maxLines = 1)
        }
    }
}

@Composable
private fun AdminSourcesTab(
    sources: List<AdminSourceDto>,
    onAddSource: (name: String, url: String, isPrimary: Boolean, isBackup: Boolean, useProxy: Boolean) -> Unit,
    onUpdateSource: (source: AdminSourceDto, name: String, url: String, isPrimary: Boolean, isBackup: Boolean, isEnabled: Boolean, useProxy: Boolean) -> Unit,
    onDeleteSource: (String) -> Unit,
    onActivatePrimary: (String) -> Unit,
    onRefreshSource: (String) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var showAddDialog by remember { mutableStateOf(false) }
    var editingSource by remember { mutableStateOf<AdminSourceDto?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Authorized Backend Sources (${sources.size})",
                style = MaterialTheme.typography.titleLarge,
                color = palette.text
            )
            NeonGradientButton(
                text = "Add Source",
                onClick = { showAddDialog = true },
                leadingIcon = { Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(sources, key = { it.id }) { source ->
                Surface(
                    color = palette.card,
                    shape = RoundedCornerShape(16.dp),
                    border = if (source.isPrimary) BorderStroke(1.5.dp, NeonAccentGradient) else BorderStroke(1.dp, palette.border),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(source.name, style = MaterialTheme.typography.titleMedium, color = palette.text)
                                    if (source.isPrimary) {
                                        BadgePill("PRIMARY", TerminalPrimary)
                                    } else if (source.isBackup) {
                                        BadgePill("BACKUP", TerminalWarning)
                                    }
                                    if (source.useProxy) {
                                        BadgePill("PROXY PROTECTED", TerminalSecondary)
                                    }
                                }
                                Text(
                                    text = source.upstreamUrl,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${source.channelCount} channels • Refreshed ${Formatters.formatTimestamp(source.lastRefreshedAt)}" +
                                        (source.lastError?.let { " • Error: $it" } ?: ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (source.lastError != null) TerminalError else palette.textSecondary
                                )
                            }

                            Switch(
                                checked = source.isEnabled,
                                onCheckedChange = { enabled ->
                                    onUpdateSource(
                                        source,
                                        source.name,
                                        source.upstreamUrl,
                                        source.isPrimary,
                                        source.isBackup,
                                        enabled,
                                        source.useProxy
                                    )
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = TerminalPrimary)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (!source.isPrimary) {
                                NeonOutlinedButton(
                                    text = "Set Primary",
                                    onClick = { onActivatePrimary(source.id) },
                                    leadingIcon = { Icon(Icons.Filled.Star, null, tint = TerminalPrimary, modifier = Modifier.size(16.dp)) }
                                )
                            }
                            NeonOutlinedButton(
                                text = "Refresh Upstream",
                                onClick = { onRefreshSource(source.id) },
                                leadingIcon = { Icon(Icons.Filled.Refresh, null, tint = TerminalSecondary, modifier = Modifier.size(16.dp)) }
                            )
                            IconButton(onClick = { editingSource = source }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                Icon(Icons.Filled.Edit, "Edit source", tint = palette.text)
                            }
                            if (sources.size > 1) {
                                IconButton(onClick = { onDeleteSource(source.id) }, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Icon(Icons.Filled.Delete, "Delete source", tint = TerminalError)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        SourceEditorDialog(
            title = "Add Authorized Playlist Source",
            initialName = "",
            initialUrl = "",
            initialPrimary = false,
            initialBackup = true,
            initialProxy = true,
            onDismiss = { showAddDialog = false },
            onSave = { name, url, primary, backup, proxy ->
                onAddSource(name, url, primary, backup, proxy)
                showAddDialog = false
            }
        )
    }

    editingSource?.let { target ->
        SourceEditorDialog(
            title = "Edit Source",
            initialName = target.name,
            initialUrl = target.upstreamUrl,
            initialPrimary = target.isPrimary,
            initialBackup = target.isBackup,
            initialProxy = target.useProxy,
            onDismiss = { editingSource = null },
            onSave = { name, url, primary, backup, proxy ->
                onUpdateSource(target, name, url, primary, backup, target.isEnabled, proxy)
                editingSource = null
            }
        )
    }
}

@Composable
private fun AdminChannelsTab(
    channels: List<AdminChannelDto>,
    onUpdateChannel: (channelId: String, name: String?, logoUrl: String?, groupTitle: String?, channelNumber: Int?, enabled: Boolean?) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var filter by remember { mutableStateOf("") }
    var editingChannel by remember { mutableStateOf<AdminChannelDto?>(null) }

    val filtered = remember(channels, filter) {
        val q = filter.trim()
        if (q.isEmpty()) channels
        else channels.filter {
            it.name.contains(q, ignoreCase = true) ||
                it.groupTitle.contains(q, ignoreCase = true) ||
                it.channelNumber.toString() == q
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = filter,
            onValueChange = { filter = it },
            placeholder = { Text("Search managed channels...") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TerminalSecondary,
                unfocusedBorderColor = palette.border,
                focusedTextColor = palette.text,
                unfocusedTextColor = palette.text
            ),
            modifier = Modifier.fillMaxWidth()
        )

        if (filtered.isEmpty()) {
            Text(
                text = "No channels cached on backend yet. Use 'Refresh Upstream' on a source in Sources & Proxy.",
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textSecondary
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { ch ->
                    Surface(
                        color = palette.card,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, palette.border),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "#${Formatters.formatChannelNumber(ch.channelNumber)} • ${ch.name}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (ch.enabled) palette.text else palette.textSecondary
                                )
                                Text(
                                    text = "${ch.groupTitle} • ${if (ch.enabled) "Enabled" else "Disabled"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (ch.enabled) TerminalSecondary else TerminalError
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { editingChannel = ch },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Edit, "Edit channel metadata", tint = palette.text)
                                }
                                Switch(
                                    checked = ch.enabled,
                                    onCheckedChange = { enabled ->
                                        onUpdateChannel(ch.id, null, null, null, null, enabled)
                                    },
                                    colors = SwitchDefaults.colors(checkedTrackColor = TerminalPrimary)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    editingChannel?.let { target ->
        var name by remember(target) { mutableStateOf(target.name) }
        var category by remember(target) { mutableStateOf(target.groupTitle) }
        var logoUrl by remember(target) { mutableStateOf(target.logoUrl.orEmpty()) }
        var numberStr by remember(target) { mutableStateOf(target.channelNumber.toString()) }

        AlertDialog(
            onDismissRequest = { editingChannel = null },
            containerColor = palette.card,
            titleContentColor = palette.text,
            title = { Text("Edit Channel Metadata") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Channel Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = numberStr,
                        onValueChange = { numberStr = it.filter(Char::isDigit) },
                        label = { Text("Channel Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = logoUrl,
                        onValueChange = { logoUrl = it },
                        label = { Text("Logo URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                NeonGradientButton(
                    text = "Save Metadata",
                    onClick = {
                        onUpdateChannel(
                            target.id,
                            name.trim().ifBlank { null },
                            logoUrl.trim(),
                            category.trim().ifBlank { null },
                            numberStr.toIntOrNull(),
                            null
                        )
                        editingChannel = null
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { editingChannel = null }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }
}

@Composable
private fun AdminConfigAuditTab(
    state: AdminDashboardUiState,
    onPushConfig: (heartbeatSec: Int, timeoutSec: Int, retentionDays: Int, analyticsEnabled: Boolean, maintenanceMsg: String) -> Unit
) {
    val palette = LocalTerminalPalette.current
    val cfg = state.liveAnalytics.config
    var heartbeatSec by remember(cfg) { mutableStateOf(cfg.heartbeatIntervalSeconds.toString()) }
    var timeoutSec by remember(cfg) { mutableStateOf(cfg.sessionTimeoutSeconds.toString()) }
    var retentionDays by remember(cfg) { mutableStateOf(cfg.retentionDays.toString()) }
    var analyticsEnabled by remember(cfg) { mutableStateOf(cfg.analyticsEnabled) }
    var maintenanceMsg by remember(cfg) { mutableStateOf(cfg.maintenanceMessage) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 24.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Surface(
                color = palette.card,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, palette.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Remote Config Push (Current v${cfg.configVersion})",
                        style = MaterialTheme.typography.titleLarge,
                        color = palette.text
                    )
                    Text(
                        text = "Updates apply to client apps without APK reinstallation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = heartbeatSec,
                            onValueChange = { heartbeatSec = it.filter(Char::isDigit) },
                            label = { Text("Heartbeat (s)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = timeoutSec,
                            onValueChange = { timeoutSec = it.filter(Char::isDigit) },
                            label = { Text("Session Timeout (s)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = retentionDays,
                            onValueChange = { retentionDays = it.filter(Char::isDigit) },
                            label = { Text("Retention (days)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = maintenanceMsg,
                        onValueChange = { maintenanceMsg = it },
                        label = { Text("Notice / Maintenance Banner (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Global Viewing Analytics Enabled", color = palette.text)
                        Switch(
                            checked = analyticsEnabled,
                            onCheckedChange = { analyticsEnabled = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = TerminalPrimary)
                        )
                    }
                    NeonGradientButton(
                        text = "Push Config Update",
                        onClick = {
                            onPushConfig(
                                heartbeatSec.toIntOrNull() ?: 30,
                                timeoutSec.toIntOrNull() ?: 75,
                                retentionDays.toIntOrNull() ?: 7,
                                analyticsEnabled,
                                maintenanceMsg
                            )
                        },
                        leadingIcon = { Icon(Icons.Filled.PublishedWithChanges, null, tint = Color.White) }
                    )
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.Shield, null, tint = TerminalSecondary)
                Text("Admin Audit Log (${state.auditLogs.size})", style = MaterialTheme.typography.titleLarge, color = palette.text)
            }
        }

        items(state.auditLogs, key = { it.id }) { log ->
            Surface(
                color = palette.card,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, palette.border),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(log.action, style = MaterialTheme.typography.labelMedium, color = TerminalPrimary)
                        Text(
                            Formatters.formatTimestamp(log.timestamp),
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.textSecondary
                        )
                    }
                    Text(log.details, style = MaterialTheme.typography.bodySmall, color = palette.text)
                    Text("Actor: ${log.actor}", style = MaterialTheme.typography.labelSmall, color = palette.textSecondary)
                }
            }
        }
    }
}

@Composable
private fun BadgePill(text: String, color: Color) {
    Surface(color = color.copy(alpha = 0.18f), shape = RoundedCornerShape(6.dp)) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun SourceEditorDialog(
    title: String,
    initialName: String,
    initialUrl: String,
    initialPrimary: Boolean,
    initialBackup: Boolean,
    initialProxy: Boolean,
    onDismiss: () -> Unit,
    onSave: (name: String, url: String, isPrimary: Boolean, isBackup: Boolean, useProxy: Boolean) -> Unit
) {
    val palette = LocalTerminalPalette.current
    var name by remember { mutableStateOf(initialName) }
    var url by remember { mutableStateOf(initialUrl) }
    var isPrimary by remember { mutableStateOf(initialPrimary) }
    var isBackup by remember { mutableStateOf(initialBackup) }
    var useProxy by remember { mutableStateOf(initialProxy) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.card,
        titleContentColor = palette.text,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Source Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Upstream M3U / M3U8 URL (Kept on Backend)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPrimary, onCheckedChange = { isPrimary = it })
                    Text("Primary Source", color = palette.text)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isBackup, onCheckedChange = { isBackup = it })
                    Text("Backup Source", color = palette.text)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = useProxy, onCheckedChange = { useProxy = it })
                    Text("Hide Upstream URL via Backend Proxy", color = palette.text)
                }
            }
        },
        confirmButton = {
            NeonGradientButton(
                text = "Save Source",
                enabled = name.isNotBlank() && url.isNotBlank(),
                onClick = { onSave(name.trim(), url.trim(), isPrimary, isBackup, useProxy) }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}
