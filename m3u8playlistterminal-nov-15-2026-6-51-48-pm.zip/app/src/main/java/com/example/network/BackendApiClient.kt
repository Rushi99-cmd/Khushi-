package com.example.network

import com.example.models.AdminChannelDto
import com.example.models.AdminChannelPatchRequest
import com.example.models.AdminChannelsResponse
import com.example.models.AdminConfigUpdateRequest
import com.example.models.AdminLoginRequest
import com.example.models.AdminLoginResponse
import com.example.models.AdminSessionState
import com.example.models.AdminSourceDto
import com.example.models.AdminSourceUpsertRequest
import com.example.models.AdminSourcesResponse
import com.example.models.AnalyticsEventRequest
import com.example.models.AnalyticsEventResponse
import com.example.models.AuditLogEntryDto
import com.example.models.AuditLogsResponse
import com.example.models.ClientTokenResponse
import com.example.models.LiveAnalyticsResponse
import com.example.models.RemoteBootstrapResponse
import com.example.models.RemoteConfigDto
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class AdminUnauthorizedException(message: String) : IllegalStateException(message)

class BackendApiClient(
    private val httpClient: OkHttpClient = PlaylistNetworkClient.okHttpClient
) {
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val tokenMutex = Mutex()
    private var cachedClientToken: String? = null
    private var cachedClientTokenExpiresAt: Long = 0L
    private var cachedClientBaseUrl: String = ""

    private fun normalizeBaseUrl(rawUrl: String): String {
        val cleaned = rawUrl.trim().trimEnd('/')
        require(cleaned.startsWith("http://", ignoreCase = true) || cleaned.startsWith("https://", ignoreCase = true)) {
            "Backend server URL must start with http:// or https://"
        }
        return cleaned
    }

    private suspend fun getOrFetchClientToken(baseUrl: String): String = tokenMutex.withLock {
        val now = System.currentTimeMillis()
        val existing = cachedClientToken
        if (existing != null && cachedClientBaseUrl == baseUrl && now < cachedClientTokenExpiresAt - 10_000L) {
            return@withLock existing
        }
        val body = "{}".toRequestBody(jsonMediaType)
        val request = Request.Builder()
            .url("$baseUrl/api/client/token")
            .post(body)
            .build()

        val responseText = executeCall(request)
        val parsed = json.decodeFromString<ClientTokenResponse>(responseText)
        cachedClientToken = parsed.token
        cachedClientTokenExpiresAt = parsed.expiresAt
        cachedClientBaseUrl = baseUrl
        parsed.token
    }

    suspend fun fetchRemoteBootstrap(rawBaseUrl: String): Result<RemoteBootstrapResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val token = getOrFetchClientToken(baseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/client/bootstrap")
                .header("Authorization", "Bearer $token")
                .get()
                .build()
            val responseText = executeCall(request)
            json.decodeFromString<RemoteBootstrapResponse>(responseText)
        }
    }

    suspend fun sendAnalyticsEvent(
        rawBaseUrl: String,
        event: AnalyticsEventRequest
    ): Result<AnalyticsEventResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val token = getOrFetchClientToken(baseUrl)
            val payload = json.encodeToString(event).toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url("$baseUrl/api/analytics/event")
                .header("Authorization", "Bearer $token")
                .post(payload)
                .build()
            val responseText = executeCall(request)
            json.decodeFromString<AnalyticsEventResponse>(responseText)
        }
    }

    suspend fun adminLogin(
        rawBaseUrl: String,
        username: String,
        password: String
    ): Result<AdminSessionState> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val payload = json.encodeToString(AdminLoginRequest(username.trim(), password))
                .toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/login")
                .post(payload)
                .build()
            val responseText = executeCall(request)
            val resp = json.decodeFromString<AdminLoginResponse>(responseText)
            AdminSessionState(
                token = resp.token,
                expiresAt = resp.expiresAt,
                username = resp.username
            )
        }
    }

    suspend fun adminLogout(rawBaseUrl: String, adminToken: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/logout")
                .header("Authorization", "Bearer $adminToken")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun fetchLiveAnalytics(rawBaseUrl: String, adminToken: String): Result<LiveAnalyticsResponse> =
        withContext(Dispatchers.IO) {
            runCatching {
                val baseUrl = normalizeBaseUrl(rawBaseUrl)
                val request = Request.Builder()
                    .url("$baseUrl/api/admin/analytics/live")
                    .header("Authorization", "Bearer $adminToken")
                    .get()
                    .build()
                val responseText = executeCall(request, isAdminCall = true)
                json.decodeFromString<LiveAnalyticsResponse>(responseText)
            }
        }

    suspend fun fetchAdminSources(rawBaseUrl: String, adminToken: String): Result<List<AdminSourceDto>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val baseUrl = normalizeBaseUrl(rawBaseUrl)
                val request = Request.Builder()
                    .url("$baseUrl/api/admin/sources")
                    .header("Authorization", "Bearer $adminToken")
                    .get()
                    .build()
                json.decodeFromString<AdminSourcesResponse>(executeCall(request, isAdminCall = true)).sources
            }
        }

    suspend fun addAdminSource(
        rawBaseUrl: String,
        adminToken: String,
        body: AdminSourceUpsertRequest
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/sources")
                .header("Authorization", "Bearer $adminToken")
                .post(json.encodeToString(body).toRequestBody(jsonMediaType))
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun updateAdminSource(
        rawBaseUrl: String,
        adminToken: String,
        sourceId: String,
        body: AdminSourceUpsertRequest
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/sources/$sourceId")
                .header("Authorization", "Bearer $adminToken")
                .put(json.encodeToString(body).toRequestBody(jsonMediaType))
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun deleteAdminSource(
        rawBaseUrl: String,
        adminToken: String,
        sourceId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/sources/$sourceId")
                .header("Authorization", "Bearer $adminToken")
                .delete()
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun activatePrimarySource(
        rawBaseUrl: String,
        adminToken: String,
        sourceId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/sources/$sourceId/activate-primary")
                .header("Authorization", "Bearer $adminToken")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun refreshAdminSource(
        rawBaseUrl: String,
        adminToken: String,
        sourceId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/sources/$sourceId/refresh")
                .header("Authorization", "Bearer $adminToken")
                .post("{}".toRequestBody(jsonMediaType))
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun fetchAdminChannels(rawBaseUrl: String, adminToken: String): Result<List<AdminChannelDto>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val baseUrl = normalizeBaseUrl(rawBaseUrl)
                val request = Request.Builder()
                    .url("$baseUrl/api/admin/channels")
                    .header("Authorization", "Bearer $adminToken")
                    .get()
                    .build()
                json.decodeFromString<AdminChannelsResponse>(executeCall(request, isAdminCall = true)).channels
            }
        }

    suspend fun patchAdminChannel(
        rawBaseUrl: String,
        adminToken: String,
        channelId: String,
        patch: AdminChannelPatchRequest
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/channels/$channelId")
                .header("Authorization", "Bearer $adminToken")
                .patch(json.encodeToString(patch).toRequestBody(jsonMediaType))
                .build()
            executeCall(request, isAdminCall = true)
            Unit
        }
    }

    suspend fun pushRemoteConfig(
        rawBaseUrl: String,
        adminToken: String,
        config: AdminConfigUpdateRequest
    ): Result<RemoteConfigDto> = withContext(Dispatchers.IO) {
        runCatching {
            val baseUrl = normalizeBaseUrl(rawBaseUrl)
            val request = Request.Builder()
                .url("$baseUrl/api/admin/config")
                .header("Authorization", "Bearer $adminToken")
                .put(json.encodeToString(config).toRequestBody(jsonMediaType))
                .build()
            val text = executeCall(request, isAdminCall = true)
            val root = json.parseToJsonElement(text).jsonObject
            json.decodeFromString<RemoteConfigDto>(root["config"].toString())
        }
    }

    suspend fun fetchAuditLogs(rawBaseUrl: String, adminToken: String): Result<List<AuditLogEntryDto>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val baseUrl = normalizeBaseUrl(rawBaseUrl)
                val request = Request.Builder()
                    .url("$baseUrl/api/admin/audit-logs")
                    .header("Authorization", "Bearer $adminToken")
                    .get()
                    .build()
                json.decodeFromString<AuditLogsResponse>(executeCall(request, isAdminCall = true)).logs
            }
        }

    private fun executeCall(request: Request, isAdminCall: Boolean = false): String {
        httpClient.newCall(request).execute().use { response ->
            val bodyString = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                return bodyString
            }
            val serverError = runCatching {
                json.parseToJsonElement(bodyString).jsonObject["error"]?.jsonPrimitive?.content
            }.getOrNull()

            if (response.code == 401 && isAdminCall) {
                throw AdminUnauthorizedException(serverError ?: "Admin session expired or unauthorized.")
            }
            if (response.code == 401 && !isAdminCall) {
                cachedClientToken = null
            }
            val message = serverError ?: when (response.code) {
                429 -> "Rate limit exceeded. Please wait before retrying."
                401 -> "Authentication required or invalid credentials."
                404 -> "Backend endpoint not found."
                else -> "Server returned HTTP ${response.code}"
            }
            throw IOException(message)
        }
    }
}
