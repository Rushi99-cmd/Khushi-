package com.example.network

import com.example.playlist.M3uParser
import com.example.playlist.ParsedChannelEntry
import com.example.utils.AppConstants
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Streaming
import retrofit2.http.Url

interface PlaylistApiService {
    @Streaming
    @GET
    suspend fun fetchPlaylist(
        @Url url: String,
        @Header("User-Agent") userAgent: String,
        @Header("Accept") accept: String = "application/x-mpegURL, application/vnd.apple.mpegurl, audio/x-mpegurl, text/plain, */*"
    ): Response<ResponseBody>
}

sealed interface PlaylistFetchResult {
    data class Success(
        val entries: List<ParsedChannelEntry>,
        val resolvedUrl: String
    ) : PlaylistFetchResult

    data class Failure(val errorMessage: String) : PlaylistFetchResult
}

object PlaylistNetworkClient {

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private val apiService: PlaylistApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://localhost/")
            .client(okHttpClient)
            .build()
            .create(PlaylistApiService::class.java)
    }

    suspend fun fetchAndParse(
        url: String,
        playlistId: String,
        customUserAgent: String = ""
    ): PlaylistFetchResult = withContext(Dispatchers.IO) {
        val ua = customUserAgent.ifBlank { AppConstants.DEFAULT_USER_AGENT }
        try {
            val response = apiService.fetchPlaylist(url = url, userAgent = ua)
            if (!response.isSuccessful) {
                val code = response.code()
                val msg = when (code) {
                    401, 403 -> "Access denied (HTTP $code). Check playlist authorization."
                    404 -> "Playlist endpoint not found (HTTP 404)."
                    in 500..599 -> "Playlist server is temporarily unavailable (HTTP $code)."
                    else -> "Server returned HTTP $code."
                }
                return@withContext PlaylistFetchResult.Failure(msg)
            }

            val body = response.body()
                ?: return@withContext PlaylistFetchResult.Failure("Server returned an empty playlist response.")

            val resolvedUrl = response.raw().request.url.toString()
            val parsedEntries = body.charStream().use { reader ->
                M3uParser.parse(reader = reader, playlistId = playlistId, baseUrl = resolvedUrl)
            }

            if (parsedEntries.isEmpty()) {
                return@withContext PlaylistFetchResult.Failure(
                    "No valid M3U/M3U8 stream entries were found in this playlist."
                )
            }

            PlaylistFetchResult.Success(entries = parsedEntries, resolvedUrl = resolvedUrl)
        } catch (e: UnknownHostException) {
            PlaylistFetchResult.Failure("Unable to reach host. Check your internet connection or URL.")
        } catch (e: SocketTimeoutException) {
            PlaylistFetchResult.Failure("Connection timed out while loading playlist.")
        } catch (e: SSLException) {
            PlaylistFetchResult.Failure("Secure SSL/TLS handshake failed for this server.")
        } catch (e: IOException) {
            PlaylistFetchResult.Failure("Network error: ${e.localizedMessage ?: "Unable to read playlist"}")
        } catch (e: Exception) {
            PlaylistFetchResult.Failure("Unexpected error loading playlist: ${e.localizedMessage ?: "Unknown error"}")
        }
    }
}
