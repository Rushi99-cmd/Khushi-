package com.example.player

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import com.example.models.AspectRatioMode
import com.example.models.BufferProfile
import com.example.models.Channel
import com.example.models.PlayerUiState
import com.example.models.TrackOption
import com.example.network.PlaylistNetworkClient
import com.example.utils.AppConstants
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

@OptIn(UnstableApi::class)
class ExoPlayerManager(private val context: Context) {

    private val appContext = context.applicationContext
    private var exoPlayer: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var currentBufferProfile: BufferProfile = BufferProfile.BALANCED
    private var currentUserAgent: String = AppConstants.DEFAULT_USER_AGENT

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    var onPlaybackErrorCallback: ((Channel, String, String) -> Unit)? = null

    private val playerListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            updatePlaybackSnapshot()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlaybackSnapshot()
        }

        override fun onTracksChanged(tracks: Tracks) {
            extractTracks(tracks)
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            _uiState.update {
                it.copy(videoWidth = videoSize.width, videoHeight = videoSize.height)
            }
        }

        override fun onVolumeChanged(volume: Float) {
            _uiState.update {
                it.copy(volume = volume, isMuted = volume == 0f)
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val friendly = translatePlaybackError(error)
            Log.e("ExoPlayerManager", "Playback error [${error.errorCodeName}]: ${error.message}", error)
            _uiState.value.currentChannel?.let { ch ->
                onPlaybackErrorCallback?.invoke(
                    ch,
                    error.errorCodeName,
                    friendly.second
                )
            }
            _uiState.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    errorTitle = friendly.first,
                    errorMessage = friendly.second,
                    errorDetails = "${error.errorCodeName}: ${error.localizedMessage ?: "Stream error"}"
                )
            }
        }
    }

    fun getOrCreatePlayer(
        bufferProfile: BufferProfile = currentBufferProfile,
        userAgent: String = currentUserAgent
    ): ExoPlayer {
        val resolvedUa = userAgent.ifBlank { AppConstants.DEFAULT_USER_AGENT }
        val existing = exoPlayer
        if (existing != null && bufferProfile == currentBufferProfile && resolvedUa == currentUserAgent) {
            return existing
        }

        val previousChannel = _uiState.value.currentChannel
        val previousQueue = _uiState.value.channelQueue
        release()

        currentBufferProfile = bufferProfile
        currentUserAgent = resolvedUa

        val httpFactory = OkHttpDataSource.Factory(PlaylistNetworkClient.okHttpClient)
            .setUserAgent(resolvedUa)

        val mediaSourceFactory = DefaultMediaSourceFactory(appContext)
            .setDataSourceFactory(httpFactory)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                bufferProfile.minBufferMs,
                bufferProfile.maxBufferMs,
                bufferProfile.bufferForPlaybackMs,
                bufferProfile.bufferForPlaybackAfterRebufferMs
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(playerListener)
        exoPlayer = player

        mediaSession = runCatching {
            MediaSession.Builder(appContext, player)
                .setId("m3u8_terminal_session")
                .build()
        }.getOrNull()

        if (previousChannel != null) {
            _uiState.update { it.copy(currentChannel = previousChannel, channelQueue = previousQueue) }
        }
        return player
    }

    fun playChannel(
        channel: Channel,
        queue: List<Channel>,
        aspectRatio: AspectRatioMode,
        bufferProfile: BufferProfile,
        globalUserAgent: String,
        resumeIfVod: Boolean = false
    ) {
        val effectiveUserAgent = channel.userAgent?.takeIf { it.isNotBlank() }
            ?: globalUserAgent.ifBlank { AppConstants.DEFAULT_USER_AGENT }

        val player = getOrCreatePlayer(bufferProfile, effectiveUserAgent)

        _uiState.update {
            it.copy(
                currentChannel = channel,
                channelQueue = queue,
                aspectRatio = aspectRatio,
                isBuffering = true,
                errorTitle = null,
                errorMessage = null,
                errorDetails = null,
                audioTracks = emptyList(),
                subtitleTracks = emptyList(),
                videoQualities = emptyList()
            )
        }

        val mediaItem = buildMediaItem(channel)
        player.setMediaItem(mediaItem)
        if (resumeIfVod && channel.lastPositionMs > 5_000L && channel.durationMs > 0L) {
            player.seekTo(channel.lastPositionMs)
        }
        player.prepare()
        player.playWhenReady = true
    }

    fun retryCurrentChannel(bufferProfile: BufferProfile, globalUserAgent: String) {
        val state = _uiState.value
        val channel = state.currentChannel ?: return
        playChannel(
            channel = channel,
            queue = state.channelQueue,
            aspectRatio = state.aspectRatio,
            bufferProfile = bufferProfile,
            globalUserAgent = globalUserAgent
        )
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED || player.playerError != null) {
                player.prepare()
            }
            player.play()
        }
    }

    fun seekBy(deltaMs: Long) {
        val player = exoPlayer ?: return
        if (!player.isCurrentMediaItemSeekable) return
        val target = (player.currentPosition + deltaMs).coerceIn(0L, player.duration.coerceAtLeast(0L))
        player.seekTo(target)
        updatePlaybackSnapshot()
    }

    fun seekTo(positionMs: Long) {
        val player = exoPlayer ?: return
        if (!player.isCurrentMediaItemSeekable) return
        player.seekTo(positionMs.coerceAtLeast(0L))
        updatePlaybackSnapshot()
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        exoPlayer?.volume = clamped
        _uiState.update { it.copy(volume = clamped, isMuted = clamped == 0f) }
    }

    fun toggleMute() {
        val player = exoPlayer ?: return
        val newMuted = !_uiState.value.isMuted
        val targetVol = if (newMuted) 0f else (_uiState.value.volume.takeIf { it > 0.05f } ?: 1f)
        player.volume = if (newMuted) 0f else targetVol
        _uiState.update { it.copy(isMuted = newMuted, volume = if (newMuted) it.volume else targetVol) }
    }

    fun setAspectRatio(mode: AspectRatioMode) {
        _uiState.update { it.copy(aspectRatio = mode) }
    }

    fun setFullscreen(fullscreen: Boolean) {
        _uiState.update { it.copy(isFullscreen = fullscreen) }
    }

    fun selectAudioTrack(option: TrackOption) {
        val player = exoPlayer ?: return
        val groups = player.currentTracks.groups
        val group = groups.getOrNull(option.groupIndex) ?: return
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
            .build()
    }

    fun selectSubtitleTrack(option: TrackOption?) {
        val player = exoPlayer ?: return
        val builder = player.trackSelectionParameters.buildUpon()
        if (option == null) {
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
        } else {
            val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return
            builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
        }
        player.trackSelectionParameters = builder.build()
    }

    fun selectVideoQuality(option: TrackOption?) {
        val player = exoPlayer ?: return
        val builder = player.trackSelectionParameters.buildUpon()
        if (option == null) {
            builder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
        } else {
            val group = player.currentTracks.groups.getOrNull(option.groupIndex) ?: return
            builder.setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
        }
        player.trackSelectionParameters = builder.build()
    }

    fun refreshProgressTick() {
        val player = exoPlayer ?: return
        _uiState.update {
            it.copy(
                currentPositionMs = player.currentPosition.coerceAtLeast(0L),
                durationMs = player.duration.coerceAtLeast(0L),
                bufferedPercentage = player.bufferedPercentage,
                isLive = player.isCurrentMediaItemLive || player.duration <= 0L,
                isSeekable = player.isCurrentMediaItemSeekable
            )
        }
    }

    fun pausePlayback() {
        exoPlayer?.pause()
    }

    fun release() {
        mediaSession?.release()
        mediaSession = null
        exoPlayer?.let { player ->
            player.removeListener(playerListener)
            player.stop()
            player.release()
        }
        exoPlayer = null
    }

    private fun updatePlaybackSnapshot() {
        val player = exoPlayer ?: return
        val buffering = player.playbackState == Player.STATE_BUFFERING
        _uiState.update {
            it.copy(
                isPlaying = player.isPlaying,
                isBuffering = buffering,
                isLive = player.isCurrentMediaItemLive || player.duration <= 0L,
                isSeekable = player.isCurrentMediaItemSeekable,
                currentPositionMs = player.currentPosition.coerceAtLeast(0L),
                durationMs = player.duration.coerceAtLeast(0L),
                bufferedPercentage = player.bufferedPercentage
            )
        }
    }

    private fun extractTracks(tracks: Tracks) {
        val audio = mutableListOf<TrackOption>()
        val subtitles = mutableListOf<TrackOption>()
        val video = mutableListOf<TrackOption>()

        tracks.groups.forEachIndexed { groupIdx, group ->
            when (group.type) {
                C.TRACK_TYPE_AUDIO -> {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val lang = format.language?.let { Locale(it).displayLanguage }
                            ?.takeIf { it.isNotBlank() } ?: "Audio Track ${audio.size + 1}"
                        val channels = if (format.channelCount > 0) "${format.channelCount}ch" else ""
                        val bitrate = if (format.bitrate > 0) "${format.bitrate / 1000} kbps" else ""
                        val details = listOfNotNull(
                            format.label?.takeIf { it.isNotBlank() },
                            channels.takeIf { it.isNotBlank() },
                            bitrate.takeIf { it.isNotBlank() }
                        ).joinToString(" • ")

                        audio.add(
                            TrackOption(
                                groupIndex = groupIdx,
                                trackIndex = i,
                                label = lang,
                                subLabel = details.ifBlank { format.sampleMimeType ?: "Audio" },
                                isSelected = group.isTrackSelected(i),
                                isSupported = group.isTrackSupported(i)
                            )
                        )
                    }
                }
                C.TRACK_TYPE_TEXT -> {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val lang = format.language?.let { Locale(it).displayLanguage }
                            ?.takeIf { it.isNotBlank() }
                            ?: format.label
                            ?: "Subtitle ${subtitles.size + 1}"
                        subtitles.add(
                            TrackOption(
                                groupIndex = groupIdx,
                                trackIndex = i,
                                label = lang,
                                subLabel = format.sampleMimeType ?: "Captions",
                                isSelected = group.isTrackSelected(i),
                                isSupported = group.isTrackSupported(i)
                            )
                        )
                    }
                }
                C.TRACK_TYPE_VIDEO -> {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        val res = if (format.width > 0 && format.height > 0) {
                            "${format.height}p (${format.width}×${format.height})"
                        } else {
                            "Variant ${video.size + 1}"
                        }
                        val fps = if (format.frameRate > 0f) "${format.frameRate.toInt()} fps" else ""
                        val bitrate = if (format.bitrate > 0) "${format.bitrate / 1000} kbps" else ""
                        val details = listOf(fps, bitrate).filter { it.isNotBlank() }.joinToString(" • ")

                        video.add(
                            TrackOption(
                                groupIndex = groupIdx,
                                trackIndex = i,
                                label = res,
                                subLabel = details.ifBlank { format.codecs ?: "Video stream" },
                                isSelected = group.isTrackSelected(i),
                                isSupported = group.isTrackSupported(i)
                            )
                        )
                    }
                }
            }
        }

        _uiState.update {
            it.copy(
                audioTracks = audio,
                subtitleTracks = subtitles,
                videoQualities = video.sortedByDescending { opt ->
                    opt.label.substringBefore("p").toIntOrNull() ?: 0
                }
            )
        }
    }

    private fun buildMediaItem(channel: Channel): MediaItem {
        val builder = MediaItem.Builder()
            .setMediaId(channel.id)
            .setUri(Uri.parse(channel.streamUrl))
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(channel.name)
                    .setSubtitle(channel.groupTitle)
                    .build()
            )

        val lowerUrl = channel.streamUrl.lowercase(Locale.ROOT)
        when {
            lowerUrl.contains(".m3u8") || lowerUrl.contains("m3u8") -> {
                builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            lowerUrl.contains(".mpd") -> {
                builder.setMimeType(MimeTypes.APPLICATION_MPD)
            }
            lowerUrl.endsWith(".mp4") -> {
                builder.setMimeType(MimeTypes.VIDEO_MP4)
            }
        }

        // Only configure provider-authorized DRM if explicitly present in playlist metadata
        val licenseUrl = channel.drmLicenseUrl?.takeIf {
            it.startsWith("http://", ignoreCase = true) || it.startsWith("https://", ignoreCase = true)
        }
        val schemeUuid = when (channel.drmScheme?.lowercase(Locale.ROOT)) {
            "com.widevine.alpha", "widevine" -> C.WIDEVINE_UUID
            "org.w3.clearkey", "clearkey" -> C.CLEARKEY_UUID
            "com.microsoft.playready", "playready" -> C.PLAYREADY_UUID
            else -> null
        }
        if (licenseUrl != null && schemeUuid != null) {
            builder.setDrmConfiguration(
                MediaItem.DrmConfiguration.Builder(schemeUuid)
                    .setLicenseUri(licenseUrl)
                    .build()
            )
        }

        return builder.build()
    }

    private fun translatePlaybackError(error: PlaybackException): Pair<String, String> {
        return when (error.errorCode) {
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> {
                "Connection Failed" to "Unable to connect to the stream server. Check your internet connection or try again."
            }
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> {
                val msg = error.cause?.message.orEmpty()
                when {
                    msg.contains("401") || msg.contains("403") ->
                        "Stream Unauthorized" to "The stream server rejected access (HTTP 401/403). Valid provider authorization is required."
                    msg.contains("404") ->
                        "Stream Not Found" to "This channel URL returned HTTP 404 (not found or offline)."
                    else ->
                        "HTTP Stream Error" to "The broadcast server returned an unexpected HTTP status."
                }
            }
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED -> {
                "Unsupported Stream Format" to "This stream format or playlist manifest is not supported by Media3."
            }
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> {
                "Unsupported Codec" to "Your device hardware/software decoders do not support this video or audio codec."
            }
            PlaybackException.ERROR_CODE_DRM_LICENSE_ACQUISITION_FAILED,
            PlaybackException.ERROR_CODE_DRM_PROVISIONING_FAILED,
            PlaybackException.ERROR_CODE_DRM_SCHEME_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DRM_UNSPECIFIED -> {
                "Protected / Incompatible DRM" to "This protected stream requires an authorized provider DRM license or a compatible DRM module."
            }
            PlaybackException.ERROR_CODE_IO_CLEARTEXT_NOT_PERMITTED -> {
                "Cleartext Blocked" to "Cleartext HTTP playback was blocked by network policy."
            }
            else -> {
                "Playback Interrupted" to "The stream could not be played. Try retrying or switching to another channel."
            }
        }
    }
}
