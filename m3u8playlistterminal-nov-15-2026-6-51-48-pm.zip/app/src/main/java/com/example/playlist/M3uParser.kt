package com.example.playlist

import com.example.utils.UrlValidator
import java.io.BufferedReader
import java.io.Reader
import java.io.StringReader
import java.net.URI
import java.security.MessageDigest

data class ParsedChannelEntry(
    val id: String,
    val channelNumber: Int,
    val name: String,
    val streamUrl: String,
    val logoUrl: String?,
    val groupTitle: String,
    val tvgId: String?,
    val userAgent: String?,
    val referrer: String?,
    val drmScheme: String?,
    val drmLicenseUrl: String?
)

object M3uParser {

    private val attributeRegex = Regex("""([a-zA-Z0-9_-]+)\s*=\s*"([^"]*)"""")

    fun parse(content: String, playlistId: String, baseUrl: String? = null): List<ParsedChannelEntry> {
        return parse(StringReader(content), playlistId, baseUrl)
    }

    fun parse(reader: Reader, playlistId: String, baseUrl: String? = null): List<ParsedChannelEntry> {
        val channels = mutableListOf<ParsedChannelEntry>()
        val buffered = if (reader is BufferedReader) reader else BufferedReader(reader, 16 * 1024)

        var pendingName: String? = null
        var pendingLogo: String? = null
        var pendingGroup: String? = null
        var pendingTvgId: String? = null
        var pendingChannelNo: Int? = null
        var pendingUserAgent: String? = null
        var pendingReferrer: String? = null
        var pendingDrmScheme: String? = null
        var pendingDrmLicense: String? = null
        var hasMetadata = false
        var autoNumber = 1

        buffered.useLines { lines ->
            for (rawLine in lines) {
                val line = rawLine.trim().removePrefix("\uFEFF")
                if (line.isEmpty()) continue

                when {
                    line.startsWith("#EXTM3U", ignoreCase = true) -> {
                        // Playlist header - continue parsing entries
                    }

                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        hasMetadata = true
                        val attributes = mutableMapOf<String, String>()
                        attributeRegex.findAll(line).forEach { match ->
                            attributes[match.groupValues[1].lowercase()] = match.groupValues[2].trim()
                        }
                        val commaIndex = findDisplayNameCommaIndex(line)
                        val displayName = if (commaIndex in 0 until line.lastIndex) {
                            line.substring(commaIndex + 1).trim()
                        } else {
                            ""
                        }
                        val tvgName = attributes["tvg-name"]?.takeIf { it.isNotBlank() }
                        pendingName = displayName.ifBlank { tvgName ?: "Channel $autoNumber" }
                        pendingLogo = attributes["tvg-logo"]?.takeIf { it.isNotBlank() }
                        pendingGroup = attributes["group-title"]?.takeIf { it.isNotBlank() } ?: pendingGroup
                        pendingTvgId = attributes["tvg-id"]?.takeIf { it.isNotBlank() }
                        pendingChannelNo = (attributes["tvg-chno"] ?: attributes["channel-number"])
                            ?.toIntOrNull()
                            ?.takeIf { it > 0 }
                    }

                    line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                        val grp = line.substringAfter(":", "").trim()
                        if (grp.isNotEmpty()) pendingGroup = grp
                    }

                    line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                        val opt = line.substringAfter(":", "").trim()
                        when {
                            opt.startsWith("http-user-agent=", ignoreCase = true) -> {
                                pendingUserAgent = opt.substringAfter("=", "").trim().ifBlank { null }
                            }
                            opt.startsWith("http-referrer=", ignoreCase = true) -> {
                                pendingReferrer = opt.substringAfter("=", "").trim().ifBlank { null }
                            }
                        }
                    }

                    line.startsWith("#KODIPROP:", ignoreCase = true) -> {
                        val prop = line.substringAfter(":", "").trim()
                        when {
                            prop.startsWith("inputstream.adaptive.license_type=", ignoreCase = true) -> {
                                pendingDrmScheme = prop.substringAfter("=", "").trim().ifBlank { null }
                            }
                            prop.startsWith("inputstream.adaptive.license_key=", ignoreCase = true) -> {
                                pendingDrmLicense = prop.substringAfter("=", "").trim().ifBlank { null }
                            }
                        }
                    }

                    line.startsWith("#") -> {
                        // Ignore other directive/comment lines
                    }

                    else -> {
                        val resolvedUrl = resolveStreamUrl(line, baseUrl)
                        if (resolvedUrl != null && UrlValidator.isSafeStreamUrl(resolvedUrl)) {
                            val assignedNumber = pendingChannelNo ?: autoNumber
                            autoNumber = maxOf(autoNumber + 1, assignedNumber + 1)
                            val finalName = pendingName?.takeIf { it.isNotBlank() }
                                ?: inferChannelNameFromUrl(resolvedUrl, assignedNumber)
                            val finalGroup = pendingGroup?.takeIf { it.isNotBlank() } ?: "General"
                            val id = stableChannelId(playlistId, resolvedUrl, finalName)

                            channels.add(
                                ParsedChannelEntry(
                                    id = id,
                                    channelNumber = assignedNumber,
                                    name = finalName,
                                    streamUrl = resolvedUrl,
                                    logoUrl = pendingLogo?.let { resolveAssetUrl(it, baseUrl) },
                                    groupTitle = finalGroup,
                                    tvgId = pendingTvgId,
                                    userAgent = pendingUserAgent,
                                    referrer = pendingReferrer,
                                    drmScheme = pendingDrmScheme,
                                    drmLicenseUrl = pendingDrmLicense
                                )
                            )
                        }
                        // Reset per-entry state
                        pendingName = null
                        pendingLogo = null
                        pendingGroup = null
                        pendingTvgId = null
                        pendingChannelNo = null
                        pendingUserAgent = null
                        pendingReferrer = null
                        pendingDrmScheme = null
                        pendingDrmLicense = null
                        hasMetadata = false
                    }
                }
            }
        }
        return channels
    }

    private fun findDisplayNameCommaIndex(extInfLine: String): Int {
        var inQuotes = false
        var lastComma = -1
        for (i in extInfLine.indices) {
            when (extInfLine[i]) {
                '"' -> inQuotes = !inQuotes
                ',' -> if (!inQuotes) {
                    lastComma = i
                }
            }
        }
        return lastComma
    }

    private fun resolveStreamUrl(raw: String, baseUrl: String?): String? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.contains("://")) return trimmed
        if (baseUrl.isNullOrBlank()) return null
        return runCatching { URI(baseUrl).resolve(trimmed).toString() }.getOrNull()
    }

    private fun resolveAssetUrl(raw: String, baseUrl: String?): String? {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            return trimmed
        }
        if (baseUrl.isNullOrBlank()) return trimmed
        return runCatching { URI(baseUrl).resolve(trimmed).toString() }.getOrNull()
    }

    private fun inferChannelNameFromUrl(url: String, number: Int): String {
        val segment = runCatching {
            URI(url).path?.substringAfterLast('/')?.substringBeforeLast('.')
        }.getOrNull()
        return segment?.takeIf { it.isNotBlank() }?.replace('_', ' ')?.replace('-', ' ')
            ?: "Channel $number"
    }

    private fun stableChannelId(playlistId: String, streamUrl: String, name: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$playlistId|$streamUrl|$name".toByteArray(Charsets.UTF_8))
        return digest.take(12).joinToString("") { "%02x".format(it) }
    }
}
