package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY isBuiltIn DESC, isDefault DESC, createdAt ASC")
    fun observeAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY isBuiltIn DESC, isDefault DESC, createdAt ASC")
    suspend fun getAllPlaylistsOnce(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE isEnabled = 1 ORDER BY isBuiltIn DESC, isDefault DESC, createdAt ASC")
    suspend fun getEnabledPlaylistsOnce(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
    suspend fun getPlaylistById(id: String): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPlaylist(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET isEnabled = :enabled WHERE id = :id")
    suspend fun setPlaylistEnabled(id: String, enabled: Boolean)

    @Query("UPDATE playlists SET isDefault = CASE WHEN id = :id THEN 1 ELSE 0 END")
    suspend fun setDefaultPlaylist(id: String)

    @Query("UPDATE playlists SET name = :name, urlOrUri = :urlOrUri WHERE id = :id")
    suspend fun updatePlaylistDetails(id: String, name: String, urlOrUri: String)

    @Query("UPDATE playlists SET channelCount = :count, lastSyncedAt = :syncedAt, lastError = :error WHERE id = :id")
    suspend fun updateSyncStatus(id: String, count: Int, syncedAt: Long?, error: String?)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylistById(id: String)
}

@Dao
interface ChannelDao {
    @Query(
        """
        SELECT c.* FROM channels c
        INNER JOIN playlists p ON c.playlistId = p.id
        WHERE p.isEnabled = 1
        ORDER BY p.isDefault DESC, c.channelNumber ASC, c.name ASC
        """
    )
    fun observeEnabledChannels(): Flow<List<ChannelEntity>>

    @Query(
        """
        SELECT c.* FROM channels c
        INNER JOIN playlists p ON c.playlistId = p.id
        WHERE p.isEnabled = 1 AND c.isFavourite = 1
        ORDER BY c.channelNumber ASC, c.name ASC
        """
    )
    fun observeFavouriteChannels(): Flow<List<ChannelEntity>>

    @Query(
        """
        SELECT c.* FROM channels c
        INNER JOIN playlists p ON c.playlistId = p.id
        WHERE p.isEnabled = 1 AND c.lastWatchedAt IS NOT NULL
        ORDER BY c.lastWatchedAt DESC
        LIMIT 20
        """
    )
    fun observeRecentlyWatched(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId")
    suspend fun getChannelsByPlaylist(playlistId: String): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
    suspend fun getChannelById(id: String): ChannelEntity?

    @Query("UPDATE channels SET isFavourite = :isFavourite WHERE id = :id")
    suspend fun setFavourite(id: String, isFavourite: Boolean)

    @Query(
        """
        UPDATE channels
        SET lastWatchedAt = :watchedAt, lastPositionMs = :positionMs, durationMs = :durationMs
        WHERE id = :id
        """
    )
    suspend fun updateWatchProgress(id: String, watchedAt: Long, positionMs: Long, durationMs: Long)

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deleteChannelsForPlaylist(playlistId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<ChannelEntity>)

    @Transaction
    suspend fun replaceChannelsForPlaylist(playlistId: String, newChannels: List<ChannelEntity>) {
        deleteChannelsForPlaylist(playlistId)
        if (newChannels.isNotEmpty()) {
            insertChannels(newChannels)
        }
    }

    @Query("DELETE FROM channels")
    suspend fun clearAllChannels()
}
