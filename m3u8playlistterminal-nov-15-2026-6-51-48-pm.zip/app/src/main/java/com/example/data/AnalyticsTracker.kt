package com.example.data

import android.content.Context
import com.example.BuildConfig
import com.example.models.AnalyticsEventRequest
import com.example.models.Channel
import com.example.network.BackendApiClient
import com.example.settings.SettingsPreferences
import com.example.utils.isAndroidTvDevice
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class AnalyticsTracker(
    private val context: Context,
    private val apiClient: BackendApiClient,
    private val settingsPrefs: SettingsPreferences,
    private val scope: CoroutineScope
) {
    private val deviceType: String = if (context.isAndroidTvDevice()) "ANDROID_TV" else "MOBILE"
    private val appVersion: String = BuildConfig.VERSION_NAME

    private var activeSessionId: String? = null
    private var activeChannel: Channel? = null
    private var heartbeatJob: Job? = null

    fun recoverCrashedSessionIfAny() {
        scope.launch {
            val settings = settingsPrefs.getSettingsOnce()
            val pending = settingsPrefs.getPendingAnalyticsSession() ?: return@launch
            val (sessionId, channelId, channelName) = pending
            if (settings.backendServerUrl.isNotBlank() && settings.analyticsEnabled) {
                apiClient.sendAnalyticsEvent(
                    rawBaseUrl = settings.backendServerUrl,
                    event = AnalyticsEventRequest(
                        type = "CRASH_RECOVERY",
                        sessionId = sessionId,
                        channelId = channelId,
                        channelName = channelName,
                        deviceType = deviceType,
                        appVersion = appVersion,
                        status = "EXPIRED"
                    )
                )
            }
            settingsPrefs.setPendingAnalyticsSession(null)
        }
    }

    fun onPlaybackStarted(channel: Channel) {
        scope.launch {
            val currentSid = activeSessionId
            val currentCh = activeChannel
            if (currentSid != null && currentCh != null && currentCh.id != channel.id) {
                sendStopInternal(currentSid, currentCh)
            }

            val settings = settingsPrefs.getSettingsOnce()
            if (settings.backendServerUrl.isBlank() || !settings.analyticsEnabled) {
                activeSessionId = null
                activeChannel = channel
                heartbeatJob?.cancel()
                return@launch
            }

            val sid = if (currentCh?.id == channel.id && currentSid != null) {
                currentSid
            } else {
                UUID.randomUUID().toString()
            }
            activeSessionId = sid
            activeChannel = channel
            settingsPrefs.setPendingAnalyticsSession(sid, channel.id, channel.name)

            val res = apiClient.sendAnalyticsEvent(
                rawBaseUrl = settings.backendServerUrl,
                event = AnalyticsEventRequest(
                    type = "START",
                    sessionId = sid,
                    channelId = channel.id,
                    channelName = channel.name,
                    deviceType = deviceType,
                    appVersion = appVersion,
                    status = "PLAYING"
                )
            )
            val serverInterval = res.getOrNull()?.heartbeatIntervalSeconds
            if (serverInterval != null && serverInterval != settings.heartbeatIntervalSeconds) {
                settingsPrefs.applyRemoteConfig(
                    configVersion = settings.lastRemoteConfigVersion,
                    heartbeatIntervalSeconds = serverInterval,
                    maintenanceMessage = settings.maintenanceMessage
                )
            }

            startHeartbeatLoop(sid, channel)
        }
    }

    private fun startHeartbeatLoop(sessionId: String, channel: Channel) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                val settings = settingsPrefs.getSettingsOnce()
                val intervalMs = settings.heartbeatIntervalSeconds.coerceIn(10, 300) * 1000L
                delay(intervalMs)
                if (!isActive || activeSessionId != sessionId) break
                if (settings.backendServerUrl.isBlank() || !settings.analyticsEnabled) break

                val resp = apiClient.sendAnalyticsEvent(
                    rawBaseUrl = settings.backendServerUrl,
                    event = AnalyticsEventRequest(
                        type = "HEARTBEAT",
                        sessionId = sessionId,
                        channelId = channel.id,
                        channelName = channel.name,
                        deviceType = deviceType,
                        appVersion = appVersion,
                        status = "PLAYING"
                    )
                )
                val updatedInterval = resp.getOrNull()?.heartbeatIntervalSeconds
                if (updatedInterval != null && updatedInterval != settings.heartbeatIntervalSeconds) {
                    settingsPrefs.applyRemoteConfig(
                        configVersion = settings.lastRemoteConfigVersion,
                        heartbeatIntervalSeconds = updatedInterval,
                        maintenanceMessage = settings.maintenanceMessage
                    )
                }
            }
        }
    }

    fun onPlaybackPausedOrStopped() {
        heartbeatJob?.cancel()
        heartbeatJob = null
        val sid = activeSessionId
        val ch = activeChannel
        activeSessionId = null
        activeChannel = null
        if (sid != null && ch != null) {
            scope.launch {
                sendStopInternal(sid, ch)
            }
        }
    }

    fun onPlaybackError(channel: Channel, errorCode: String, errorMessage: String) {
        heartbeatJob?.cancel()
        scope.launch {
            val settings = settingsPrefs.getSettingsOnce()
            val sid = activeSessionId ?: UUID.randomUUID().toString()
            if (settings.backendServerUrl.isNotBlank() && settings.analyticsEnabled) {
                apiClient.sendAnalyticsEvent(
                    rawBaseUrl = settings.backendServerUrl,
                    event = AnalyticsEventRequest(
                        type = "ERROR",
                        sessionId = sid,
                        channelId = channel.id,
                        channelName = channel.name,
                        deviceType = deviceType,
                        appVersion = appVersion,
                        status = "ERROR",
                        errorCode = errorCode,
                        errorMessage = errorMessage
                    )
                )
            }
            settingsPrefs.setPendingAnalyticsSession(null)
            activeSessionId = null
        }
    }

    private suspend fun sendStopInternal(sessionId: String, channel: Channel) {
        val settings = settingsPrefs.getSettingsOnce()
        if (settings.backendServerUrl.isNotBlank() && settings.analyticsEnabled) {
            apiClient.sendAnalyticsEvent(
                rawBaseUrl = settings.backendServerUrl,
                event = AnalyticsEventRequest(
                    type = "STOP",
                    sessionId = sessionId,
                    channelId = channel.id,
                    channelName = channel.name,
                    deviceType = deviceType,
                    appVersion = appVersion,
                    status = "STOPPED"
                )
            )
        }
        settingsPrefs.setPendingAnalyticsSession(null)
    }
}
