package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.models.Channel
import com.example.models.PlaylistSource
import com.example.models.PlaylistType

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val urlOrUri: String,
    val sourceType: String,
    val isEnabled: Boolean,
    val isBuiltIn: Boolean,
    val isDefault: Boolean,
    val channelCount: Int,
    val lastSyncedAt: Long?,
    val lastError: String?,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): PlaylistSource = PlaylistSource(
        id = id,
        name = name,
        urlOrUri = urlOrUri,
        type = runCatching { PlaylistType.valueOf(sourceType) }.getOrDefault(PlaylistType.REMOTE_URL),
        isEnabled = isEnabled,
        isBuiltIn = isBuiltIn,
        isDefault = isDefault,
        channelCount = channelCount,
        lastSyncedAt = lastSyncedAt,
        lastError = lastError
    )
}

@Entity(
    tableName = "channels",
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["playlistId"]),
        Index(value = ["groupTitle"]),
        Index(value = ["isFavourite"]),
        Index(value = ["lastWatchedAt"])
    ]
)
data class ChannelEntity(
    @PrimaryKey val id: String,
    val playlistId: String,
    val playlistName: String,
    val channelNumber: Int,
    val name: String,
    val streamUrl: String,
    val logoUrl: String?,
    val groupTitle: String,
    val tvgId: String?,
    val userAgent: String?,
    val referrer: String?,
    val drmScheme: String?,
    val drmLicenseUrl: String?,
    val isFavourite: Boolean = false,
    val lastWatchedAt: Long? = null,
    val lastPositionMs: Long = 0L,
    val durationMs: Long = 0L
) {
    fun toDomain(): Channel = Channel(
        id = id,
        playlistId = playlistId,
        playlistName = playlistName,
        channelNumber = channelNumber,
        name = name,
        streamUrl = streamUrl,
        logoUrl = logoUrl,
        groupTitle = groupTitle,
        tvgId = tvgId,
        userAgent = userAgent,
        referrer = referrer,
        drmScheme = drmScheme,
        drmLicenseUrl = drmLicenseUrl,
        isFavourite = isFavourite,
        lastWatchedAt = lastWatchedAt,
        lastPositionMs = lastPositionMs,
        durationMs = durationMs
    )
}
