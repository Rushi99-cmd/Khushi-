package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.models.Channel
import com.example.models.PlaylistSource
import com.example.models.PlaylistType
import com.example.models.SyncState
import com.example.network.PlaylistFetchResult
import com.example.network.PlaylistNetworkClient
import com.example.playlist.M3uParser
import com.example.playlist.ParsedChannelEntry
import com.example.utils.AppConstants
import com.example.utils.UrlValidationResult
import com.example.utils.UrlValidator
import java.io.InputStreamReader
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class PlaylistRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    private val playlistDao = database.playlistDao()
    private val channelDao = database.channelDao()

    val playlistsFlow: Flow<List<PlaylistSource>> =
        playlistDao.observeAllPlaylists().map { list -> list.map { it.toDomain() } }

    val enabledChannelsFlow: Flow<List<Channel>> =
        channelDao.observeEnabledChannels().map { list -> list.map { it.toDomain() } }

    val favouriteChannelsFlow: Flow<List<Channel>> =
        channelDao.observeFavouriteChannels().map { list -> list.map { it.toDomain() } }

    val recentlyWatchedFlow: Flow<List<Channel>> =
        channelDao.observeRecentlyWatched().map { list -> list.map { it.toDomain() } }

    suspend fun ensureBuiltInPlaylistExists() {
        val existing = playlistDao.getPlaylistById(AppConstants.BUILT_IN_PLAYLIST_ID)
        if (existing == null) {
            val all = playlistDao.getAllPlaylistsOnce()
            val shouldBeDefault = all.none { it.isDefault }
            playlistDao.upsertPlaylist(
                PlaylistEntity(
                    id = AppConstants.BUILT_IN_PLAYLIST_ID,
                    name = AppConstants.BUILT_IN_PLAYLIST_NAME,
                    urlOrUri = AppConstants.BUILT_IN_PLAYLIST_URL,
                    sourceType = PlaylistType.BUILT_IN.name,
                    isEnabled = true,
                    isBuiltIn = true,
                    isDefault = shouldBeDefault,
                    channelCount = 0,
                    lastSyncedAt = null,
                    lastError = null
                )
            )
        }
    }

    suspend fun refreshAllEnabledPlaylists(customUserAgent: String = ""): SyncState {
        ensureBuiltInPlaylistExists()
        val enabledPlaylists = playlistDao.getEnabledPlaylistsOnce()
        if (enabledPlaylists.isEmpty()) {
            return SyncState.Error("No playlists are currently enabled. Enable or add a playlist in My Playlists.")
        }

        var syncedCount = 0
        var totalChannels = 0
        var lastFailure: String? = null

        for (playlist in enabledPlaylists) {
            when (val result = refreshPlaylistInternal(playlist, customUserAgent)) {
                is PlaylistSyncOutcome.Success -> {
                    syncedCount++
                    totalChannels += result.count
                }
                is PlaylistSyncOutcome.Failure -> {
                    lastFailure = "${playlist.name}: ${result.error}"
                    totalChannels += playlist.channelCount
                }
            }
        }

        return when {
            syncedCount == enabledPlaylists.size -> {
                SyncState.Success(
                    message = "Synced $totalChannels channels across $syncedCount playlist(s).",
                    timestamp = System.currentTimeMillis()
                )
            }
            syncedCount > 0 -> {
                SyncState.CachedFallback(
                    reason = lastFailure ?: "One or more playlists could not be reached.",
                    channelCount = totalChannels
                )
            }
            totalChannels > 0 -> {
                SyncState.CachedFallback(
                    reason = lastFailure ?: "Server unavailable.",
                    channelCount = totalChannels
                )
            }
            else -> {
                SyncState.Error(lastFailure ?: "Unable to load channels from configured playlists.")
            }
        }
    }

    suspend fun refreshSinglePlaylist(playlistId: String, customUserAgent: String = ""): SyncState {
        val playlist = playlistDao.getPlaylistById(playlistId)
            ?: return SyncState.Error("Playlist not found.")
        return when (val outcome = refreshPlaylistInternal(playlist, customUserAgent)) {
            is PlaylistSyncOutcome.Success -> {
                SyncState.Success(
                    message = "Loaded ${outcome.count} channels for ${playlist.name}.",
                    timestamp = System.currentTimeMillis()
                )
            }
            is PlaylistSyncOutcome.Failure -> {
                if (playlist.channelCount > 0) {
                    SyncState.CachedFallback(
                        reason = outcome.error,
                        channelCount = playlist.channelCount
                    )
                } else {
                    SyncState.Error(outcome.error)
                }
            }
        }
    }

    private sealed interface PlaylistSyncOutcome {
        data class Success(val count: Int) : PlaylistSyncOutcome
        data class Failure(val error: String) : PlaylistSyncOutcome
    }

    private suspend fun refreshPlaylistInternal(
        playlist: PlaylistEntity,
        customUserAgent: String
    ): PlaylistSyncOutcome {
        val type = runCatching { PlaylistType.valueOf(playlist.sourceType) }
            .getOrDefault(PlaylistType.REMOTE_URL)

        val entries: List<ParsedChannelEntry> = when (type) {
            PlaylistType.BUILT_IN, PlaylistType.REMOTE_URL -> {
                when (val fetch = PlaylistNetworkClient.fetchAndParse(playlist.urlOrUri, playlist.id, customUserAgent)) {
                    is PlaylistFetchResult.Success -> fetch.entries
                    is PlaylistFetchResult.Failure -> {
                        playlistDao.updateSyncStatus(
                            id = playlist.id,
                            count = playlist.channelCount,
                            syncedAt = playlist.lastSyncedAt,
                            error = fetch.errorMessage
                        )
                        return PlaylistSyncOutcome.Failure(fetch.errorMessage)
                    }
                }
            }
            PlaylistType.LOCAL_FILE -> {
                val localResult = readAndParseLocalUri(playlist.urlOrUri, playlist.id)
                if (localResult.isFailure) {
                    val err = localResult.exceptionOrNull()?.message
                        ?: "Unable to re-read local file. Cached channels remain available."
                    playlistDao.updateSyncStatus(
                        id = playlist.id,
                        count = playlist.channelCount,
                        syncedAt = playlist.lastSyncedAt,
                        error = err
                    )
                    return PlaylistSyncOutcome.Failure(err)
                }
                localResult.getOrThrow()
            }
        }

        val existingMap = channelDao.getChannelsByPlaylist(playlist.id).associateBy { it.id }
        val entities = entries.map { entry ->
            val previous = existingMap[entry.id]
            ChannelEntity(
                id = entry.id,
                playlistId = playlist.id,
                playlistName = playlist.name,
                channelNumber = entry.channelNumber,
                name = entry.name,
                streamUrl = entry.streamUrl,
                logoUrl = entry.logoUrl,
                groupTitle = entry.groupTitle,
                tvgId = entry.tvgId,
                userAgent = entry.userAgent,
                referrer = entry.referrer,
                drmScheme = entry.drmScheme,
                drmLicenseUrl = entry.drmLicenseUrl,
                isFavourite = previous?.isFavourite ?: false,
                lastWatchedAt = previous?.lastWatchedAt,
                lastPositionMs = previous?.lastPositionMs ?: 0L,
                durationMs = previous?.durationMs ?: 0L
            )
        }

        channelDao.replaceChannelsForPlaylist(playlist.id, entities)
        val now = System.currentTimeMillis()
        playlistDao.updateSyncStatus(
            id = playlist.id,
            count = entities.size,
            syncedAt = now,
            error = null
        )
        return PlaylistSyncOutcome.Success(entities.size)
    }

    suspend fun addRemotePlaylist(
        name: String,
        rawUrl: String,
        makeDefault: Boolean = false,
        customUserAgent: String = ""
    ): Result<PlaylistSource> {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) {
            return Result.failure(IllegalArgumentException("Please provide a custom name for this playlist."))
        }
        val validatedUrl = when (val validation = UrlValidator.validatePlaylistUrl(rawUrl)) {
            is UrlValidationResult.Valid -> validation.normalizedUrl
            is UrlValidationResult.Invalid -> {
                return Result.failure(IllegalArgumentException(validation.error))
            }
        }

        val newId = "pl_${UUID.randomUUID().toString().take(8)}"
        val entity = PlaylistEntity(
            id = newId,
            name = cleanName,
            urlOrUri = validatedUrl,
            sourceType = PlaylistType.REMOTE_URL.name,
            isEnabled = true,
            isBuiltIn = false,
            isDefault = false,
            channelCount = 0,
            lastSyncedAt = null,
            lastError = null
        )

        val fetchResult = PlaylistNetworkClient.fetchAndParse(validatedUrl, newId, customUserAgent)
        return when (fetchResult) {
            is PlaylistFetchResult.Failure -> {
                Result.failure(IllegalStateException(fetchResult.errorMessage))
            }
            is PlaylistFetchResult.Success -> {
                playlistDao.upsertPlaylist(entity)
                if (makeDefault) {
                    playlistDao.setDefaultPlaylist(newId)
                }
                val channelEntities = fetchResult.entries.map { entry ->
                    ChannelEntity(
                        id = entry.id,
                        playlistId = newId,
                        playlistName = cleanName,
                        channelNumber = entry.channelNumber,
                        name = entry.name,
                        streamUrl = entry.streamUrl,
                        logoUrl = entry.logoUrl,
                        groupTitle = entry.groupTitle,
                        tvgId = entry.tvgId,
                        userAgent = entry.userAgent,
                        referrer = entry.referrer,
                        drmScheme = entry.drmScheme,
                        drmLicenseUrl = entry.drmLicenseUrl
                    )
                }
                channelDao.replaceChannelsForPlaylist(newId, channelEntities)
                val now = System.currentTimeMillis()
                playlistDao.updateSyncStatus(newId, channelEntities.size, now, null)
                val saved = playlistDao.getPlaylistById(newId)?.toDomain() ?: entity.toDomain()
                Result.success(saved)
            }
        }
    }

    suspend fun importLocalPlaylist(
        name: String,
        uri: Uri,
        makeDefault: Boolean = false
    ): Result<PlaylistSource> {
        val cleanName = name.trim().ifEmpty { "Local M3U Playlist" }
        // Try persisting read permission via SAF if supported by the document provider
        runCatching {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }

        val newId = "local_${UUID.randomUUID().toString().take(8)}"
        val parsed = readAndParseLocalUri(uri.toString(), newId)
        if (parsed.isFailure) {
            return Result.failure(
                parsed.exceptionOrNull() ?: IllegalStateException("Unable to read selected file.")
            )
        }

        val entries = parsed.getOrThrow()
        val entity = PlaylistEntity(
            id = newId,
            name = cleanName,
            urlOrUri = uri.toString(),
            sourceType = PlaylistType.LOCAL_FILE.name,
            isEnabled = true,
            isBuiltIn = false,
            isDefault = false,
            channelCount = entries.size,
            lastSyncedAt = System.currentTimeMillis(),
            lastError = null
        )
        playlistDao.upsertPlaylist(entity)
        if (makeDefault) {
            playlistDao.setDefaultPlaylist(newId)
        }

        val channelEntities = entries.map { entry ->
            ChannelEntity(
                id = entry.id,
                playlistId = newId,
                playlistName = cleanName,
                channelNumber = entry.channelNumber,
                name = entry.name,
                streamUrl = entry.streamUrl,
                logoUrl = entry.logoUrl,
                groupTitle = entry.groupTitle,
                tvgId = entry.tvgId,
                userAgent = entry.userAgent,
                referrer = entry.referrer,
                drmScheme = entry.drmScheme,
                drmLicenseUrl = entry.drmLicenseUrl
            )
        }
        channelDao.replaceChannelsForPlaylist(newId, channelEntities)
        return Result.success(playlistDao.getPlaylistById(newId)?.toDomain() ?: entity.toDomain())
    }

    private suspend fun readAndParseLocalUri(
        uriString: String,
        playlistId: String
    ): Result<List<ParsedChannelEntry>> = withContext(Dispatchers.IO) {
        try {
            val uri = Uri.parse(uriString)
            val stream = context.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("Cannot open selected playlist file."))
            val entries = stream.use { input ->
                InputStreamReader(input, Charsets.UTF_8).use { reader ->
                    M3uParser.parse(reader, playlistId)
                }
            }
            if (entries.isEmpty()) {
                return@withContext Result.failure(
                    IllegalStateException("Selected file does not contain any valid M3U/M3U8 stream URLs.")
                )
            }
            Result.success(entries)
        } catch (e: SecurityException) {
            Result.failure(IllegalStateException("File permission expired. Please re-import the playlist file."))
        } catch (e: Exception) {
            Result.failure(IllegalStateException("Error reading local playlist: ${e.localizedMessage ?: "Unknown error"}"))
        }
    }

    suspend fun updatePlaylistDetails(
        playlistId: String,
        newName: String,
        newUrl: String,
        customUserAgent: String = ""
    ): Result<Unit> {
        val existing = playlistDao.getPlaylistById(playlistId)
            ?: return Result.failure(IllegalArgumentException("Playlist not found."))
        val cleanName = newName.trim()
        if (cleanName.isEmpty()) {
            return Result.failure(IllegalArgumentException("Playlist name cannot be empty."))
        }
        val type = runCatching { PlaylistType.valueOf(existing.sourceType) }
            .getOrDefault(PlaylistType.REMOTE_URL)

        val finalUrl = if (type == PlaylistType.REMOTE_URL) {
            when (val v = UrlValidator.validatePlaylistUrl(newUrl)) {
                is UrlValidationResult.Valid -> v.normalizedUrl
                is UrlValidationResult.Invalid -> return Result.failure(IllegalArgumentException(v.error))
            }
        } else {
            existing.urlOrUri
        }

        playlistDao.updatePlaylistDetails(playlistId, cleanName, finalUrl)
        // Update cached channel playlistName references
        val cached = channelDao.getChannelsByPlaylist(playlistId)
        if (cached.isNotEmpty()) {
            channelDao.insertChannels(cached.map { it.copy(playlistName = cleanName) })
        }

        if (type == PlaylistType.REMOTE_URL && finalUrl != existing.urlOrUri) {
            val updatedEntity = playlistDao.getPlaylistById(playlistId)
            if (updatedEntity != null) {
                refreshPlaylistInternal(updatedEntity, customUserAgent)
            }
        }
        return Result.success(Unit)
    }

    suspend fun setPlaylistEnabled(playlistId: String, enabled: Boolean) {
        playlistDao.setPlaylistEnabled(playlistId, enabled)
    }

    suspend fun setDefaultPlaylist(playlistId: String) {
        playlistDao.setDefaultPlaylist(playlistId)
        playlistDao.setPlaylistEnabled(playlistId, true)
    }

    suspend fun deletePlaylist(playlistId: String) {
        val target = playlistDao.getPlaylistById(playlistId) ?: return
        if (target.isBuiltIn) return
        playlistDao.deletePlaylistById(playlistId)
        if (target.isDefault) {
            playlistDao.setDefaultPlaylist(AppConstants.BUILT_IN_PLAYLIST_ID)
        }
    }

    suspend fun toggleFavourite(channelId: String) {
        val channel = channelDao.getChannelById(channelId) ?: return
        channelDao.setFavourite(channelId, !channel.isFavourite)
    }

    suspend fun recordWatchProgress(channelId: String, positionMs: Long, durationMs: Long) {
        channelDao.updateWatchProgress(
            id = channelId,
            watchedAt = System.currentTimeMillis(),
            positionMs = positionMs.coerceAtLeast(0L),
            durationMs = durationMs.coerceAtLeast(0L)
        )
    }

    suspend fun clearCachedPlaylistData() {
        channelDao.clearAllChannels()
        val all = playlistDao.getAllPlaylistsOnce()
        all.forEach { playlist ->
            playlistDao.updateSyncStatus(playlist.id, 0, null, null)
        }
    }

    suspend fun applyRemoteBootstrap(bootstrap: com.example.models.RemoteBootstrapResponse) {
        val remotePlaylistId = "remote_managed_control_plane"
        val primarySourceName = bootstrap.sources.firstOrNull { it.isPrimary }?.name
            ?: bootstrap.sources.firstOrNull()?.name
            ?: "Remote Managed Catalog"

        if (bootstrap.channels.isNotEmpty()) {
            val sourceNames = bootstrap.sources.associate { it.id to it.name }
            val existingMap = channelDao.getChannelsByPlaylist(remotePlaylistId).associateBy { it.id }

            playlistDao.upsertPlaylist(
                PlaylistEntity(
                    id = remotePlaylistId,
                    name = "$primarySourceName (Managed)",
                    urlOrUri = "backend://managed-proxy",
                    sourceType = PlaylistType.REMOTE_URL.name,
                    isEnabled = true,
                    isBuiltIn = false,
                    isDefault = true,
                    channelCount = bootstrap.channels.size,
                    lastSyncedAt = System.currentTimeMillis(),
                    lastError = null
                )
            )
            playlistDao.setDefaultPlaylist(remotePlaylistId)

            val entities = bootstrap.channels.map { remoteCh ->
                val prev = existingMap[remoteCh.id]
                ChannelEntity(
                    id = remoteCh.id,
                    playlistId = remotePlaylistId,
                    playlistName = sourceNames[remoteCh.sourceId] ?: primarySourceName,
                    channelNumber = remoteCh.channelNumber,
                    name = remoteCh.name,
                    streamUrl = remoteCh.streamUrl,
                    logoUrl = remoteCh.logoUrl,
                    groupTitle = remoteCh.groupTitle,
                    tvgId = remoteCh.tvgId,
                    userAgent = remoteCh.userAgent,
                    referrer = null,
                    drmScheme = null,
                    drmLicenseUrl = null,
                    isFavourite = prev?.isFavourite ?: false,
                    lastWatchedAt = prev?.lastWatchedAt,
                    lastPositionMs = prev?.lastPositionMs ?: 0L,
                    durationMs = prev?.durationMs ?: 0L
                )
            }
            channelDao.replaceChannelsForPlaylist(remotePlaylistId, entities)
        }
    }
}
