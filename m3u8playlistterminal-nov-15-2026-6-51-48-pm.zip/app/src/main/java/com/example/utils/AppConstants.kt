package com.example.utils

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object AppConstants {
    const val APP_NAME = "M3U8PLAYLISTTERMINAL"
    const val BUILT_IN_PLAYLIST_ID = "built_in_terminal"
    const val BUILT_IN_PLAYLIST_NAME = "Terminal Live Network"
    const val BUILT_IN_PLAYLIST_URL = "https://m3u8playlistterminal-free.lovable.app/api/playlist"
    const val TELEGRAM_INVITE_URL = "https://t.me/+SIFUyQU4p3IwZjhl"
    const val DEFAULT_USER_AGENT = "M3U8PLAYLISTTERMINAL/1.0 (Android; ExoPlayer)"
    const val PRIVACY_SUMMARY =
        "M3U8PLAYLISTTERMINAL stores playlists, favourites, watch history, and preferences locally on your device. Imported local playlists are never uploaded. When connected to a backend control plane with analytics enabled, the app sends only anonymous session UUIDs, active channel ID, device form factor (Android TV or Mobile), app version, and playback errors with configurable retention—never personal identity or contact details. You can disable viewing analytics at any time in Settings."
}

sealed interface UrlValidationResult {
    data class Valid(val normalizedUrl: String) : UrlValidationResult
    data class Invalid(val error: String) : UrlValidationResult
}

object UrlValidator {
    fun validatePlaylistUrl(rawUrl: String): UrlValidationResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isEmpty()) {
            return UrlValidationResult.Invalid("Please enter a playlist URL.")
        }
        if (trimmed.contains(" ")) {
            return UrlValidationResult.Invalid("URL cannot contain spaces.")
        }
        val parsed = runCatching { URI(trimmed) }.getOrNull()
            ?: return UrlValidationResult.Invalid("Malformed URL format.")
        val scheme = parsed.scheme?.lowercase(Locale.ROOT)
        if (scheme != "http" && scheme != "https") {
            return UrlValidationResult.Invalid("URL must begin with http:// or https://.")
        }
        val host = parsed.host
        if (host.isNullOrBlank()) {
            return UrlValidationResult.Invalid("URL is missing a valid domain or IP address.")
        }
        return UrlValidationResult.Valid(trimmed)
    }

    fun isSafeStreamUrl(url: String): Boolean {
        val scheme = runCatching { URI(url.trim()).scheme?.lowercase(Locale.ROOT) }.getOrNull()
        return scheme == "http" || scheme == "https" || scheme == "rtsp" || scheme == "rtmp"
    }
}

object Formatters {
    fun formatTimestamp(millis: Long?): String {
        if (millis == null || millis <= 0L) return "Never synced"
        val formatter = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        return formatter.format(Date(millis))
    }

    fun formatDuration(ms: Long): String {
        if (ms <= 0L) return "00:00"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatChannelNumber(number: Int): String = String.format(Locale.US, "%03d", number)
}

fun Context.isAndroidTvDevice(): Boolean {
    val uiModeManager = getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    val isTvMode = uiModeManager?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    val hasLeanback = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    return isTvMode || hasLeanback
}
