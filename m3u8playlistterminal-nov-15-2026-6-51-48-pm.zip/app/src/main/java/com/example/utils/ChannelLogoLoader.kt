package com.example.utils

import android.content.Context
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.network.PlaylistNetworkClient

object ChannelLogoLoader {
    @Volatile
    private var instance: ImageLoader? = null

    fun get(context: Context): ImageLoader {
        return instance ?: synchronized(this) {
            instance ?: buildImageLoader(context.applicationContext).also { instance = it }
        }
    }

    private fun buildImageLoader(appContext: Context): ImageLoader {
        return ImageLoader.Builder(appContext)
            .okHttpClient(PlaylistNetworkClient.okHttpClient)
            .memoryCache {
                MemoryCache.Builder(appContext)
                    .maxSizePercent(0.18) // Safe on low-memory Android TV boxes
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(appContext.cacheDir.resolve("channel_logos"))
                    .maxSizeBytes(32L * 1024L * 1024L) // 32 MB cap
                    .build()
            }
            .respectCacheHeaders(false)
            .crossfade(180)
            .build()
    }
}
