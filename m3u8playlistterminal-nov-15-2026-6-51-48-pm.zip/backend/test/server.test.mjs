import { test, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { hashPassword } from '../create-admin.mjs';
import { createTerminalServer } from '../server.mjs';

let instance;
let baseUrl;
let mockTime = 1_700_000_000_000;

const sampleM3u = `#EXTM3U
#EXTINF:-1 tvg-id="news.1" tvg-logo="https://cdn.test/news.png" group-title="News" tvg-chno="1",Global News HD
https://streams.test/live/news.m3u8
#EXTINF:-1 group-title="Sports" tvg-chno="2",Arena Sports
https://streams.test/live/sports.m3u8
`;

beforeEach(async () => {
  mockTime = 1_700_000_000_000;
  const passwordHash = hashPassword('OwnerSecretPass#2026');
  instance = createTerminalServer({
    inMemoryOnly: true,
    signingSecret: 'test-signing-secret-32-bytes-minimum-key',
    adminUsername: 'owner@m3u8terminal.local',
    adminPasswordHash: passwordHash,
    adminTokenTtlSeconds: 300,
    clientTokenTtlSeconds: 300,
    nowFn: () => mockTime,
    fetchImpl: async () => new Response(sampleM3u, { status: 200 })
  });
  await new Promise((resolve) => instance.server.listen(0, '127.0.0.1', resolve));
  const addr = instance.server.address();
  baseUrl = `http://127.0.0.1:${addr.port}`;
});

afterEach(async () => {
  await new Promise((resolve) => instance.server.close(resolve));
});

test('owner authentication enforces password hash, rate limit, token expiration, and rejects public registration', async () => {
  const regRes = await fetch(`${baseUrl}/api/admin/register`, { method: 'POST' });
  assert.equal(regRes.status, 404);

  const badLogin = await fetch(`${baseUrl}/api/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'owner@m3u8terminal.local', password: 'wrong-password' })
  });
  assert.equal(badLogin.status, 401);

  const goodLogin = await fetch(`${baseUrl}/api/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'owner@m3u8terminal.local', password: 'OwnerSecretPass#2026' })
  });
  assert.equal(goodLogin.status, 200);
  const loginData = await goodLogin.json();
  assert.ok(loginData.token);

  // Verify token expires cleanly after TTL
  mockTime += 301_000;
  const expiredRes = await fetch(`${baseUrl}/api/admin/analytics/live`, {
    headers: { Authorization: `Bearer ${loginData.token}` }
  });
  assert.equal(expiredRes.status, 401);
  mockTime -= 301_000;

  // Rate limit triggers after 5 attempts in window
  for (let i = 0; i < 3; i++) {
    await fetch(`${baseUrl}/api/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'owner@m3u8terminal.local', password: 'wrong' })
    });
  }
  const limited = await fetch(`${baseUrl}/api/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'owner@m3u8terminal.local', password: 'wrong' })
  });
  assert.equal(limited.status, 429);
});

test('live analytics tracks real sessions, heartbeats, peak concurrency, and expires stale sessions', async () => {
  const adminRes = await fetch(`${baseUrl}/api/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'owner@m3u8terminal.local', password: 'OwnerSecretPass#2026' })
  });
  const { token: adminToken } = await adminRes.json();

  const clientRes = await fetch(`${baseUrl}/api/client/token`, { method: 'POST' });
  const { token: clientToken } = await clientRes.json();

  // Start two real sessions (TV + Mobile)
  for (const [sid, device] of [['sess-tv-1', 'ANDROID_TV'], ['sess-mob-1', 'MOBILE']]) {
    const ev = await fetch(`${baseUrl}/api/analytics/event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
      body: JSON.stringify({
        type: 'START',
        sessionId: sid,
        channelId: 'ch_1',
        channelName: 'Global News HD',
        deviceType: device,
        appVersion: '1.0'
      })
    });
    assert.equal(ev.status, 200);
  }

  let live = await (await fetch(`${baseUrl}/api/admin/analytics/live`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  })).json();

  assert.equal(live.totalConcurrentViewers, 2);
  assert.equal(live.peakConcurrentViewers, 2);
  assert.equal(live.tvViewers, 1);
  assert.equal(live.mobileViewers, 1);

  // Advance clock by 80s (beyond 75s timeout) after heartbeating only sess-tv-1 at +40s
  mockTime += 40_000;
  await fetch(`${baseUrl}/api/analytics/event`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${clientToken}` },
    body: JSON.stringify({
      type: 'HEARTBEAT',
      sessionId: 'sess-tv-1',
      channelId: 'ch_1',
      channelName: 'Global News HD',
      deviceType: 'ANDROID_TV',
      appVersion: '1.0'
    })
  });

  mockTime += 40_000; // sess-mob-1 is now 80s stale -> expired; sess-tv-1 is 40s fresh -> active
  live = await (await fetch(`${baseUrl}/api/admin/analytics/live`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  })).json();

  assert.equal(live.totalConcurrentViewers, 1);
  assert.equal(live.peakConcurrentViewers, 2);
  assert.equal(live.tvViewers, 1);
  assert.equal(live.mobileViewers, 0);
});

test('source proxy hides upstream URLs, supports channel disable/metadata update, and records audit logs', async () => {
  const adminRes = await fetch(`${baseUrl}/api/admin/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'owner@m3u8terminal.local', password: 'OwnerSecretPass#2026' })
  });
  const { token: adminToken } = await adminRes.json();

  const refreshRes = await fetch(`${baseUrl}/api/admin/sources/primary_terminal/refresh`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  assert.equal(refreshRes.status, 200);

  const channelsRes = await fetch(`${baseUrl}/api/admin/channels`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  const { channels } = await channelsRes.json();
  assert.equal(channels.length, 2);

  // Disable channel 2
  const patchRes = await fetch(`${baseUrl}/api/admin/channels/${channels[1].id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${adminToken}` },
    body: JSON.stringify({ enabled: false })
  });
  assert.equal(patchRes.status, 200);

  // Client bootstrap never exposes upstreamUrl when useProxy is true and hides disabled channels
  const clientRes = await fetch(`${baseUrl}/api/client/token`, { method: 'POST' });
  const { token: clientToken } = await clientRes.json();
  const bootRes = await fetch(`${baseUrl}/api/client/bootstrap`, {
    headers: { Authorization: `Bearer ${clientToken}` }
  });
  const boot = await bootRes.json();
  assert.equal(boot.sources[0].publicUrl, null);
  assert.equal(boot.channels.length, 1);

  const auditRes = await fetch(`${baseUrl}/api/admin/audit-logs`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  const { logs } = await auditRes.json();
  assert.ok(logs.some((l) => l.action === 'CHANNEL_UPDATED'));
});
