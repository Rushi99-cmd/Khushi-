import crypto from 'node:crypto';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { verifyPassword } from './create-admin.mjs';

const BUILT_IN_DEFAULT_URL = 'https://m3u8playlistterminal-free.lovable.app/api/playlist';

export function parseM3uText(content, sourceId) {
  const lines = content.split(/\r?\n/);
  const channels = [];
  const attrRegex = /([a-zA-Z0-9_-]+)\s*=\s*"([^"]*)"/g;

  let pending = null;
  let autoNum = 1;

  for (const raw of lines) {
    const line = raw.trim().replace(/^\uFEFF/, '');
    if (!line) continue;
    if (line.startsWith('#EXTM3U')) continue;

    if (line.startsWith('#EXTINF:')) {
      const attrs = {};
      let m;
      while ((m = attrRegex.exec(line)) !== null) {
        attrs[m[1].toLowerCase()] = m[2].trim();
      }
      attrRegex.lastIndex = 0;

      let inQuotes = false;
      let commaIdx = -1;
      for (let i = 0; i < line.length; i++) {
        if (line[i] === '"') inQuotes = !inQuotes;
        else if (line[i] === ',' && !inQuotes) commaIdx = i;
      }
      const displayName = commaIdx >= 0 ? line.slice(commaIdx + 1).trim() : '';
      const chNo = Number(attrs['tvg-chno'] || attrs['channel-number']);
      pending = {
        name: displayName || attrs['tvg-name'] || `Channel ${autoNum}`,
        logoUrl: attrs['tvg-logo'] || null,
        groupTitle: attrs['group-title'] || 'General',
        tvgId: attrs['tvg-id'] || null,
        channelNumber: Number.isInteger(chNo) && chNo > 0 ? chNo : null,
        userAgent: null
      };
    } else if (line.startsWith('#EXTGRP:')) {
      const grp = line.slice(8).trim();
      if (grp) {
        pending = pending || { name: '', logoUrl: null, groupTitle: grp, tvgId: null, channelNumber: null, userAgent: null };
        pending.groupTitle = grp;
      }
    } else if (line.startsWith('#EXTVLCOPT:')) {
      const opt = line.slice(11).trim();
      if (opt.toLowerCase().startsWith('http-user-agent=')) {
        pending = pending || { name: '', logoUrl: null, groupTitle: 'General', tvgId: null, channelNumber: null, userAgent: null };
        pending.userAgent = opt.slice(16).trim() || null;
      }
    } else if (!line.startsWith('#')) {
      if (/^(https?|rtsp|rtmp):\/\//i.test(line)) {
        const number = pending?.channelNumber || autoNum;
        autoNum = Math.max(autoNum + 1, number + 1);
        const name = pending?.name || `Channel ${number}`;
        const id = crypto
          .createHash('sha256')
          .update(`${sourceId}|${line}|${name}`)
          .digest('hex')
          .slice(0, 20);

        channels.push({
          id,
          sourceId,
          channelNumber: number,
          name,
          streamUrl: line,
          logoUrl: pending?.logoUrl || null,
          groupTitle: pending?.groupTitle || 'General',
          tvgId: pending?.tvgId || null,
          userAgent: pending?.userAgent || null,
          enabled: true
        });
      }
      pending = null;
    }
  }
  return channels;
}

class SlidingWindowRateLimiter {
  constructor() {
    this.buckets = new Map();
  }

  check(key, maxRequests, windowMs, now = Date.now()) {
    const cutoff = now - windowMs;
    const timestamps = (this.buckets.get(key) || []).filter((t) => t > cutoff);
    if (timestamps.length >= maxRequests) {
      const retryAfterSec = Math.max(1, Math.ceil((timestamps[0] + windowMs - now) / 1000));
      this.buckets.set(key, timestamps);
      return { allowed: false, retryAfterSec };
    }
    timestamps.push(now);
    this.buckets.set(key, timestamps);
    return { allowed: true, retryAfterSec: 0 };
  }
}

function signToken(payload, secret) {
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token, secret, now = Date.now()) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, providedSig] = parts;
  const expectedSig = crypto.createHmac('sha256', secret).update(encoded).digest('base64url');
  const a = Buffer.from(providedSig);
  const b = Buffer.from(expectedSig);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp <= now) return null;
    return payload;
  } catch {
    return null;
  }
}

export function createTerminalServer(options = {}) {
  const dataDir = options.dataDir || process.env.DATA_DIR || path.join(process.cwd(), 'data');
  const storePath = path.join(dataDir, 'terminal-store.json');
  const signingSecret =
    options.signingSecret ||
    process.env.TOKEN_SIGNING_SECRET ||
    crypto.randomBytes(32).toString('hex');
  const adminUsername = (options.adminUsername || process.env.ADMIN_USERNAME || '').trim().toLowerCase();
  const adminPasswordHash = options.adminPasswordHash || process.env.ADMIN_PASSWORD_HASH || '';
  const adminTokenTtlSec = Number(options.adminTokenTtlSeconds || process.env.ADMIN_TOKEN_TTL_SECONDS || 900);
  const clientTokenTtlSec = Number(options.clientTokenTtlSeconds || process.env.CLIENT_TOKEN_TTL_SECONDS || 600);
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  const nowFn = options.nowFn || (() => Date.now());

  fs.mkdirSync(dataDir, { recursive: true });

  const defaultStore = () => ({
    config: {
      configVersion: 1,
      heartbeatIntervalSeconds: Number(process.env.DEFAULT_HEARTBEAT_INTERVAL_SECONDS || 30),
      sessionTimeoutSeconds: Number(process.env.DEFAULT_SESSION_TIMEOUT_SECONDS || 75),
      retentionDays: Number(process.env.DEFAULT_RETENTION_DAYS || 7),
      analyticsEnabled: true,
      maintenanceMessage: ''
    },
    sources: [
      {
        id: 'primary_terminal',
        name: 'Terminal Live Network',
        upstreamUrl: BUILT_IN_DEFAULT_URL,
        isPrimary: true,
        isBackup: false,
        isEnabled: true,
        useProxy: true,
        lastRefreshedAt: null,
        lastError: null,
        channelCount: 0
      }
    ],
    channels: [],
    sessions: {},
    peakConcurrentViewers: 0,
    peakConcurrentAt: null,
    recentErrors: [],
    auditLogs: [],
    revokedAdminJtis: {}
  });

  let store = defaultStore();
  if (fs.existsSync(storePath) && !options.inMemoryOnly) {
    try {
      const loaded = JSON.parse(fs.readFileSync(storePath, 'utf8'));
      store = { ...defaultStore(), ...loaded };
    } catch {
      store = defaultStore();
    }
  }

  function persist() {
    if (options.inMemoryOnly) return;
    const tmp = `${storePath}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(store, null, 2), 'utf8');
    fs.renameSync(tmp, storePath);
  }

  function appendAudit(actor, action, details) {
    store.auditLogs.unshift({
      id: crypto.randomUUID(),
      timestamp: nowFn(),
      actor,
      action,
      details
    });
    if (store.auditLogs.length > 500) {
      store.auditLogs.length = 500;
    }
  }

  function expireInactiveSessions() {
    const now = nowFn();
    const timeoutMs = Math.max(15, store.config.sessionTimeoutSeconds) * 1000;
    const retentionMs = Math.max(1, store.config.retentionDays) * 86_400_000;
    let changed = false;

    for (const [sid, session] of Object.entries(store.sessions)) {
      if (session.status === 'PLAYING' || session.status === 'BUFFERING') {
        if (now - session.lastHeartbeatAt > timeoutMs) {
          session.status = 'EXPIRED';
          session.stoppedAt = session.lastHeartbeatAt + timeoutMs;
          changed = true;
        }
      }
      if (session.stoppedAt && now - session.stoppedAt > retentionMs) {
        delete store.sessions[sid];
        changed = true;
      }
    }

    // Prune expired revoked JTIs and old errors beyond retention
    for (const [jti, exp] of Object.entries(store.revokedAdminJtis)) {
      if (exp <= now) {
        delete store.revokedAdminJtis[jti];
      }
    }
    store.recentErrors = store.recentErrors.filter((e) => now - e.timestamp <= retentionMs);
    if (store.recentErrors.length > 200) {
      store.recentErrors.length = 200;
    }

    const activeCount = Object.values(store.sessions).filter(
      (s) => s.status === 'PLAYING' || s.status === 'BUFFERING'
    ).length;

    if (activeCount > store.peakConcurrentViewers) {
      store.peakConcurrentViewers = activeCount;
      store.peakConcurrentAt = now;
      changed = true;
    }
    if (changed) persist();
  }

  function computeLiveAnalytics() {
    expireInactiveSessions();
    const activeSessions = Object.values(store.sessions)
      .filter((s) => s.status === 'PLAYING' || s.status === 'BUFFERING')
      .sort((a, b) => b.lastHeartbeatAt - a.lastHeartbeatAt);

    const channelMap = new Map();
    let tvCount = 0;
    let mobileCount = 0;
    const versionCounts = {};

    for (const s of activeSessions) {
      if (s.deviceType === 'ANDROID_TV') tvCount++;
      else mobileCount++;
      versionCounts[s.appVersion] = (versionCounts[s.appVersion] || 0) + 1;

      const key = s.channelId || s.channelName;
      const prev = channelMap.get(key) || {
        channelId: s.channelId,
        channelName: s.channelName,
        viewers: 0
      };
      prev.viewers += 1;
      channelMap.set(key, prev);
    }

    const channelViewerCounts = Array.from(channelMap.values()).sort((a, b) => b.viewers - a.viewers);

    return {
      generatedAt: nowFn(),
      totalConcurrentViewers: activeSessions.length,
      peakConcurrentViewers: store.peakConcurrentViewers,
      peakConcurrentAt: store.peakConcurrentAt,
      tvViewers: tvCount,
      mobileViewers: mobileCount,
      appVersionCounts: versionCounts,
      channelViewerCounts,
      activeSessions: activeSessions.slice(0, 100),
      recentErrors: store.recentErrors.slice(0, 50),
      config: store.config
    };
  }

  async function refreshSourceFromUpstream(source) {
    try {
      const response = await fetchImpl(source.upstreamUrl, {
        redirect: 'follow',
        headers: { 'User-Agent': 'M3U8PLAYLISTTERMINAL-ServerProxy/1.0' }
      });
      if (!response.ok) {
        throw new Error(`Upstream returned HTTP ${response.status}`);
      }
      const text = await response.text();
      const parsed = parseM3uText(text, source.id);
      if (parsed.length === 0) {
        throw new Error('No valid stream entries returned by upstream playlist.');
      }

      // Preserve existing admin channel overrides (custom name, logo, group, number, enabled)
      const existingById = new Map(store.channels.filter((c) => c.sourceId === source.id).map((c) => [c.id, c]));
      const merged = parsed.map((ch) => {
        const prev = existingById.get(ch.id);
        return prev
          ? {
              ...ch,
              name: prev.customName || ch.name,
              customName: prev.customName || null,
              logoUrl: prev.customLogoUrl || ch.logoUrl,
              customLogoUrl: prev.customLogoUrl || null,
              groupTitle: prev.customGroupTitle || ch.groupTitle,
              customGroupTitle: prev.customGroupTitle || null,
              channelNumber: prev.customChannelNumber || ch.channelNumber,
              customChannelNumber: prev.customChannelNumber || null,
              enabled: prev.enabled !== false
            }
          : ch;
      });

      store.channels = [...store.channels.filter((c) => c.sourceId !== source.id), ...merged];
      source.lastRefreshedAt = nowFn();
      source.lastError = null;
      source.channelCount = merged.length;
      store.config.configVersion += 1;
      persist();
      return { ok: true, count: merged.length };
    } catch (err) {
      source.lastError = err.message || 'Upstream refresh failed';
      persist();
      return { ok: false, error: source.lastError };
    }
  }

  const rateLimiter = new SlidingWindowRateLimiter();

  function readJsonBody(req) {
    return new Promise((resolve, reject) => {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk;
        if (body.length > 1024 * 1024) {
          reject(new Error('Payload too large'));
          req.destroy();
        }
      });
      req.on('end', () => {
        if (!body.trim()) return resolve({});
        try {
          resolve(JSON.parse(body));
        } catch {
          reject(new Error('Invalid JSON payload'));
        }
      });
      req.on('error', reject);
    });
  }

  function sendJson(res, status, data, extraHeaders = {}) {
    const body = JSON.stringify(data);
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      ...extraHeaders
    });
    res.end(body);
  }

  function authenticateBearer(req, expectedScope) {
    const authHeader = req.headers['authorization'] || '';
    if (!authHeader.startsWith('Bearer ')) return null;
    const token = authHeader.slice(7).trim();
    const payload = verifyToken(token, signingSecret, nowFn());
    if (!payload || payload.scope !== expectedScope) return null;
    if (expectedScope === 'admin' && store.revokedAdminJtis[payload.jti]) return null;
    return payload;
  }

  function getClientIp(req) {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string' && forwarded.trim()) {
      return forwarded.split(',')[0].trim();
    }
    return req.socket?.remoteAddress || 'unknown';
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;
    const method = req.method || 'GET';
    const ip = getClientIp(req);

    try {
      if (method === 'GET' && pathname === '/health') {
        return sendJson(res, 200, { ok: true, time: nowFn() });
      }

      // Issue short-lived anonymous client token (rate limited)
      if (method === 'POST' && pathname === '/api/client/token') {
        const limit = rateLimiter.check(`client_token:${ip}`, 30, 60_000, nowFn());
        if (!limit.allowed) {
          return sendJson(res, 429, { error: 'Rate limit exceeded' }, { 'Retry-After': String(limit.retryAfterSec) });
        }
        const now = nowFn();
        const exp = now + clientTokenTtlSec * 1000;
        const token = signToken({ scope: 'client', jti: crypto.randomUUID(), iat: now, exp }, signingSecret);
        return sendJson(res, 200, { token, expiresAt: exp });
      }

      // Client remote configuration bootstrap (NEVER returns upstreamUrl)
      if (method === 'GET' && pathname === '/api/client/bootstrap') {
        const limit = rateLimiter.check(`client_boot:${ip}`, 120, 60_000, nowFn());
        if (!limit.allowed) {
          return sendJson(res, 429, { error: 'Rate limit exceeded' }, { 'Retry-After': String(limit.retryAfterSec) });
        }
        const clientAuth = authenticateBearer(req, 'client');
        if (!clientAuth) {
          return sendJson(res, 401, { error: 'Valid client session token required.' });
        }

        const activeSources = store.sources
          .filter((s) => s.isEnabled)
          .map((s) => ({
            id: s.id,
            name: s.name,
            isPrimary: s.isPrimary,
            isBackup: s.isBackup,
            useProxy: s.useProxy,
            channelCount: s.channelCount,
            lastRefreshedAt: s.lastRefreshedAt,
            // Only expose URL when admin explicitly disables proxy for a public source
            publicUrl: s.useProxy ? null : s.upstreamUrl
          }));

        const enabledChannels = store.channels
          .filter((c) => {
            const src = store.sources.find((s) => s.id === c.sourceId);
            return c.enabled !== false && src && src.isEnabled;
          })
          .map((c) => ({
            id: c.id,
            sourceId: c.sourceId,
            channelNumber: c.channelNumber,
            name: c.name,
            streamUrl: c.streamUrl,
            logoUrl: c.logoUrl,
            groupTitle: c.groupTitle,
            tvgId: c.tvgId,
            userAgent: c.userAgent
          }));

        return sendJson(res, 200, {
          configVersion: store.config.configVersion,
          heartbeatIntervalSeconds: store.config.heartbeatIntervalSeconds,
          sessionTimeoutSeconds: store.config.sessionTimeoutSeconds,
          analyticsEnabled: store.config.analyticsEnabled,
          maintenanceMessage: store.config.maintenanceMessage,
          sources: activeSources,
          channels: enabledChannels
        });
      }

      // Backend playlist proxy (hides upstream playlist URLs & credentials)
      if (method === 'GET' && pathname === '/api/client/playlist') {
        const limit = rateLimiter.check(`client_proxy:${ip}`, 60, 60_000, nowFn());
        if (!limit.allowed) {
          return sendJson(res, 429, { error: 'Rate limit exceeded' }, { 'Retry-After': String(limit.retryAfterSec) });
        }
        const clientAuth = authenticateBearer(req, 'client');
        if (!clientAuth) {
          return sendJson(res, 401, { error: 'Valid client session token required.' });
        }
        const sourceId = url.searchParams.get('sourceId');
        const targetSource = sourceId
          ? store.sources.find((s) => s.id === sourceId && s.isEnabled)
          : store.sources.find((s) => s.isPrimary && s.isEnabled) || store.sources.find((s) => s.isEnabled);

        if (!targetSource) {
          return sendJson(res, 404, { error: 'No enabled playlist source available.' });
        }

        if (store.channels.none((c) => c.sourceId === targetSource.id)) {
          await refreshSourceFromUpstream(targetSource);
        }

        const lines = ['#EXTM3U'];
        const sourceChannels = store.channels.filter((c) => c.sourceId === targetSource.id && c.enabled !== false);
        for (const ch of sourceChannels) {
          const attrs = [
            ch.tvgId ? `tvg-id="${ch.tvgId}"` : '',
            ch.logoUrl ? `tvg-logo="${ch.logoUrl}"` : '',
            `group-title="${ch.groupTitle}"`,
            `tvg-chno="${ch.channelNumber}"`
          ]
            .filter(Boolean)
            .join(' ');
          lines.push(`#EXTINF:-1 ${attrs},${ch.name}`);
          if (ch.userAgent) lines.push(`#EXTVLCOPT:http-user-agent=${ch.userAgent}`);
          lines.push(ch.streamUrl);
        }

        res.writeHead(200, {
          'Content-Type': 'application/vnd.apple.mpegurl; charset=utf-8',
          'Cache-Control': 'no-store'
        });
        return res.end(lines.join('\n'));
      }

      // Live Analytics Ingestion (Real events only)
      if (method === 'POST' && pathname === '/api/analytics/event') {
        const limit = rateLimiter.check(`analytics:${ip}`, 240, 60_000, nowFn());
        if (!limit.allowed) {
          return sendJson(res, 429, { error: 'Analytics rate limit exceeded' }, { 'Retry-After': String(limit.retryAfterSec) });
        }
        const clientAuth = authenticateBearer(req, 'client');
        if (!clientAuth) {
          return sendJson(res, 401, { error: 'Valid client session token required.' });
        }

        const body = await readJsonBody(req);
        const type = String(body.type || '').toUpperCase();
        const sessionId = String(body.sessionId || '').trim();
        if (!sessionId || !['START', 'HEARTBEAT', 'STOP', 'ERROR', 'CRASH_RECOVERY'].includes(type)) {
          return sendJson(res, 400, { error: 'Invalid analytics event payload.' });
        }

        const now = nowFn();
        const deviceType = body.deviceType === 'ANDROID_TV' ? 'ANDROID_TV' : 'MOBILE';
        const appVersion = String(body.appVersion || '1.0').slice(0, 24);
        const channelId = String(body.channelId || '').slice(0, 64);
        const channelName = String(body.channelName || 'Unknown').slice(0, 120);

        if (type === 'START' || type === 'HEARTBEAT') {
          const existing = store.sessions[sessionId];
          store.sessions[sessionId] = {
            sessionId,
            channelId,
            channelName,
            deviceType,
            appVersion,
            status: body.status === 'BUFFERING' ? 'BUFFERING' : 'PLAYING',
            startedAt: existing?.startedAt || now,
            lastHeartbeatAt: now,
            stoppedAt: null,
            errorCount: existing?.errorCount || 0
          };
          expireInactiveSessions();
          persist();
          return sendJson(res, 200, { ok: true, heartbeatIntervalSeconds: store.config.heartbeatIntervalSeconds });
        }

        if (type === 'STOP' || type === 'CRASH_RECOVERY') {
          const existing = store.sessions[sessionId];
          if (existing) {
            existing.status = type === 'CRASH_RECOVERY' ? 'EXPIRED' : 'STOPPED';
            existing.stoppedAt = now;
            persist();
          }
          return sendJson(res, 200, { ok: true });
        }

        if (type === 'ERROR') {
          const existing = store.sessions[sessionId];
          if (existing) {
            existing.errorCount = (existing.errorCount || 0) + 1;
            existing.lastHeartbeatAt = now;
          }
          store.recentErrors.unshift({
            id: crypto.randomUUID(),
            sessionId,
            channelId,
            channelName,
            deviceType,
            appVersion,
            errorCode: String(body.errorCode || 'PLAYBACK_ERROR').slice(0, 64),
            errorMessage: String(body.errorMessage || 'Playback error').slice(0, 240),
            timestamp: now
          });
          expireInactiveSessions();
          persist();
          return sendJson(res, 200, { ok: true });
        }
      }

      // OWNER-ONLY ADMIN AUTHENTICATION (No public registration)
      if (method === 'POST' && pathname === '/api/admin/login') {
        const limit = rateLimiter.check(`admin_login:${ip}`, 5, 15 * 60_000, nowFn());
        if (!limit.allowed) {
          return sendJson(
            res,
            429,
            { error: 'Too many admin login attempts. Please wait before retrying.' },
            { 'Retry-After': String(limit.retryAfterSec) }
          );
        }

        if (!adminUsername || !adminPasswordHash) {
          return sendJson(res, 503, { error: 'Owner administrator account is not configured on this server.' });
        }

        const body = await readJsonBody(req);
        const username = String(body.username || '').trim().toLowerCase();
        const password = String(body.password || '');

        const usernameMatches =
          username.length === adminUsername.length &&
          crypto.timingSafeEqual(Buffer.from(username), Buffer.from(adminUsername));
        const passwordMatches = verifyPassword(password, adminPasswordHash);

        if (!usernameMatches || !passwordMatches) {
          appendAudit(username || 'unknown', 'ADMIN_LOGIN_FAILED', `Rejected login from ${ip}`);
          persist();
          return sendJson(res, 401, { error: 'Invalid owner administrator credentials.' });
        }

        const now = nowFn();
        const exp = now + adminTokenTtlSec * 1000;
        const jti = crypto.randomUUID();
        const token = signToken({ scope: 'admin', sub: adminUsername, jti, iat: now, exp }, signingSecret);
        appendAudit(adminUsername, 'ADMIN_LOGIN_SUCCESS', `Authenticated from ${ip}`);
        persist();
        return sendJson(res, 200, { token, expiresAt: exp, username: adminUsername });
      }

      if (pathname === '/api/admin/register' || pathname === '/api/admin/signup') {
        return sendJson(res, 404, { error: 'Public admin registration is disabled.' });
      }

      // All /api/admin/* routes below require valid short-lived Owner Admin Bearer token
      if (pathname.startsWith('/api/admin/')) {
        const limit = rateLimiter.check(`admin_api:${ip}`, 90, 60_000, nowFn());
        if (!limit.allowed) {
          return sendJson(res, 429, { error: 'Admin API rate limit exceeded.' }, { 'Retry-After': String(limit.retryAfterSec) });
        }
        const adminAuth = authenticateBearer(req, 'admin');
        if (!adminAuth) {
          return sendJson(res, 401, { error: 'Admin session expired or unauthorized.' });
        }

        if (method === 'POST' && pathname === '/api/admin/logout') {
          store.revokedAdminJtis[adminAuth.jti] = adminAuth.exp;
          appendAudit(adminAuth.sub, 'ADMIN_LOGOUT', 'Signed out and revoked session token');
          persist();
          return sendJson(res, 200, { ok: true });
        }

        if (method === 'GET' && pathname === '/api/admin/analytics/live') {
          return sendJson(res, 200, computeLiveAnalytics());
        }

        if (method === 'GET' && pathname === '/api/admin/sources') {
          return sendJson(res, 200, { sources: store.sources });
        }

        if (method === 'POST' && pathname === '/api/admin/sources') {
          const body = await readJsonBody(req);
          const name = String(body.name || '').trim();
          const upstreamUrl = String(body.upstreamUrl || '').trim();
          if (!name || !/^https?:\/\//i.test(upstreamUrl)) {
            return sendJson(res, 400, { error: 'Valid source name and http(s) upstream URL are required.' });
          }
          const isPrimary = Boolean(body.isPrimary);
          const isBackup = Boolean(body.isBackup);
          const useProxy = body.useProxy !== false;
          if (isPrimary) {
            store.sources.forEach((s) => (s.isPrimary = false));
          }
          const newSource = {
            id: `src_${crypto.randomUUID().slice(0, 8)}`,
            name,
            upstreamUrl,
            isPrimary,
            isBackup: !isPrimary && isBackup,
            isEnabled: body.isEnabled !== false,
            useProxy,
            lastRefreshedAt: null,
            lastError: null,
            channelCount: 0
          };
          store.sources.push(newSource);
          store.config.configVersion += 1;
          appendAudit(adminAuth.sub, 'SOURCE_ADDED', `Added source "${name}" (proxy=${useProxy})`);
          persist();
          return sendJson(res, 201, { source: newSource });
        }

        const sourceMatch = pathname.match(/^\/api\/admin\/sources\/([^/]+)$/);
        if (sourceMatch) {
          const sourceId = decodeURIComponent(sourceMatch[1]);
          const source = store.sources.find((s) => s.id === sourceId);
          if (!source) return sendJson(res, 404, { error: 'Source not found.' });

          if (method === 'PUT') {
            const body = await readJsonBody(req);
            if (typeof body.name === 'string' && body.name.trim()) source.name = body.name.trim();
            if (typeof body.upstreamUrl === 'string' && /^https?:\/\//i.test(body.upstreamUrl.trim())) {
              source.upstreamUrl = body.upstreamUrl.trim();
            }
            if (typeof body.isEnabled === 'boolean') source.isEnabled = body.isEnabled;
            if (typeof body.isBackup === 'boolean') source.isBackup = body.isBackup;
            if (typeof body.useProxy === 'boolean') source.useProxy = body.useProxy;
            if (body.isPrimary === true) {
              store.sources.forEach((s) => (s.isPrimary = s.id === source.id));
              source.isBackup = false;
              source.isEnabled = true;
            }
            store.config.configVersion += 1;
            appendAudit(adminAuth.sub, 'SOURCE_UPDATED', `Updated source "${source.name}" (${source.id})`);
            persist();
            return sendJson(res, 200, { source });
          }

          if (method === 'DELETE') {
            if (store.sources.length <= 1) {
              return sendJson(res, 400, { error: 'Cannot remove the last remaining playlist source.' });
            }
            store.sources = store.sources.filter((s) => s.id !== sourceId);
            store.channels = store.channels.filter((c) => c.sourceId !== sourceId);
            if (source.isPrimary && store.sources.length > 0) {
              store.sources[0].isPrimary = true;
              store.sources[0].isEnabled = true;
            }
            store.config.configVersion += 1;
            appendAudit(adminAuth.sub, 'SOURCE_DELETED', `Deleted source "${source.name}" (${sourceId})`);
            persist();
            return sendJson(res, 200, { ok: true });
          }
        }

        const activateMatch = pathname.match(/^\/api\/admin\/sources\/([^/]+)\/activate-primary$/);
        if (method === 'POST' && activateMatch) {
          const sourceId = decodeURIComponent(activateMatch[1]);
          const source = store.sources.find((s) => s.id === sourceId);
          if (!source) return sendJson(res, 404, { error: 'Source not found.' });
          store.sources.forEach((s) => {
            if (s.id === sourceId) {
              s.isPrimary = true;
              s.isBackup = false;
              s.isEnabled = true;
            } else {
              if (s.isPrimary) s.isBackup = true;
              s.isPrimary = false;
            }
          });
          store.config.configVersion += 1;
          appendAudit(adminAuth.sub, 'PRIMARY_SOURCE_SWITCHED', `Switched primary source to "${source.name}"`);
          persist();
          return sendJson(res, 200, { sources: store.sources });
        }

        const refreshMatch = pathname.match(/^\/api\/admin\/sources\/([^/]+)\/refresh$/);
        if (method === 'POST' && refreshMatch) {
          const sourceId = decodeURIComponent(refreshMatch[1]);
          const source = store.sources.find((s) => s.id === sourceId);
          if (!source) return sendJson(res, 404, { error: 'Source not found.' });
          const outcome = await refreshSourceFromUpstream(source);
          appendAudit(
            adminAuth.sub,
            'SOURCE_REFRESHED',
            outcome.ok
              ? `Refreshed "${source.name}" (${outcome.count} channels)`
              : `Refresh failed for "${source.name}": ${outcome.error}`
          );
          persist();
          if (!outcome.ok) return sendJson(res, 502, { error: outcome.error });
          return sendJson(res, 200, { source, channelCount: outcome.count });
        }

        if (method === 'GET' && pathname === '/api/admin/channels') {
          return sendJson(res, 200, { channels: store.channels });
        }

        const channelMatch = pathname.match(/^\/api\/admin\/channels\/([^/]+)$/);
        if (method === 'PATCH' && channelMatch) {
          const channelId = decodeURIComponent(channelMatch[1]);
          const channel = store.channels.find((c) => c.id === channelId);
          if (!channel) return sendJson(res, 404, { error: 'Channel not found.' });

          const body = await readJsonBody(req);
          if (typeof body.name === 'string' && body.name.trim()) {
            channel.name = body.name.trim();
            channel.customName = channel.name;
          }
          if (typeof body.logoUrl === 'string') {
            channel.logoUrl = body.logoUrl.trim() || null;
            channel.customLogoUrl = channel.logoUrl;
          }
          if (typeof body.groupTitle === 'string' && body.groupTitle.trim()) {
            channel.groupTitle = body.groupTitle.trim();
            channel.customGroupTitle = channel.groupTitle;
          }
          if (typeof body.channelNumber === 'number' && body.channelNumber > 0) {
            channel.channelNumber = Math.floor(body.channelNumber);
            channel.customChannelNumber = channel.channelNumber;
          }
          if (typeof body.enabled === 'boolean') {
            channel.enabled = body.enabled;
          }
          store.config.configVersion += 1;
          appendAudit(
            adminAuth.sub,
            'CHANNEL_UPDATED',
            `Updated channel "${channel.name}" (enabled=${channel.enabled})`
          );
          persist();
          return sendJson(res, 200, { channel });
        }

        if (method === 'PUT' && pathname === '/api/admin/config') {
          const body = await readJsonBody(req);
          if (typeof body.heartbeatIntervalSeconds === 'number') {
            store.config.heartbeatIntervalSeconds = Math.min(300, Math.max(10, Math.floor(body.heartbeatIntervalSeconds)));
          }
          if (typeof body.sessionTimeoutSeconds === 'number') {
            store.config.sessionTimeoutSeconds = Math.min(600, Math.max(20, Math.floor(body.sessionTimeoutSeconds)));
          }
          if (typeof body.retentionDays === 'number') {
            store.config.retentionDays = Math.min(90, Math.max(1, Math.floor(body.retentionDays)));
          }
          if (typeof body.analyticsEnabled === 'boolean') {
            store.config.analyticsEnabled = body.analyticsEnabled;
          }
          if (typeof body.maintenanceMessage === 'string') {
            store.config.maintenanceMessage = body.maintenanceMessage.trim().slice(0, 240);
          }
          store.config.configVersion += 1;
          appendAudit(
            adminAuth.sub,
            'CONFIG_PUSHED',
            `Pushed config v${store.config.configVersion} (heartbeat=${store.config.heartbeatIntervalSeconds}s, timeout=${store.config.sessionTimeoutSeconds}s, retention=${store.config.retentionDays}d)`
          );
          persist();
          return sendJson(res, 200, { config: store.config });
        }

        if (method === 'GET' && pathname === '/api/admin/audit-logs') {
          return sendJson(res, 200, { logs: store.auditLogs.slice(0, 150) });
        }
      }

      return sendJson(res, 404, { error: 'Endpoint not found.' });
    } catch (err) {
      return sendJson(res, 500, { error: err.message || 'Internal server error' });
    }
  });

  // Compatibility helper
  if (!Array.prototype.none) {
    Object.defineProperty(Array.prototype, 'none', {
      value(pred) {
        return !this.some(pred);
      },
      enumerable: false
    });
  }

  return {
    server,
    getStore: () => store,
    expireInactiveSessions
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 8080);
  const host = process.env.HOST || '0.0.0.0';
  const { server } = createTerminalServer();
  server.listen(port, host, () => {
    console.log(`M3U8PLAYLISTTERMINAL Backend listening on http://${host}:${port}`);
  });
}
