import crypto from 'node:crypto';
import readline from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';

export function hashPassword(password) {
  if (!password || password.length < 10) {
    throw new Error('Admin password must be at least 10 characters.');
  }
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  return `scrypt$16384$8$1$${salt}$${derived}`;
}

export function verifyPassword(password, storedHash) {
  if (!password || !storedHash || typeof storedHash !== 'string') return false;
  const parts = storedHash.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const n = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  const salt = parts[4];
  const expectedHex = parts[5];
  if (!salt || !expectedHex || Number.isNaN(n) || Number.isNaN(r) || Number.isNaN(p)) {
    return false;
  }
  const derived = crypto.scryptSync(password, salt, 64, { N: n, r, p });
  const expected = Buffer.from(expectedHex, 'hex');
  if (derived.length !== expected.length) return false;
  return crypto.timingSafeEqual(derived, expected);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const rl = readline.createInterface({ input, output });
  try {
    const pwd = process.argv[2] || (await rl.question('Enter owner admin password (min 10 chars): '));
    const hash = hashPassword(pwd.trim());
    console.log('\nAdd this to your backend environment (never put in the Android APK):');
    console.log(`ADMIN_PASSWORD_HASH=${hash}`);
  } finally {
    rl.close();
  }
}
